function initFiltersCardCarousel() {
  $(document).find(".fitlers-cards-wrapper").each(function (index) {
        $(this).addClass('slideronPageFilter' + index);
        var $filtersParent = $(this);
        $filtersParent.find(".swiper-pagination").addClass("filtersCardsCarousels" + index);
        $filtersParent.find(".swiper-button-next").addClass("filtersCardRight" + index);
        $filtersParent.find(".swiper-button-prev").addClass("filtersCardLeft" + index);
      var swiperSlideLength = $('.slideronPageFilter' + index + " .filters-cards-carousel .swiper-slide").length;
      $(this).addClass("swiper-with-" + swiperSlideLength + "-slides");
      if ($(window).width() > 992) {
        if (swiperSlideLength <= 3) {
          
          $(".slideronPageFilter" + index).addClass("destroyed");
          $(".slideronPageFilter" + index).find(".swiper-wrapper").addClass("row");
          $(".slideronPageFilter" + index).find(".swiper-wrapper.row").children().removeClass("swiper-slide");
          $(".slideronPageFilter" + index).find(".swiper-navigation").addClass("deactive");
        } else {
          $(".slideronPageFilter" + index).find(".swiper-wrapper").removeClass("row");
          var $carouselSliderwithProgressFilter = new Swiper(".slideronPageFilter" + index + " .filters-cards-carousel",
            
            {
              nextButton: $(this).find(".swiper-button-next.filtersCardRight" + index),
              prevButton: $(this).find(".swiper-button-prev.filtersCardLeft" + index),
              pagination: $(this).find(".swiper-pagination.filtersCardsCarousels" + index),
              slidesPerView: 3,
              slidesPerGroupSkip: 1,
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
                type: "progressbar",
              },
              breakpoints: {
                1099: {
                  slidesPerView: 3,
                  spaceBetween: 24,
                },
                768: {
                  slidesPerView: 2,
                  spaceBetween: 16,
                  pagination: {
                    type: "progressbar",
                    clickable: true,
                  },
                },
                600: {
                  slidesPerView: 2,
                  spaceBetween: 16,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  },
                },
                500: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                  pagination: {
                    type: "bullets",
                    clickable: true
                  }
                },
                100: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  }
                }
              }
            }
          );
        }
      } else {
        $(".slideronPageFilter" + index).find(".swiper-wrapper").removeClass("row");
        var $carouselSliderwithProgressFilter = new Swiper(".slideronPageFilter" + index + " .filters-cards-carousel",
          {
            slidesPerView: 3,
            slidesPerGroupSkip: 1,
            nextButton: $(this).find(".swiper-button-next.filtersCardRight1" + index),
              prevButton: $(this).find(".swiper-button-prev.filtersCardLeft1" + index),
              pagination: $(this).find(".swiper-pagination.filtersCardsCarousels1" + index),
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
                type: "progressbar",
              },
              breakpoints: {
                1099: {
                  slidesPerView: 3,
                  spaceBetween: 24,
                },
                768: {
                  slidesPerView: 2,
                  spaceBetween: 16,
                  pagination: {
                    type: "progressbar",
                    clickable: true,
                  },
                },
                600: {
                  slidesPerView: 2,
                  spaceBetween: 16,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  },
                },
                500: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  }
                },
                100: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  }
                }
              }
            }
        );
      }
    });
  
}

 $(document).ready(function () {
  initFiltersCardCarousel();
   //total count fuction product sum (single category)
   $(".p-category-list-wrap ul").each(function () {
     var single_sum = 0;
     $(this).find('.price-badge').each(function () {
       single_sum += parseFloat($(this).text().trim()) || 0;
     });

     $(this).find(".total-price-badge").html(single_sum.toFixed(0));
   });

   //total count function product sum (sub category)
   $(".p-category-list-wrap ul .accordion-item").each(function () {
     var sum = 0;
     $(this).find('.price-badge').each(function () {
       sum += parseFloat($(this).text().trim()) || 0;
     });

     $(this).find(".total-price-badge").html(sum.toFixed(0));
   });

   var radios = []
   // selected radios
   var selected = [];

   $(".p-category-list-wrap input").each(function () {
     radios.push($(this))
   });

   for (var i = 0; i < radios.length; i++) {
     $(radios[i]).each(function (index) {
       var self = $(this);
       if ($(this).prop('checked')) {
         selected.push($(this));

         //console.log($(this).attr('data-label'))
         // passing data-label and id to function for filtering
         filterCards($(this).attr('data-label'), $(this));
       }
     });
   }

   // on radio selction show hide right panel ( container )
   $(".p-category-list-wrap input").change(function () {
     if ($(this).is(":checked")) { // check if the radio is checked
       filterCards($(this).attr('data-label'), $(this));
     }
   });

   function filterCards(radioInput, selfFilter) {
     var filter = $(selfFilter).closest('.p-category-list-wrap');
     //var product-common-data = $(selfFilter).closest('.product-common-data');
     //var currentTab = $('#'+tabsID);
     $(filter).find('ul li').removeClass('active');
     $(filter).find("[data-label='" + radioInput + "']").closest('li').addClass('active');
     $('.product-common-data .filters-data').css('display', 'none');

     if (radioInput === 'all-categories') {
       $('.product-common-data .filters-data').css('display', 'block');
     } else {
       $("[data-label='" + radioInput + "']").css('display', 'block');
     }
   }
   //view more button show hide if category is less then or equal to 5 

   $(".p-category-list-wrap ul").each(function () {
     var liCount;
     liCount = $(this).children("li").length;
     if (liCount <= 5) {
       $(this).next(".view-more-filters").addClass("d-none");
     }
   });
   // view more and view less functionality for category list ( filters )
   function vewCategoriesMoreLess() {
     var button = $(this);
     button.closest('.p-category-list-wrap').find('ul').toggleClass('full-list');
     button.toggleClass('toggleView');
   }
   $('.p-category-list-wrap .view-more-filters').off('click').on('click', vewCategoriesMoreLess);

   // filter mobile view popup open close
  //  function filtersMobileView(thisValue) {
  //    if (window.innerWidth < 992) {
  //      var currentElement = $(thisValue).attr('data-label');
  //      if (currentElement) {
  //        $('.responsive-' + currentElement).addClass('mobileViewActive')
  //        $('body').addClass('freeze');
  //      }
  //    }
  //  }
  //  $('.filter-compare-sort-section a').off('click').on('click', function () {
  //    filtersMobileView(this);
  //  });

  if (window.innerWidth < 992) {
      $('.filter-compare-sort-section .filter-icon > a').click(function(){
        var inputValueFilter = $(this).attr("data-label");
        var targetBillFilter = $("." + inputValueFilter);
        // $(".bill").not(targetBill).hide();
        $(targetBillFilter).addClass('mobileViewActive');
        $('body').addClass('freeze');
      });
    }

   // to make filters popup in-active ( hide )in mobile view
   $('.filter-close').off('click').on('click', function () {
     $('.responsive-filters').removeClass('mobileViewActive');
     $('.responsive-sort').removeClass('mobileViewActive');
     $('body').removeClass('freeze');
   });
 });