/**
 * Intro Text With Counter
 */

$(document).ready(function() {
  $('.intro-text-with-counter .counter-section-box .counter').each(function () {
      var countertext=$(this).text();
      var countertext2 = countertext[countertext.length-1];
      console.log(countertext2);
      function containsOnlyNumbers(countertext2) {
          return /^[0-9]+$/.test(countertext2);
        }
      if (containsOnlyNumbers(countertext2) == true){
          var countertext2 = "";
      } else{
          var countertext2 = countertext2;
      }
      $(this).prop('Counter',0).animate({
          Counter: $(this).text()
      }, {
          duration: 1000,
          easing: 'swing',
          step: function (now) {
              $(this).text(Math.ceil(now));
          },
          complete: function() {
              $(this).text(this.Counter + countertext2);
            }
      });
  });
});
