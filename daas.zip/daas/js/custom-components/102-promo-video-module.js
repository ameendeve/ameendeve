/**
 * Promo Video Modules
 */

$(document).ready(function() {
  if (document.getElementsByClassName("youtube-popup-container") !== null) { 
      var promovideomodal = document.getElementsByClassName("youtube-popup-container");            
      for (let i = 0; i < promovideomodal.length; i++) {
        promovideomodal[i].addEventListener("click", function () {
          var src = $(this).find('iframe').attr('src');
          $(this).find('iframe').attr('src', '');
          $(this).find('iframe').attr('src', src.replace('autoplay=1', '')); 
        });
      }
    }
});

