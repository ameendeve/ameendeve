/* 
===========================
   100 Icon With Description Tile
===========================
*/



function currentpromotionslider() {          
  $(document).find(".currentpromoslider").each(function (index) {
    $(this).addClass("cpromocardslid" + index);
    var $contextNavigation = $(this);
    $contextNavigation.find(".swiper-button-next").addClass("CPSRight" + index);
    $contextNavigation.find(".swiper-button-prev").addClass("CPSLeft" + index);
    $contextNavigation.find(".swiper-pagination").addClass("cpPagination" + index);
    var etiSlidesCount = $contextNavigation.find('.swiper-slide').length;
    $(this).addClass("IB-tiles-" + etiSlidesCount);
    var currentpromotioncardslider = new Swiper(".cpromocardslid" + index + " .swiper", {
        slidesPerView: 3,
        pagination: {
          el: ".swiper-pagination.cpPagination" + index,
          clickable: true,                
        },   
        navigation: {
          nextEl: ".swiper-button-next.CPSRight" + index,
          prevEl: ".swiper-button-prev.CPSLeft" + index,
          clickable: true,
        },              
        breakpoints: {
          200: {
            slidesPerView: 1.25,
            spaceBetween: 16,
            pagination: {
              type: "bullets",
              clickable: true,
            },
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 16,
          },
          992: {
            slidesPerView: 2.5,
            spaceBetween: 16,                     
          },
          1224: {
            slidesPerView: 2.5,
            spaceBetween: 32,
          }
        },
      });
  });
}
  // register the event handlers
  $(document).ready(function () {
      currentpromotionslider();
  //   var sliderlength = $(".currentpromoslider .swiper-slide").length;
  //   console.log(sliderlength);
  //   if ($(window).width() > 1224) {
  //     if(sliderlength > 4){
  //       currentpromotionslider();
  //     }
  //   }else{
  //     currentpromotionslider();
  //   }
  });
