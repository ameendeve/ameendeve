/*
* Choose your number ###version###
*/
import { FORM_SUCCESS, FORM_ERROR } from '../../js/analytics/analytics';
import valdefault from 'jquery';

valdefault();
// default Variables
var activeNumbers = []
var numbersWithErros = 0;
var $smbVerifyNumberForm = $("#chooseyournumber");
var smbVerifyNumberFormmessagelocal;
var smbVerifyNumberFormresultMessageContainer = $("#chooseyournumber .business-form-submitted");
var smbVerifyNumberFormGeneralErrorMsg = window.location.href.indexOf(".ae/ar") > -1 ? "هناك شيء خاطئ، يرجى المحاولة في وقت لاحق" : "Something went wrong, please try again later";
var smbVerifyNumbersvalidateMessage = {
    en: {
        contactNumber: {
            number: "Number connot contain numbers",
            maxlength: "Number cannot be longer than 50 characters.",
            minlength: "Number cannot be less than 10 characters.",
        },
    },
    ar: {
        contactNumber: {
            number: "يرجى كتابة الاسم ",
            maxlength: "يرجى كتابة الاسم ",
            minlength: "يرجى كتابة الاسم ",
        }
    }
};

if ($('html').attr('lang') == "ar") {
    smbVerifyNumberFormmessagelocal = smbVerifyNumbersvalidateMessage.ar;
    console.log(smbVerifyNumberFormmessagelocal)
} else {
    smbVerifyNumberFormmessagelocal = smbVerifyNumbersvalidateMessage.en;
}

function showErrorMessage(text) {
    smbVerifyNumberFormresultMessageContainer.text(text);
    smbVerifyNumberFormresultMessageContainer.addClass("error-msg").delay(10000).fadeOut(300);
}

function submitErrorResponse(jqXHR, textStatus, error) {
    let errorText = (jqXHR.responseJSON && jqXHR.responseJSON.message) || error;
    showErrorMessage(smbVerifyNumberFormGeneralErrorMsg);
    FORM_ERROR($smbVerifyNumberForm, 'API error', errorText);
}

// Validation on number submission
function chooseyournumber(settings, givenNumber, givenUrlforRedirect) {
    console.log('trigger choose function')
    var givenUrl = $('#submitNumber').attr('redirectURL');
    var givenUrlforRedirect = window.location.origin + givenUrl
    $.ajax(settings).done(function (response) {
        let responseObject = JSON.parse(response)
        // response.data?.filter((number, index) => {
            let numberData = responseObject?.data
            console.log(numberData)
            if(numberData !== undefined && numberData.length > 0) {
                numberData?.filter((num) => {
                    let numberExist = activeNumbers.includes(num.accountNumber)
                    if (numberExist) {
                        $(".phonenumber").each(function () {
                            if ($(this).text().includes(num.accountNumber)) {
                                $(this).addClass('exisitng-etisalat')
                            }
                        })
                    }
                    numbersWithErros = $(".phonenumber.exisitng-etisalat").length;
                    console.log(numbersWithErros)
                    if (numbersWithErros > 0) {
                        // console.log(numbersWithErros)
                        var showerromeesagenotification = (window.location.href.indexOf("/ar/") > -1 ? 'الرقم موجود بالفعل في اتصالات يرجى إزالته للمتابعة' : 'Number already in Etisalat. Kindly remove it to continue');
                        $(".verify-number-section .fixed-number-form .etisalat-notification-error .notification-text p").text(showerromeesagenotification);
                        $(".verify-number-section .fixed-number-form .etisalat-notification-error").show();
                    } else {
                        // console.log(numbersWithErros)
                        console.log('no errors found')
                        if(activeNumbers.length > 0) {
                            // console.log(numbersWithErros)
                            // console.log('numbers exist and ready to go')
                            window.location.href = givenUrlforRedirect
                        } else {
                            // console.log('numbers are set to 0 do not go')
                            var errormesstxt = (window.location.href.indexOf("/ar/") > -1 ? 'At least one number required.' : 'At least one number required.');
                            $("#contactNumber-error").text(errormesstxt).addClass("d-block").show();  
                        }
                        $(".verify-number-section .fixed-number-form .etisalat-notification-error").hide();
                    }    
                })
            } else {
                window.location.href = givenUrlforRedirect
            }
        // })
    })
    .fail(submitErrorResponse);
}

// form  validtions
$(document).ready(function () {

    let fieldNumber = $('#chooseyournumber input')
    fieldNumber.keyup(function (e) {
        var givenNumber = $('#contactNumber').val();
        
        if (e.keyCode == 188 && givenNumber !== '' ) {
            
            if ($('#contactNumber').valid()) {
                if (!activeNumbers.includes(givenNumber)) {
                    if (activeNumbers.length > 9) {
                        var showerromeesagenotification = (window.location.href.indexOf("/ar/") > -1 ? 'الحد الأقصى المسموح به هو 10 أرقام' : 'Maximum 10 numbers are allowed.');
                        $(".verify-number-section .fixed-number-form .etisalat-notification-error .notification-text p").text(showerromeesagenotification);
                        $(".verify-number-section .fixed-number-form .etisalat-notification-error").show().delay(5000).fadeOut(300);
                    } else {
                        activeNumbers.push(givenNumber);
                        $(".phonenumber-section").append(`<div class='phonenumber'>${givenNumber}<span><img src='/content/dam/etisalat/svg-icons/close-icon.svg'/></span></div>`);
                    }
                } else {
                    var errormesstxt = (window.location.href.indexOf("/ar/") > -1 ? 'رقم مكرر' : 'Repeated number.');
                    $("#contactNumber-error").text(errormesstxt).addClass("d-block").show();
                }                   
                $('#submitNumber').prop('disabled', false);  
            } else {
                $('#submitNumber').prop('disabled', 'disabled');
            }
            
            fieldNumber.val('')
            return false;

        } else {
            // var errormesstxt = (window.location.href.indexOf("/ar/") > -1 ? 'Number required.' : 'Number required.');
            // $("#contactNumber-error").text(errormesstxt).addClass("d-block").show();
        }
    });
    var $smbformdesktop = $('#chooseyournumber');
    $.validator.messages.required = "";
    $smbformdesktop.validate({
        rules: {
            contactNumber: {
                pattern: /^(02|03|04|06|07|09)/,
                number: true,
                digits: true,
                minlength: 9,
                maxlength: 9
            },
        },
        errorPlacement:
        function (error, element) {
            error.insertAfter(element);
        },
        messages: smbVerifyNumbersvalidateMessage,
        submitHandler: function (form, event) {
            sessionStorage.setItem("activeNumbers", JSON.stringify(activeNumbers))
            var jsonNumbers = { 
                "accountNumber" : JSON.parse(JSON.stringify(activeNumbers).replace(/↵/g, ''))
            }
            var givenNumber = $('#contactNumber').val();
            var givenUrl = $('#submitNumber').attr('redirectURL');
            var givenUrlforRedirect = window.location.origin + givenUrl
            var actionURL = $('#chooseyournumber').attr('actionURL');
            var settings = {
                async: true,
                url: actionURL,
                // url: `https://devnew.etisalat.ae/dnative/smb-buy-and-get-service//account/account-status`,
                //url : `https://www.etisalat.ae/b2bportal/Utility/checkCaptcha.service`,
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": '*',
                },
                data:JSON.stringify(jsonNumbers),
            };
            //console.log(settings)
            chooseyournumber(settings, givenNumber, givenUrlforRedirect);
            return false;
        },
    })
    $.extend($.validator.messages, 
        { pattern: window.location.href.indexOf(".ae/ar") > -1 ? ". رقم غير صالح." : "invalid format number.",
          minlength: window.location.href.indexOf(".ae/ar") > -1 ? "الحد الأدنى لعدد الأرقام 9" : "Please enter at least 9 number." ,
          maxlength: window.location.href.indexOf(".ae/ar") > -1 ? "الرجاء إدخال ما لا يزيد عن 9 أرقام" : "Please enter no more than 9 number." ,
        }
    );
})

$(document).ready(function () {
    if($('#chooseyournumber').length){
      $("#chooseyournumber #contactNumber").valid();
    }
    // Removing number from list on X icon
    $(document).on('click', '.verify-number-section .fixed-number-form .form-section .form-group .phonenumber-section .phonenumber span', function () {
        let numberToRemove = $(this).parent(".phonenumber").text()
        $(this).parent(".phonenumber").remove()

        let index = activeNumbers.indexOf(numberToRemove);
        let x = activeNumbers.splice(index, 1);
        numbersWithErros = $(".phonenumber.exisitng-etisalat").length
        console.log(numbersWithErros)
        if (numbersWithErros > 0) {
            var showerromeesagenotification = (window.location.href.indexOf("/ar/") > -1 ? 'الرقم موجود بالفعل في اتصالات يرجى إزالته للمتابعة' : 'Number already in Etisalat. Kindly remove it to continue');
            $(".verify-number-section .fixed-number-form .etisalat-notification-error .notification-text p").text(showerromeesagenotification);
            $(".verify-number-section .fixed-number-form .etisalat-notification-error").show();
        } else {
            $(".verify-number-section .fixed-number-form .etisalat-notification-error").hide(); 
            $('#submitNumber').prop('disabled', false);                      
        }
        let phonenumbercount =  $(".phonenumber").length
        if(phonenumbercount == 0){
            $('#submitNumber').prop('disabled', 'disabled');
        }
    });
    if ($("#chooseyournumber #addNumber").is(":focus")) {
        // console.log('add number active')
    }
});