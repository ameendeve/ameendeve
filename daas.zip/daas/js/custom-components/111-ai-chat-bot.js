localStorage.setItem("AIChat", 'No');
  function getTokenID() {
      localStorage.setItem("AIChat", 'No');
      var $location = $('.show-ai-support').attr("data-domain");
      var currentLang = $('html').attr('lang');
      if (localStorage.getItem("userInfo")) {
          let userData = JSON.parse(localStorage.getItem("userInfo"));
          //var loggedInIframe = $location + "/etisalat-va/?channel=digitalnativeweb&language=" + currentLang + "&fullName=" + userData.firstName + userData.lastName + "&sendemailto=" + userData.eMail + "&accountNumber=" + userData.accountNumber + "&token=" + userData.token;
          var loggedInIframe = $location;
          localStorage.setItem("AIChat", 'Yes');
          if ($('.aiChatIfreameDiv iframe').length > 0) {
              $('.aiChatIfreameDiv iframe').remove();
              $(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedInIframe + "'></iframe>");
          } else {
              $(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedInIframe + "'></iframe>");
          }
      } else {
          //var loggedOutIframe = $location + '/etisalat-va/?channel=digitalnativeweb&language=en';
          var loggedOutIframe = $location;
          localStorage.setItem("AIChat", 'Yes');
          if ($('.aiChatIfreameDiv iframe').length > 0) {
              $('.aiChatIfreameDiv iframe').remove();
              $(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedOutIframe + "'></iframe>");
          } else {
              $(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedOutIframe + "'></iframe>");
          }
      }
  }

  $(document).ready(function() {
      localStorage.setItem("AIChat", 'No');
      $(document).mouseup(function(e) {
          var container = $(".aiChatIfreameDiv,.show-ai-support");
          if (!container.is(e.target) // if the target of the click isn't the container...
              &&
              container.has(e.target).length === 0) // ... nor a descendant of the container
          {
              //  $('body').removeAttr('style');
              //  $('.ai-chat-wrapper').hide(300);
              //  $('.show-ai-support').show();
              localStorage.setItem("AIChat", 'Yes');
          }
      });

      $(document).on('click', '.minAI', function() {
          $('body').removeAttr('style');
          $('.ai-chat-wrapper').hide(300);
          $('.show-ai-support').show();
          $('.config-section-wrap').css('z-index', '8');
          localStorage.setItem("AIChat", 'Yes');
      })

      $(document).on('click', '.plain', function() {
          alert('testing')
      });

      $(".hide-ai-support").click(function() {
          $('.ai-chat-wrapper').hide(300);
          $('.show-ai-support').show();

      });
      $(".show-ai-support").click(function() {
          if ($(window).width() < 767) {
              $('body').css('position', 'fixed');
              $('.config-section-wrap').css('z-index', '13');
          }
          getTokenID();
          $('.ai-chat-wrapper').show(300);
          $('.ai-chat-wrapper').removeClass('hide');
          $('.show-ai-support').hide();
          if (localStorage.getItem("AIChat") == 'No' || localStorage.getItem("AIChat") == null) {
              localStorage.setItem("AIChat", 'Yes');
          }
      });
  });
