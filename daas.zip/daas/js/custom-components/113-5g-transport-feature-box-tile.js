if (document.getElementsByClassName("ifram-close-transportation") !== null) { 
    var productvideoslider = document.getElementsByClassName("ifram-close-transportation");            
    for (let i = 0; i < productvideoslider.length; i++) {
      productvideoslider[i].addEventListener("click", function () {
        var src = $(".trasnport-modal .modal-body").find('iframe').attr('src');
        console.log(src);
        $(".trasnport-modal .modal-body").find('iframe').attr('src', '');
        $(".trasnport-modal .modal-body").find('iframe').attr('src', src.replace('autoplay=1', '')); 
      });
    }
  }