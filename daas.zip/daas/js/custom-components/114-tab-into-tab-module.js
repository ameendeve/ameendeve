
const paramstabs = new URLSearchParams(window.location.search);

function parenttabslider() {
  $(".tab-into-tab-section").each(function (index) {
    $(this).addClass("tab-slider-section" + index);
    new Swiper(".tab-slider-section" + index + " .swiper", {
      slidesPerView: "auto",
      freeMode: true,
      allowTouchMove: true,
      spaceBetween: 8,
      mousewheel: true,
      slideToClickedSlide: true,
    });
  });
}

function subslidertab() {
  $(".sub-tabs-swiper").each(function (index) {
    $(this).addClass("sub-slider-section" + index);
    new Swiper(".sub-slider-section" + index + " .swiper", {
      slidesPerView: "auto",
      freeMode: true,
      allowTouchMove: true,
      spaceBetween: 8,
      mousewheel: true,
      slideToClickedSlide: true,
    });
  });
}

function activateTabsFromURL() {
  const tab = paramstabs.get("parenttab");
  const subtab = paramstabs.get("subtab");

  if (tab) {
    const tabTrigger = document.querySelector(`button[data-bs-target="#${tab}"]`);
    if (tabTrigger) {
      new bootstrap.Tab(tabTrigger).show();

      if (subtab) {
        setTimeout(() => {
          const subtabTrigger = document.querySelector(`a[href="#${subtab}"]`);
          if (subtabTrigger) {
            new bootstrap.Tab(subtabTrigger).show();
          }
        }, 300);
      }
    }
  }
}

function updateURLFromActiveTabs() {
  const parentLink = document.querySelector(".nav-tabs .nav-link.active");
  const parentTabName = parentLink ? parentLink.getAttribute("data-bs-target").substring(1) : "";
  let subTabName = "";

  if (parentTabName) {
    const parentTabPane = document.querySelector(`#${parentTabName}`);
    if (parentTabPane) {
      const subLink = parentTabPane.querySelector(".nav-tabs .nav-link.active");
      if (subLink) {
        subTabName = subLink.getAttribute("href").substring(1);
      }
    }
  }

  if (parentTabName) paramstabs.set("parenttab", parentTabName);
  if (subTabName) paramstabs.set("subtab", subTabName);

  const newUrl = `${window.location.pathname}?${paramstabs.toString()}`;
  history.replaceState(null, "", newUrl);
}

function handleTabHistoryUpdate() {
  document.querySelectorAll('[data-bs-toggle="tab"], [data-bs-toggle="pill"]').forEach(tab => {
    tab.addEventListener("shown.bs.tab", function () {
      updateURLFromActiveTabs();
    });
  });
}

$(document).ready(function () {
  parenttabslider();
  subslidertab();
  activateTabsFromURL();
  handleTabHistoryUpdate();
});