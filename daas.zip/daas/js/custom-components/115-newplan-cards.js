
    $(function () {
      function newPlancardmoduleSlider() {
        $(document).find(".newplancardslider").each(function (index) {
          var sectionClass = "newplancardslider-section" + index;
          $(this).addClass(sectionClass);

          // Check if this slider is Business Essential
          var isBusinessEssential = $(this).hasClass("business-essential-slider");

          // Custom breakpoints
          var breakpointsConfig = isBusinessEssential ? {
            1099: {
              slidesPerView: 4,
              spaceBetween: 16
            },
            768: {
              slidesPerView: 2,
              spaceBetween: 16
            },
            100: {
              slidesPerView: 2.5,
              spaceBetween: 12
            }
          } : {
            1099: {
              slidesPerView: 3,
              spaceBetween: 16
            },
            768: {
              slidesPerView: 2,
              spaceBetween: 16
            },
            100: {
              slidesPerView: 1.25,
              spaceBetween: 12
            }
          };

          // Swiper Init
          var newplancardslidermodule = new Swiper("." + sectionClass + " .swiper", {
            slidesPerView: 1,
            pagination: {
              el: "." + sectionClass + " .swiper-pagination",
              clickable: true,
              type: "bullets"
            },
            navigation: {
              nextEl: "." + sectionClass + " .ql-next",
              prevEl: "." + sectionClass + " .ql-prev"
            },
            breakpoints: breakpointsConfig
          });
        });
      }
      $(document).ready(function () {
        newPlancardmoduleSlider();
      });
    });