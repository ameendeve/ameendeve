/**
 * Video Slider Module
 */

$(document).ready(function () {
  // popup
  $('.overlay-link').off('click').on('click', function (e) {
    e.preventDefault();
    e.stopPropagation();
    var dataLabel = $(this).attr("data-label"); //console.log(dataLabel);

    if (typeof dataLabel !== 'undefined' && dataLabel !== '') {
      $('#' + dataLabel).addClass('show');
      $('body').addClass('freeze');
    }
  });

  //trigger register the event handlers of aos animation on click
  $('.overlay-link').on('click', function () {
    $('.overlay-modal *').removeClass('aos-animate');
    setTimeout(function () {
      $('.overlay-modal *').addClass('aos-animate');
    }, 800);
  });

 // close popup
  $('.fullscreen-overlay-wrap').off('click').on('click', '.modal-close', function (e) {
    e.stopPropagation();
    e.preventDefault();
    var currentOpendPopUp = $(this).closest('.overlay-modal');
    $(currentOpendPopUp).removeClass('show');
    $('body').removeClass('freeze');
  });
});
