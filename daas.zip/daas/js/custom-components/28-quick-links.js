/**
 * v20180725
 */


     $(function () {
      function quicklinksslider() {
        $(document).find(".quick-links-with-slider").each(function (index) {

          // Assign unique class for each slider section
          var sectionClass = "quick-links-with-slider-section" + index;
          $(this).addClass(sectionClass);

          // Swiper Init
          var quicllinkslidermodule = new Swiper("." + sectionClass + " .swiper", {
            slidesPerView: 1,

            pagination: {
              el: "." + sectionClass + " .swiper-pagination",
              clickable: true,
              type: "bullets",
            },

            // 🔥 External Navigation Buttons (outside swiper)
            navigation: {
              nextEl: "." + sectionClass + " .ql-next",
              prevEl: "." + sectionClass + " .ql-prev",
            },

            breakpoints: {
              1099: {
                slidesPerView: 6,
                spaceBetween: 16,
              },
              768: {
                slidesPerView: 4,
                spaceBetween: 16,
              },
              100: {
                slidesPerView: 3,
                spaceBetween: 12,
              },
            },
          });

        });
      }

      // register the event handlers
      $(document).ready(function () {
        quicklinksslider();
      });
    });