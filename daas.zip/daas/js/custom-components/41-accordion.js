/**
 * 41 Accordion Module
 */

 $(document).ready(function () {
  $('.expand-collapse .collapse').on('shown.bs.collapse', function(e) {
      var $card = $(this).closest('.accordion-item');
      console.log($card);
      var $open = $($(this).data('parent')).find('.expand-collapse .collapse.show');
      console.log($open);
      var additionalOffset = 0;
      if($card.prevAll().filter($open.closest('.accordion-item')).length !== 0)
      {
            additionalOffset =  $open.height();
      }
      $('html,body').animate({
        scrollTop: $card.offset().top - additionalOffset - 120
      }, 500);
    });
    var siteurlb2b = $(".purchaseidvalue").val();
    $('.accordion-wrap .accordion .accordion-item').each(function(){
      //var tenderid=$(this).find(".accordion-header .accordion-button").text().trim();
      //var tenderidget=tenderid.split(".")[1].trim();  
      var tenderidval = $(this).find(".tenderidvalue").val();
        if(tenderidval != null){
          $(this).find(".purchaseidhref a").attr('href', siteurlb2b + "?tenderid=" + tenderidval);
        }
      });

      $('#accordioncollapse').on('click', function (e) {
        e.preventDefault(); // Stop jumping to top

        const isExpanded = $(this).hasClass('active');
        const $button = $(this);
        const $accordion = $button.closest('.sec-main-headings').next('.accordion');

        if (!isExpanded) {
          // Expand this accordion only
          $accordion.find('.accordion-collapse').addClass('show');
          $button.addClass('active');
          $button.find('.more').addClass('d-none');
          $button.find('.less').removeClass('d-none');
        } else {
          // Collapse this accordion only
          $accordion.find('.accordion-collapse').removeClass('show');
          $button.removeClass('active');
          $button.find('.less').addClass('d-none');
          $button.find('.more').removeClass('d-none');
        }
      }); 
 
});