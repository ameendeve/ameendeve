$(document).ready(function () {
  // tooltip
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  }); //tooltip on click js start

  $('.tooltip-btn').off().on('click', function (e) {
    e.preventDefault();
    var ele = $(this).siblings('.custom-tooltip');
    e.stopPropagation();
    $('.custom-tooltip').not(ele).fadeOut();
    ele.fadeToggle();
  });
  $(window).on('click', function () {
    $('.custom-tooltip').fadeOut();
  });
  $('.custom-tooltip .btn-close-tooltip .close-icon').on('click', function (e) {
    e.preventDefault();
    $('.custom-tooltip').fadeOut();
  });
  $('.custom-tooltip').on('click', function (e) {
    e.preventDefault();
    e.stopPropagation();
  });
  $(".custom-tooltip .custom-tooltip-content .sec-paragraph p a").click(function(e) {
    var url = $(this).attr("href");
    var target = $(this).attr("target");     
    if (target == '_blank'){      
      window.open(url, target);     
    }
    else{            
      window.open(url, '_self');     
    }   
  });
    $(".package-range-slider-tab .packages-section .tooltip-btn").mouseover(function(){
      $(this).next().css({"display": "block"});
  });
  $(".package-range-slider-tab .packages-section .tooltip-btn").mouseout(function(){
      $(this).next().css({"display": "none"});
  });
});


