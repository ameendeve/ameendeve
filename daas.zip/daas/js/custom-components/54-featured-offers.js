
// click on the radio buttons categories
$('input[name="simple_categories"]').click(function () {
    if ($(this).attr("data-label") == 'allcategories') {
        $(".foffers-box").removeClass('active');
        $(".foffers-box").removeClass('hide');
    } else if ($(this).attr("data-label") !== 'allcategories') {
        var singleinputAttribute = $(this).attr("data-label");
        $("#filter-area .foffers-box").each(function (index, value) {
            if ($(value).attr('categoryname') === singleinputAttribute) {
                $(value).removeClass('hide');
                $(value).addClass('active');
            } else {
                $(value).removeClass('active');
                $(value).addClass('hide');
            }
        });
    }
}); // getting length of all elements with attribute name 'categoryname'

var allboxes = $(".with-filters .foffers-box[categoryname]").length;
$('input[data-label="allcategories"] + label .badge').html(allboxes); // filter mobile view popup open close

function filtersMobileView(thisValue) {
    if (window.innerWidth < 992) {
        var currentElement = $(thisValue).attr('data-label');

        if (currentElement) {
            $('.responsive-' + currentElement).addClass('mobileViewActive');
            $('body').addClass('freeze');
        }
    }
}

$('.filter-compare-sort-section a').off('click').on('click', function () {
    filtersMobileView(this);
}); // to make filters popup in-active ( hide )in mobile view

$('.filter-close').off('click').on('click', function () {
    $('.responsive-filters').removeClass('mobileViewActive');
    $('.responsive-sort').removeClass('mobileViewActive');
    $('body').removeClass('freeze');
}); // Reset Button Function

$("#resetbtn").click(function () {
    var getAllCategoriesCard = $(".with-filters .foffers-box[categoryname]");
    $(getAllCategoriesCard).show();
});
$(".eand-filter-wrapper.third-variation .vertical-accordion-list-wrap .accordion-button").off('click').on("click", function (e) {
    var attrtab = $(this).attr("data-bs-target");
    $(".vertical-accordion-list-wrap .accordion-button").addClass("collapsed");
    $(this).removeClass("collapsed");
    $(".eand-filter-wrapper.third-variation .content-wrapper .accordion-item .accordion-collapse").removeClass("show");
    $(".eand-filter-wrapper.third-variation .content-wrapper .accordion-item").find(attrtab).addClass("show");
}); // Calculating Number of Boxes under each category

function calculateOffersCategorySize(brandCat) {
    var allOfferCategories = $(".foffers-box[categoryname='" + brandCat + "']").length;
    $(".featured-offers .checkboxes-wrap input + label .badge[cat='" + brandCat + "']").each(function (index, value) {
        $(this).html(allOfferCategories);
    });
}

$(document).ready(function () {
    $('.featured-offers .checkboxes-wrap input + label .badge').each(function (index, value) {
        var brandCat = $(this).attr('cat');
        console.log(brandCat);
        calculateOffersCategorySize(brandCat);
    });
});