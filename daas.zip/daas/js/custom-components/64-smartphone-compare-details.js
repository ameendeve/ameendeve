"use strict";

$(".smartphone-compare-details-wrap input[name='smartphone-card-input']").click(function(){
    var selectedMobileBtn = $(this).val();
    $(".card-btn").hide();
    $(".smartphone-compare-details-wrap ."+selectedMobileBtn).show();
  });
