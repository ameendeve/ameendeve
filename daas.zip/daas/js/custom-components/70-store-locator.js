"use strict";

/**
 * v20180725
 */

      if (document.getElementById("store-locator-wrapper-map") !== null) {
        var isJson = function isJson(str) {
          try {
            JSON.parse(str);
          } catch (e) {
            return false;
          }

          return true;
        };

        var initGoogleMap = function initGoogleMap(position, zoom, disableui) {
          map = new google.maps.Map(document.getElementById('store-locator-map'), {
            center: position,
            zoom: zoom,
            scrollwheel: false,
            zoomControl: true,
            disableDefaultUI: disableui
          });
        };
        /**
         * Initialize Google Maps and Places Autocomplete
         */


        var initAutocomplete = function initAutocomplete() {
          var input = document.getElementById('pac-input-store-locator');
          autocomplete = new google.maps.places.Autocomplete(input);
          autocomplete.bindTo('bounds', map);
          autocomplete.setTypes(['address']);
          autocomplete.setComponentRestrictions({
            'country': ['ae']
          });
          positionOnMyLocation(); // set the listener for place changes event

          autocomplete.addListener('place_changed', PlacesAutocompleteChange);
        };
        /**
         * Handle the Places Autocomplete selection
         */


        var PlacesAutocompleteChange = function PlacesAutocompleteChange() {
          myMarker.setVisible(false);
          var place = autocomplete.getPlace();

          if (!place.geometry) {
            // window.alert("Autocomplete's returned place contains no geometry")
            return;
          } // If the place has a geometry, then present it on a map.


          if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
            map.setZoom(9);
          } else {
            map.setCenter(place.geometry.location);
            map.setZoom(10); // Why 17? Because it looks good.
          }

          myMarker.setIcon({
            url: currentUrlPath + 'ICO_My position.svg',
            size: new google.maps.Size(90, 90),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(45, 90)
          });
          myMarker.setPosition(place.geometry.location);
          myMarker.setVisible(true); // set the current location

          currentLocation = place.geometry.location; // if the store are not yet loaded, then load them, expand the map and show the results

          if (!storesLoaded) {
            // expand the map
            $('.map-container > .background-map').removeClass('closed').addClass('opened'); // show the results and navbar

            $('.store-locator-wrap .switch-store-locator').removeClass('hidden');
            getStores(map);
          }
        };

        var displayLocation = function displayLocation(lat1, lng1) {
          var geocoder = new google.maps.Geocoder();
          var latlng = {
            lat: parseFloat(lat1),
            lng: parseFloat(lng1)
          };
          geocoder.geocode({
            'location': latlng
          }, function (results, status) {
            if (status === 'OK') {
              if (results[0]) {
                $('#pac-input-store-locator').val(results[0].formatted_address);
              } else {
                window.alert('No results found');
              }
            } else {
              window.alert('Geocoder failed due to: ' + status);
            }
          });
        };
        /**
         * Position the map on the current user position (if avail.) or the configured center,
         * and retrieve the list of store nearby.
         */


        var positionOnMyLocation = function positionOnMyLocation() {
          $('.map-container > .background-map').removeClass('closed').addClass('opened');
          map.center = currentLocation;
          map.zoom = 13;
          map.disableDefaultUI = true; // Try HTML5 geolocation.

          if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
              var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
              };
              currentLocation = pos; // update my current position

              displayLocation(pos.lat, pos.lng);
              map.setCenter(pos);
              myMarker.setPosition(pos);
              myMarker.setVisible(true);
            }, function () {
              // position to the configured center
              currentLocation = defaultCenterPosition;
            }, {});
          } else {
            // position to the configured center
            currentLocation = defaultCenterPosition;
          } // --[Load stores in google maps from a json file]---------------------------------------------


          $('.store-locator-wrap .switch-store-locator').removeClass('hidden');
          getStores(map); // --------------------------------------------------------------------------------------------
        };
        /**
         * Call the backend to retrieve the stores date, and for each store
         * @param map
         */


        var getStores = function getStores(map) {
          $('.loader-disable-screen').show();
          var categoryMap = {
            'store-business': 'BusinessCenter'
          };
          /* eslint-disable quote-props */

          var iconMap = {
            'BusinessCenter': 'Locator_active.png'
          };
          var colorMap = {
            'BusinessCenter': 'store-business'
          };
          $.ajax({
            type: 'GET',
            url: "/content/dam/etisalat/smb-revamp/storesnew.json",
            dataType: 'json',
            // cache: true, WORKS ONLY FOR GET,HEAD requests http://api.jquery.com/jQuery.ajax/
            encode: true
          }).done(function (json) {
            $('.loader-disable-screen').hide();

            if (!json.success) {
              var errorEl = '<div class="error"><h4>Sorry we can not get the stores at the moment. Please retry later.</h4></div>';
              $('#store-locator-map').append(errorEl);
              return false;
            }

            var storeLocatorData = isJson(json.data) === false ? json.data : JSON.parse(json.data);

            if (setStoreData !== 'all') {
              _.remove(storeLocatorData, function (n) {
                return n.type !== categoryMap[setStoreData];
              });
            } // clean markers from map


            for (var i = 0; i < markers.length; i++) {
              markers[i].setMap(null);
            }

            markers = []; // cycle json and place markers

            $.each(storeLocatorData, function (key, data) {
              var latLng = new google.maps.LatLng(data.lat, data.lng); // Creating a marker and putting it on the map

              var marker = new google.maps.Marker({
                position: latLng,
                map: map,
                title: data.storename,
                icon: {
                  url: currentUrlPath + iconMap[data.type],
                  size: new google.maps.Size(36, 36),
                  scaledSize: new google.maps.Size(36, 36)
                },
                storeid: data.externalLocationId
              });
              /**
               * Marker on click event
               */

              marker.addListener('click', function () {
                var listArr = $('.result-slide .result-item-container');
                var storeEleID = marker.storeid;

                function searchID(id) {
                  resetClasses();
                  $('.sidebar-result-container').addClass('sidebar-result-mobile');
                  $(listArr).each(function (index, ele) {
                    if ($(ele).find('.desc-short').data('storeid') === id) {
                      $(ele).addClass('open-detail');
                      $(ele).find('.desc-long').css('display', 'block');
                      $('.open-detail')[0].scrollIntoView({
                        behavior: "smooth",
                        // or "auto" or "instant"
                        block: "start" // or "end"

                      });
                    }
                  });
                }

                function resetClasses() {
                  $('.sidebar-result-container').removeClass('sidebar-result-mobile');
                  $('.result-slide .result-item-container').removeClass('open-detail');
                  $('.result-slide .result-item-container .desc-long').css('display', 'none');
                }

                searchID(storeEleID);

                for (var j = 0; j < markers.length; j++) {
                  markers[j].setIcon(currentUrlPath + "Locator_active.png");
                }

                marker.setIcon(currentUrlPath + "selected-marker.png");
              });
              markers.push(marker);
            });
            var temp = {
              items: storeLocatorData
            }; // set the correct icon depending of the type

            _.forEach(temp.items, function (item) {
              item.iconPath = currentUrlPath + iconMap[item.type.replace(/ +/g, "")];
              item.color = colorMap[item.type];
            });

            _.templateSettings = {
              evaluate: /<#([\s\S]+?)#>/g,
              interpolate: /<#=([\s\S]+?)#>/g,
              escape: /<#-([\s\S]+?)#>/g
            };

            var compiledTemplate = _.template($('#store-locator-result-item-template').html());

            $('.store-locator-wrap .result-slide').html(compiledTemplate(temp)); // scroll to top "onclick"

            $('.result-item-container').on('click', function (event) {
              var target = $('.result-item-container:first-child');

              if (target.length) {
                event.preventDefault();
                $(this.div).stop().animate({
                  scrollTop: target.offset().top
                }, 1000);
              }
            });
            /**
             * open result details
             * @type {*|jQuery|HTMLElement}
             */

            var resultAccordion = $('.result-item-container .desc-short');
            resultAccordion.click(function (e) {
              e.preventDefault();
              var pressedButton = $(this);
              var actualWrapper = pressedButton.closest('.result-item-container');
              var storeid = $(this).data('storeid').toString();

              if (actualWrapper.hasClass('open-detail')) {
                actualWrapper.find('.desc-long').slideUp(300);
                actualWrapper.removeClass('open-detail');
              } else {
                actualWrapper.find('.desc-long').slideDown(300);
                actualWrapper.addClass('open-detail');
              }

              $('.location-details .more-details').click(function (e) {
                e.preventDefault(); // myStoreClick($('.result-item-container .desc-short').data('storeid'));

                myStoreClick(storeid);
              });
            }); // ------------------ open result More details

            var moreDetailsAccordion = $('.result-item-container .desc-long .location-details a.more-details');
            moreDetailsAccordion.click(function (e) {
              e.preventDefault();
              var pressedButton = $(this);
              var actualWrapper = pressedButton.closest('.result-main-container'); // var sidebarImage = $('#sidebar-icon');

              if (actualWrapper.hasClass('open-more-detail')) {
                actualWrapper.find('.more-details-box').fadeIn(300);
                actualWrapper.removeClass('open-more-detail');
              } else {
                actualWrapper.find('.more-details-box').fadeOut(300);
                actualWrapper.addClass('open-more-detail');
              }
            });
            return true;
          });
        };
        /**
         * Trigger the marker click event
         * @param id
         */


        var myStoreClick = function myStoreClick(id) {
          // alert('testo:'+id)
          var marker = _.find(markers, function (item) {
            return item.storeid.valueOf() === parseInt(id.valueOf());
          }); // console.log('marker.storeid:' + marker.storeid)


          currentLocation = marker.position;
          map.setCenter(marker.getPosition());
          google.maps.event.trigger(marker, 'click');
        };

        var setStoreData = "store-business";
        var defaultCenterPosition = window.appConfig.maps.center; // { lat: 25.208549, lng: 55.271945 };

        var currentLocation = defaultCenterPosition;
        var map;
        var markers = [];
        var storesLoaded = false;
        var myMarker;
        var autocomplete; // var currentUrlPath = window.location.href.substring(0, window.location.href.lastIndexOf('/'));

        var currentUrlPath = window.location.origin + window.appConfig.maps.customMarkerBaseUrl; // ---------------------------------------------------------
        // Common functions
        // ---------------------------------------------------------

        /**
         * Custom format for Select2
         * @param data
         * @returns {*}
         */

        /**
         * Initialize Google Maps
         * @param position
         * @param zoom
         * @param disableui
         * @returns {*}
         */

        $("#pac-input-store-locator").on("keyup", function () {
          var inputStoreValue = this.value.toLowerCase().trim();
          $(".result-slide .result-item-container").show().filter(function () {
            return $(this).text().toLowerCase().trim().indexOf(inputStoreValue) == -1;
          }).hide();
        });
        $(function () {
          /**
           * try to intercept enter key on selection
           */
          $(document).on('keydown', '#pac-input-store-locator', function (e) {
            if (e.which === 13) {
              $('#pac-input-store-locator').show();
              return false;
            }

            return true;
          });
          /**
           * Form submit
           * Prevent default behaviour to reload the page
           */

          $('#store-locator-form').submit(function (e) {
            e.preventDefault();
          });
          /**
           * Display check or clear buttons focus and focus-out
           */

          $('#pac-input-store-locator').focusin(function () {
            $('.check-seach-btn').css('display', 'table-cell');
            $('.clear-check-seach-btn').css('display', 'none');
          }).focusout(function () {
            $('.clear-check-seach-btn').css('display', 'table-cell');
            $('.check-seach-btn').css('display', 'none');
          });
          /**
           * Clean pac text
           */

          $('#store-locator-text-cleaner').click(function (e) {
            e.preventDefault();
            $('#pac-input-store-locator').val('');
          });
          /**
           * click on use my current location
           */

          $('#my-location-link').click(function (e) {
            // disable content in href
            e.preventDefault(); // by default center on Dubai

            positionOnMyLocation();
          });
        }); // ---------------------------------------------------------
        // START
        // ---------------------------------------------------------
        // Init Maps

        initGoogleMap(defaultCenterPosition, 10, true); // set my position marker

        myMarker = new google.maps.Marker({
          map: map,
          zoomControl: true,
          anchorPoint: new google.maps.Point(0, -29)
        });
        myMarker.setIcon({
          url: currentUrlPath + 'ICO_My position.svg',
          size: new google.maps.Size(90, 90),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(45, 90)
        });
        myMarker.setVisible(false); // init the maps and autocompelte

        initAutocomplete();
      }
