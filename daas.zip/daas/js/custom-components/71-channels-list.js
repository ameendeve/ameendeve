"use strict";

/**
 * v20180725
 */

      function initChannelCategoryCarousel() {
        $(document).find(".channels-category-wrap").each(function (index) {
          $(this).addClass('slideronPage' + index);
          var $compareCardCarousel = $(this);
          $compareCardCarousel.find(".swiper-pagination").addClass("compareCarousel" + index);
          var swiperSlideLength = $('.slideronPage' + index + " .channel-category-carousel .swiper-slide").length;
          $(this).addClass("swiper-with-" + swiperSlideLength + "-slides");

          if ($(window).width() > 992) {
            if (swiperSlideLength <= 8) {
              $(".slideronPage" + index).addClass("destroyed");
              $(".slideronPage" + index).find(".swiper-wrapper").children().removeClass("swiper-slide");
              $(".slideronPage" + index).find(".swiper-navigation").addClass("deactive");
            } else {
              var $carouselSliderwithProgress = new Swiper(".slideronPage" + index + " .channel-category-carousel", {
                slidesPerView: 8,
                slidesPerGroupSkip: 1,
                pagination: {
                  el: ".swiper-pagination",
                  clickable: true,
                  type: "progressbar"
                },
                breakpoints: {
                  1099: {
                    slidesPerView: 8,
                    spaceBetween: 24
                  },
                  768: {
                    slidesPerView: 6,
                    spaceBetween: 10,
                    pagination: {
                      type: "progressbar",
                      clickable: true
                    }
                  },
                  100: {
                    slidesPerView: 3,
                    spaceBetween: 0
                  }
                }
              });
            }
          } else {
            var $carouselSliderwithProgress = new Swiper(".slideronPage" + index + " .channel-category-carousel", {
              slidesPerView: 8,
              slidesPerGroupSkip: 1,
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
                type: "progressbar"
              },
              breakpoints: {
                1099: {
                  slidesPerView: 8,
                  spaceBetween: 24
                },
                768: {
                  slidesPerView: 6,
                  spaceBetween: 10,
                  pagination: {
                    type: "progressbar",
                    clickable: true
                  }
                },
                100: {
                  slidesPerView: 3,
                  spaceBetween: 0
                }
              }
            });
          }
        });
      } // register the event handlers


      $(document).ready(function () {
		$('.channels-listing-wrap .channels-listing ').removeClass('aos-animate');
        $(".channels-listing").hide();
        $(".channels-listing").slice(0,8).show();
        setTimeout(function() {
          $('.channels-listing-wrap .channels-listing').addClass('aos-animate');
        }, 100);       
        $(".channel-category").click(function () {
          //var channelName = $(this).attr("data-label");
          var channelName = $(this).find('.sec-subheadings h5').text().trim();
          $('.channel-name').text(channelName);
          $('.channel-category').removeClass('active');
          $(this).addClass('active');

          if ($(this).attr("data-label") == 'all') {
            $(".channels-listing").removeClass('active');
            $(".channels-listing").removeClass('hide');
            var allBoxLenght = $(".channels-listing").length;

            if (allBoxLenght >= 8) {
              $('.load-more-btn').show();
              $(".channels-listing").hide();
              $(".channels-listing").slice(0, 8).show();
            } else {
              $('.load-more-btn').hide();
              $(".channels-listing").show();
            }
          } else if ($(this).attr("data-label") !== 'all') {
            var categoryValue = $(this).attr("data-label");
            $('.channel-name').text(channelName);
            $(".channels-listing[categoryname='" + categoryValue + "']").siblings().removeClass('active');
            $(".channels-listing[categoryname='" + categoryValue + "']").siblings().addClass('hide');
            $(".channels-listing[categoryname='" + categoryValue + "']").addClass('active');
            var boxLenght = $(".channels-listing.active").length;

            if (boxLenght >= 8) {
              $('.load-more-btn').show();
              $(".channels-listing.active").hide();
              $(".channels-listing.active").slice(0, 8).show();
            } else {
              $('.load-more-btn').hide();
              $(".channels-listing.active").show();
            }
          }
        }); // loadmore

        $(".load-more-btn").click(function (e) {
          e.preventDefault();

          if ($('.channel-category.active').attr("data-label") == 'all') {
            $(".channels-listing:hidden").show();

            if ($(".channels-listing:hidden").length == 0) {
              $(".load-more-btn").hide();
            }
          } else if ($('.channel-category.active').attr("data-label") !== 'all') {
            $(".channels-listing.active:hidden").show();

            if ($(".channels-listing.active:hidden").length == 0) {
              $(".load-more-btn").hide();
            }
          }
        });
        initChannelCategoryCarousel(); // list and grid view

        $('.grid-view-menu .in-active').hide();
        $('.list-view-menu .active').hide();
        $('.list-view-menu').click(function () {
          $('.channels-listing-wrap').addClass('list-view');
          $('.list-view-menu .active').show();
          $('.list-view-menu .in-active').hide();
          $('.grid-view-menu .in-active').show();
          $('.grid-view-menu .active').hide();
        });
        $('.grid-view-menu').click(function () {
          $('.channels-listing-wrap').removeClass('list-view');
          $('.list-view-menu .active').hide();
          $('.list-view-menu .in-active').show();
          $('.grid-view-menu .in-active').hide();
          $('.grid-view-menu .active').show();
        }); // channels count

        var channelCount = $('.channels-listing').length;
        $('.channel-count span').text(channelCount);
        $(".channel-category").click(function () {
          if ($('.channel-category.active').attr("data-label") == 'all') {
            var channelCount = $('.channels-listing').length;
            $('.channel-count span').text(channelCount);
          } else if ($('.channel-category.active').attr("data-label") !== 'all') {
            var channelCount = $('.channels-listing.active').length;
            $('.channel-count span').text(channelCount);
          }
        });
		//trigger register the event handlers of aos animation on click

        $('.grid-view-menu,.list-view-menu').on('click', function () {
          $('.channels-listing-wrap .channels-listing ').removeClass('aos-animate');
          setTimeout(function () {
            $('.channels-listing-wrap .channels-listing').addClass('aos-animate');
          }, 800);
        });
      });
