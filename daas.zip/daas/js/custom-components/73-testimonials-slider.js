"use strict";

/**
 * v20180725
 */

      function testimonialslider() {
        $(document).find(".testimonials-slider").each(function (index) {
          $(this).addClass("testimonials-slider-section" + index);
          var $Testimonialslidernav = $(this);
          var testimonialslidermodule = new Swiper(".testimonials-slider-section" + index + " .swiper", {
            navigation: true,
            loop: false,
            autoplay: false,
            slidesPerView: 1,
            centeredSlides: true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true
            }
          });
        });
      } // register the event handlers


      $(document).ready(function () {
        testimonialslider();
      });
