function initScrollingImageSliders() {
  $(".scrolling-images").each(function (index) {
    const $container = $(this);
    const sliderClass = `scrollingimg-slider${index}`;
    $container.addClass(sliderClass);

    let enableSlider = true;
    const $slides = $container.find(".swiper-slide");
    const slideCount = $slides.length;

    if ($(window).width() > 1025) {
      if (slideCount <= 3) {
        enableSlider = false;
        $container.find(".swiper-wrapper").addClass("justify-content-center");
      }
    }

    new Swiper(`.${sliderClass} .swiper`, {
      slidesPerView: 1.2,
      centeredSlides: enableSlider,
      loop: enableSlider,
      spaceBetween: 16,
      slideToClickedSlide: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      breakpoints: {
        640: {
          slidesPerView: 2.4,
          spaceBetween: 16,
        },
        768: {
          slidesPerView: 2.8,
          spaceBetween: 16,
        },
        1024: {
          slidesPerView: 3.4,
          spaceBetween: 24,
        },
        1200: {
          slidesPerView: 3.7,
          spaceBetween: 24,
        },
      },
    });
  });
}

$(document).ready(initScrollingImageSliders);