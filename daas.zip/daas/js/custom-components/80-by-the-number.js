/**
 * By the Number
 */
 $(document).ready(function () {
    $('.by-the-numner .right-section .counter-box .count').each(function () {
      $(this).prop('Counter', 0).animate({
        Counter: $(this).text()
      }, {
        duration: 3000,
        easing: 'swing',
        step: function step(now) {
          $(this).text(Math.ceil(now));
        }
      });
    });
  });