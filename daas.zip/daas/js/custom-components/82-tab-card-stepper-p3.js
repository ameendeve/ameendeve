/**
 * v20221013
 * Tab Card Stepper P3
 */
 $(document).ready(function () {
    $(".tab-card-stepper-p3 .accordion-button").off('click').on("click", function (e) {
      var attrtab = $(this).attr("data-bs-target");
      $(".accordion-button").addClass("collapsed");
      $(this).removeClass("collapsed");
      $(".tab-card-stepper-p3-content .accordion-item .accordion-collapse").removeClass("show");
      $(".tab-card-stepper-p3-content .accordion-item").find(attrtab).addClass("show");
    });
	//trigger register the event handlers of aos animation on click        

        $('.tab-card-stepper-p3 .accordion-button').on('click', function () {
          $('.tab-card-stepper-p3-content .accordion-item *').removeClass('aos-animate');
          setTimeout(function () {
            $('.tab-card-stepper-p3-content .accordion-item *').addClass('aos-animate');
          }, 800);
        });
  });