/*
 * Flip Cards
*/
$(document).ready(function () {
  //flip card onclick card
  $(".flip-card-open").click(function () {
    $(this).closest('.flip-cards').find('.flipped-card').removeClass('flipped-card');
    $(this).parent().closest('.flip-card-box').addClass('flipped-card');
  });
  $(".flip-card-close").click(function () {
    $(this).parent().closest('.flip-card-box').removeClass('flipped-card');
  });
});