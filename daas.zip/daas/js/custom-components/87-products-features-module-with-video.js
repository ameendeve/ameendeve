"use strict";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * v20180725
 */
        function productfeaturesvideomodule() {
          $(document).find(".products-features-module-with-video").each(function (index) {
              $(this).addClass("product-features-slider" + index);
              var $productfearureslider = $(this);
              $productfearureslider.find(".swiper-button-next").addClass("pr-next-arrow" + index);
              $productfearureslider.find(".swiper-button-prev").addClass("pr-prev-arrow" + index);
              $productfearureslider.find(".swiper-pagination").addClass("prod-pag" + index);
              var productfearureslidernav = new Swiper(".product-features-slider" + index + " .swiper",{
                  navigation: true,
                  loop: true,
                  autoplay: false,
                  slidesPerView: 1,
                  centeredSlides: true,
                  pagination: {
                    el: ".swiper-pagination.prod-pag" + index,
                    clickable: true,
                  },
                  navigation: {
                    nextEl: ".swiper-button-next.pr-next-arrow" + index,
                    prevEl: ".swiper-button-prev.pr-prev-arrow" + index,
                    clickable: true,
                  },
                }
              );
            });
        }
      $('.features-video-link').on('click', function (e) {
        e.preventDefault(); // var modalCTA = $(this).next('.youtube-popup-container');
        // modalCTA.modal().show();
        // $(".swiper,.swiper-wrapper,.swiper-slide").addClass("fswvideo");
      });
      if (document.getElementsByClassName("youtube-popup-container") !== null) {
        var productvideoslider = document.getElementsByClassName("youtube-popup-container");
        for (let i = 0; i < productvideoslider.length; i++) {
          productvideoslider[i].addEventListener("click", function () {
            var src = $(this).find('iframe').attr('src');
            $(this).find('iframe').attr('src', '');
            $(this).find('iframe').attr('src', src.replace('autoplay=1', ''));
          });
        }
      }
      $(document).ready(function () {
        productfeaturesvideomodule();
      });
