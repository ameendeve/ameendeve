"use strict";

/**
 * v20191225
 */

      $(document).find(".article-share-wrap").each(function (index) {
        $(this).addClass('linkBox' + index);
        var getLink = window.location.href;
        $('.linkBox' + index + " .linkText").val(getLink);
        console.log($('.linkBox' + index + " .linkText"));
        $('.linkBox' + index + ' .copyLink').click(function () {
          $('.linkBox' + index + " .linkText").val(getLink).select();
          document.execCommand('copy');
          $('.linkBox' + index + ' .form-share').addClass('copied');
        });

        var getWindowOptions = function getWindowOptions() {
          var width = 500;
          var height = 350;
          var left = window.innerWidth / 2 - width / 2;
          var top = window.innerHeight / 2 - height / 2;
          return ['resizable,scrollbars,status', 'height=' + height, 'width=' + width, 'left=' + left, 'top=' + top].join();
        };

        $('.linkBox' + index + ' .shareFacebookk').click(function (e) {
          e.preventDefault();
          shareLink('ShareOnFb', 'Hey everyone, come & see this link!', 'https://www.facebook.com/sharer/sharer.php?u=', e.target);
        });
        $('.linkBox' + index + ' .shareLinkedIn').click(function (e) {
          e.preventDefault();
          shareLink('ShareOnLinkedIn', 'Hey everyone, come & see this link!', 'http://www.linkedin.com/shareArticle?mini=true&url=', e.target);
        });
        $('.linkBox' + index + ' .shareTwitter').click(function (e) {
          e.preventDefault();
          shareLink('ShareOnTwitter', 'Hey everyone, come & see this link!', 'https://twitter.com/intent/tweet?url=', e.target);
        });
        $('.linkBox' + index + ' .shareInsta').click(function (e) {
          e.preventDefault();
          shareLink('ShareOnInstaGram', 'Hey everyone, come & see this link!', '"https://www.instagram.com/?url=', e.target);
        });

        var shareLink = function shareLink(title, text, url, target) {
          var text = encodeURIComponent(text);
          var shareUrl = url + getLink + '&text=' + text;
          target.href = shareUrl; // 1

          var win = window.open(shareUrl, title, getWindowOptions());
          win.opener = null; // 2
        };
      });
      $('.dropdown-menu').on('click', function (e) {
        e.stopPropagation();
      });
