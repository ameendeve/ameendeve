"use strict";

/**
 * Icon Cards
 */

      $(document).ready(function () {
        $(".icon-card-box").click(function () {
          $(this).toggleClass("selected");
        });
      });
