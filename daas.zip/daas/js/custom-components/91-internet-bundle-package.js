/* 
===========================
   91 Internet bundle package
===========================
*/
      if (sessionStorage.getItem('activeNumbers') === null) {
      } else {
        var storedArray = JSON.parse(sessionStorage.getItem('activeNumbers'));
        // var storedArray = ["047894240", "047894241", "047894242", "047894243", "047894244", "047894245", "047894246", "047894247", "047894248", "047894249"]
        console.log(storedArray.length)
        // removing table view swiper slides based on passed numbers
        $(
          '.compare-feature-cards-wrap .feature-cards-box .swiper-wrapper .swiper-slide'
        ).each(function (i, obj) {
          let numberofCard = $(obj)
            .find('.sec-secondary-headings.pname h4')
            .text()
            .replace(/[^0-9]/g, '');
            if (numberofCard < storedArray.length && storedArray.length < 10) {
              $(obj).removeClass('recommended');
              $(obj).remove();
            } else if (storedArray.length >= 10) {
              if($(obj).is(':last-child')) {
                // console.log('allow last child')
              } else {
                $(obj).removeClass('recommended');
                $(obj).remove();
              }
            }
        });

        // removing tabs anchor based on passed numbers
        $(
          '.internet-bundle-package.changePhoneNumbers .package-range-slider-wrap .package-range-slider-tab .tabs-section .nav-tabs-section .nav-tabs .nav-item'
        ).each(function (i, obj) {
          let numberofCard = $(obj)
            .children('a')
            .text()
            .replace(/[^0-9]/g, '');
          // console.log(numberofCard)
          if (numberofCard < storedArray.length && storedArray.length < 10) {
            $(obj).removeClass('recommended');
            if ($(obj).find('a.active')) {
              $(obj).find('a.active').removeClass('active');
            }
            $(obj).remove();
          } else if (storedArray.length >= 10) {
            if($(obj).is(':last-child')) {
              $(obj).find('a.active').addClass('active');
              // console.log('allow last child')
            } else {
              $(obj).remove();
            }
          }
        });

        // removing tabs  based on passed numbers
        $(
          '.internet-bundle-package.changePhoneNumbers .package-range-slider-wrap .package-range-slider-tab .tabs-section .tab-content-section .tab-content>.tab-pane'
        ).each(function (i, obj) {
          let numberofCard = $(obj)
            .find(
              '.justify-content-center > .col-lg-10 > .sec-main-headings > h4'
            )
            .text()
            .replace(/[^0-9]/g, '');
          // console.log(numberofCard)
          if (numberofCard < storedArray.length && storedArray.length < 10) {
            $(obj).removeClass('active');
            $(obj).removeClass('show');
            $(obj).remove();
          } else if (storedArray.length >= 10) {
            if($(obj).is(':last-child')) {
              // console.log('allow last child')
            } else {
              $(obj).removeClass('active');
              $(obj).removeClass('show');
              $(obj).remove();
            }
          }
        });

        // activating first tab after removing tabs based on packages
        $(
          '.internet-bundle-package.changePhoneNumbers .package-range-slider-wrap .package-range-slider-tab .tabs-section .tab-content-section .tab-content>.tab-pane:first-child'
        ).addClass('active');
        $(
          '.internet-bundle-package.changePhoneNumbers .package-range-slider-wrap .package-range-slider-tab .tabs-section .tab-content-section .tab-content>.tab-pane:first-child'
        ).addClass('show');
      }

      var rangeslidermodule = document.getElementsByClassName(
        'internet-bundle-package'
      );
      if (rangeslidermodule.length > 0) {
        //All code insert here ..
        $('.switch-btn-wrap a').on('click', function (e) {
          e.preventDefault();
          $('.toggle-view-btn').toggleClass('active');
          $('.rangeslider-view-btn').toggleClass('active');
          $('.package-range-slider-wrap').toggleClass('active');
          $('.package-slider-wrap').toggleClass('active');
        }); // animation for tab selector

        $('.tab-head .nav-tabs a').click(function () {
          var tabeposition = $(this).parent().position();
          var tabewidth = $(this).parent().width();
          if (tabeposition != null) {
            $('.tab-head .selector').css({ left: +tabeposition.left });
          }
        });
        var actWidth = $('.tab-head .nav-tabs')
          .find('.active')
          .parent('li')
          .width();
        var actPosition = $('.tab-head .nav-tabs .active').position();
        if (actPosition != null) {
          $('.tab-head .selector').css({ left: +actPosition.left });
        } // find recommended class on tabs

        $('.nav-tabs li').click(function () {
          if ($(this).hasClass('recommended')) {
            $(this)
              .parents('.package-range-slider-wrap')
              .addClass('recommended-bundle');
          } else {
            $(this)
              .parents('.package-range-slider-wrap')
              .removeClass('recommended-bundle');
          }
        });
      }