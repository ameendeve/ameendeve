function internetbundlecard() {
  $(document).find(".internetbundlecardslide").each(function (index) {
    $(this).addClass("internetbundslide" + index);
    var $contextNavigation = $(this);
    $contextNavigation.find(".swiper-button-next").addClass("IBRight" + index);
    $contextNavigation.find(".swiper-button-prev").addClass("IBLeft" + index);
    $contextNavigation.find(".swiper-pagination").addClass("cpPagination" + index);
    var etiSlidesCount = $contextNavigation.find('.swiper-slide').length;
    $(this).addClass("IB-tiles-" + etiSlidesCount);
    var contextNavigationlider = new Swiper(".internetbundslide" + index + " .swiper", {
      slidesPerView: 4,
      pagination: {
        el: ".swiper-pagination.cpPagination" + index,
        clickable: true,
        type: "progressbar",
      },
      navigation: {
        nextEl: ".swiper-button-next.IBRight" + index,
        prevEl: ".swiper-button-prev.IBLeft" + index,
        clickable: true,
      },
      breakpoints: {
        200: {
          slidesPerView: 1,
          spaceBetween: 16,
          pagination: {
            type: "bullets",
            clickable: true,
          },
        },
        768: {
          slidesPerView: 2,
          spaceBetween: 16,
        },
        992: {
          slidesPerView: 3,
          spaceBetween: 16,
        },
        1224: {
          slidesPerView: 4,
        }
      },
    });
  });
}
// register the event handlers
$(document).ready(function () {
  var sliderlength = $(".internetbundlecardslide .swiper-slide").length;
  console.log(sliderlength);
  if ($(window).width() > 1224) {
    if (sliderlength > 4) {
      internetbundlecard();
    }
  } else {
    internetbundlecard();
  }
});
