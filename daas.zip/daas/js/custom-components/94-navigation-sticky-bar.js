     
window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset;
  //console.log(currentScroll);
  if (currentScroll > 150) {
    $(".navigation-sticky-bar").addClass("fixed-top");
    $("body").addClass("ibstickynav");
  } else {
    $(".navigation-sticky-bar").removeClass("fixed-top");
    $("body").removeClass("ibstickynav");
  }
});
  $(document).ready(function () {
    if ($(window).width() < 992) {
  let isolated = "isolation";
      if(!$(".navigation-sticky-bar").hasClass(isolated)){
        $('.navbar-menu').hide();
        $(".exp-coll-arrow").click(function(){
          $('.navbar-menu').fadeToggle('500');
    $(this).toggleClass('expand');
        });
        $(".navbar-menu .navBar li").click(function(){
          $('.navbar-menu').fadeOut( '500' );
        });
      } else {
      }
    }


    // Add scrollspy
    $(".navbar-menu .navBar a[href^=\\#]").on('click', function (event) {
      // Make sure this.hash has a value before overriding default behavior
      if (this.hash !== "") {
        // Prevent default anchor click behavior
        //event.preventDefault();
        // Store hash
        var hash = this.hash;
        if ($(hash).length) {
          if ($(window).width() > 992) {
            $('html, body').animate({
              scrollTop: $(hash).offset().top - 152
            }, 300, function () {
              window.location.hash = hash;
            });
          } else {
            $('html, body').animate({
              scrollTop: $(hash).offset().top - 138
            }, 300, function () {
              window.location.hash = hash;
            });
          }
        }
        else {
          window.location.href = this.href;
        }
      }
    });
    var ehash = window.location.hash.substr(1);
    if (ehash !== "") {
      if ($(window).width() > 992) {

        $('html, body').animate({
          scrollTop: $('#' + ehash).offset().top - 152
        }, 50);
      } else {

        $('html, body').animate({
          scrollTop: $('#' + ehash).offset().top - 138
        }, 50);
      }
    }
    // Assign active class to nav links while scolling
    $(window).scroll(function () {

      var scrollDistance = $(window).scrollTop();
      if ($(window).width() > 992) {

        $('.page-section').each(function (i) {
          if ($(this).position().top - 152 <= scrollDistance) {
            $('.navbar-menu .navBar li.active').removeClass('active');
            $('.navbar-menu .navBar li').eq(i).addClass('active');
          }
        });
      } else {

        $('.page-section').each(function (i) {
          if ($(this).position().top - 138 <= scrollDistance) {
            $('.navbar-menu .navBar li.active').removeClass('active');
            $('.navbar-menu .navBar li').eq(i).addClass('active');
          }
        });

      }
    }).scroll();

  });

