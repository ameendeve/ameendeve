/* 
===========================
   98 Sticky Price Footer
===========================
*/

$(document).ready(function () {
    $(".view-summary-wrapper a").click(function(){
        $(this).toggleClass('active');
        $('.sticky-price-footer').find('.hide-section').slideToggle();              
    })
});
