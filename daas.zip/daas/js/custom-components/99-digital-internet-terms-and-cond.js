$(function() {
          $('#tandcoverlay a').on('click',function(){
            setTimeout(() => {
                $('#tandcoverlay a').removeClass('active');
                $(this).addClass('active');
            }, 50);

          })
      });
