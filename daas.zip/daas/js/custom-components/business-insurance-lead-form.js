import { FORM_SUCCESS, FORM_ERROR } from '../analytics/analytics';

  if (window.location.href.indexOf('error') !== -1) {
      $("#insuaranceleadform #dErrorMessage").removeClass('hidden');
  }

  // Google Event
  function googleClickEvent(dataObject) {
    if (typeof (window.dataLayer) !== "undefined") {
      dataLayer.push(dataObject);
    }
    console.log(dataObject)
  }

  function BusinessFormsErrorGoogle(msg) {
    var DisplayFormName = window.location.href;
    var errorMessage = $('.smbform .business-form-submitted.error').text();
    var object = {
      'event': 'lead_'  + msg,
      'form_id': "insuaranceLeadForm",
      'form_name': "insuaranceLeadForm",
      'currency': '',
      'value': '',
      'error_code': '',
      'error_message': errorMessage,
      'error_type': 'system_error',
      'items': {
        'item_id': '',
        'item_name': '',
        'item_category': '',
        'price': '',
      }
    }
    googleClickEvent(object);
  }

  function BusinessFormsSuccessGoogle(msg) {
    var DisplayFormName = window.location.href
    var object = {
      'event': 'lead_'  + msg,
      'form_id': "insuaranceLeadForm",
      'form_name': "insuaranceLeadForm",
      'currency': '',
      'value': '',
      'items': {
        'item_id': '',
        'item_name': '',
        'item_category': '',
        'price': '',
      }
    }
    googleClickEvent(object);
  }

  var $insuaranceLeadForm = $("#insuaranceleadform");
  var insuaranceLeadFormlang = $('html').attr('lang');
  var insuaranceLeadFormresultMessageContainer = $("#insuaranceleadform .business-form-submitted");
  var insuaranceLeadFormGeneralErrorMsg = window.location.href.indexOf(".ae/ar") > -1 ? "هناك شيء خاطئ، يرجى المحاولة في وقت لاحق" : "Something went wrong, please try again later";

  const $SUBMIT_CTA = $('#insuaranceleadform #btninsuaranceleadform');
  const currentURL = window.location.href;
  $SUBMIT_CTA.on('click', function () {
      if ($insuaranceLeadForm.valid() == false) {
          FORM_ERROR($insuaranceLeadForm, 'validation error');
          return false;
      }
  });
  var insuaranceLeadFormmessagelocal;
  var insuaranceLeadFormvalidateMessage = {
      en: {
          fullName: {
              required: "Name is required",
              number: "Name connot contain numbers",
              maxlength: "Name cannot be longer than 50 characters.",
              alphanumeric: "Letters only please",
              lettersonly: "Letters only please",
          },
      },
      ar: {
          fullName: {
              required: "يرجى كتابة الاسم ",
          },
          email: {
              required: "يرجى كتابة البريد الإلكتروني",
          }
      },
  };
  if (insuaranceLeadFormlang == "ar") {
      insuaranceLeadFormmessagelocal = insuaranceLeadFormvalidateMessage.ar;
  } else {
      insuaranceLeadFormmessagelocal = insuaranceLeadFormvalidateMessage.en;
  }

  function getFormData($insuaranceLeadForm) {
      var o = {};
      var a = $insuaranceLeadForm.serializeArray();
      $.each(a, function () {
        if (o[this.name]) {
          if (!o[this.name].push) {
            o[this.name] = [o[this.name]];
          }
          o[this.name].push(this.value || "");
        } else {
          o[this.name] = this.value || "";
        }
      });
      return o;
  }

  function showErrorMessageInsuaranceForm(text) {
      insuaranceLeadFormresultMessageContainer.text(text);
      insuaranceLeadFormresultMessageContainer.addClass("error");
      insuaranceLeadFormresultMessageContainer.removeClass("hidden");
  }

  $(document).ready(function () {
      $insuaranceLeadForm.validate({
          rules: {
              fullName: {
                  required: true,
                  realalphabeticlatinarabic: true,
                  maxlength: 248,
              },
              contactNumber: {
                  required: true,
                  digits: true,
                  pattern: /^(050|052|054|055|056|057|058)/,
                  minlength: 10,
                  maxlength: 10,
              },
              emailAddress: {
                  required: true,
                  email: true,
              },
              termsconditions: {
                  required: true
              }
          },
          errorPlacement:
              function (error, element) {
                  error.insertAfter(element);
              },
          messages: insuaranceLeadFormmessagelocal,
          submitHandler: function (form, event) {
              var dataObj = getFormData($insuaranceLeadForm);
              var formData = {
                  partyId: dataObj.partyId,
                  fullName: dataObj.fullName,
                  emailId: dataObj.emailAddress,
                  contactNumber: dataObj.contactNumber,
                  leadType: dataObj.leadType,
                  businessType: dataObj.businessType,
                  insuranceType: dataObj.insuranceType

              }
              let dataObjwithJson = {
                  ClientCaptchaValue: sessionStorage.getItem("gcresponse"),
                  TYPE: 'BUSINESS_INSURANCE_LEAD',
                  REQPAYLOAD: formData,
              };
              dataObjwithJson = JSON.stringify(dataObjwithJson, null, 2);
              console.log(dataObjwithJson)
              document.getElementById("btninsuaranceleadform").disabled = true;
              $.ajax({
                  type: 'POST',
                  url: $($insuaranceLeadForm).attr('action'),
                  data: dataObjwithJson.replace(/[\r\n]/gm, ''),
                  dataType: 'json',
                  headers: {
                      'content-type': 'application/json',
                      'x-calling-application': 'cms',
                  },
                  encode: true
              })
              .done(function (response) {
                  const fromData = getFormData($insuaranceLeadForm);
                  const authoredRedirectUrl = fromData[':redirect'] || `smb-thank-you-page.html`;

                  let RE_URL = '';
                  const ref = response?.leadReferenceId || '';

                  let path = window.location.pathname;
                  let page = path.split('/').pop();

                  if (window.location.search) {
                      RE_URL += `${window.location.search}&referenceNo=${ref}&formIDName=insuaranceleadform`;
                  } else {
                      RE_URL += `?referenceNo=${ref}&formIDName=insuaranceleadform`;
                  }
                  BusinessFormsSuccessGoogle('submit')
                  $(document).trigger('GA_FROM_TRACKING', { $type: 'submit' });
                  FORM_SUCCESS($insuaranceLeadForm, formData);
                  window.location.href = window.location.origin + window.location.pathname.replace(page, authoredRedirectUrl) + RE_URL; 
                  //window.location.href = window.location.href.replace(page, authoredRedirectUrl) + RE_URL;
                  return true;
              })
              .fail(submitErrorResponseInsuaranceForm);

              // return false to prevent normal browser submit and page navigation
              return false;
          },

      })
  });

  function submitErrorResponseInsuaranceForm(jqXHR, textStatus, error) {
      let errorText = (jqXHR.responseJSON && jqXHR.responseJSON.message) || error;
      showErrorMessageInsuaranceForm(insuaranceLeadFormGeneralErrorMsg);
      FORM_ERROR($insuaranceLeadForm, 'API error', errorText);
      BusinessFormsErrorGoogle('error');
  }
