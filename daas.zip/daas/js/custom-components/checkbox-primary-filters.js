$(document).ready(function () {
  // Show hide categories Function(re-called from select products cards)
  var getAllCategoriesCard = $(".checkbox-primary-filters-showhide > div");
  $(getAllCategoriesCard).hide();
  $('.checkbox-primary-filters input[name="how_you_like_to_pay"]').click(function () {
    var checkboxValues = [];
    $('.checkbox-primary-filters input[name="how_you_like_to_pay"]:checked').each(function (index, elem) {
      checkboxValues.push($(elem).val());
    });
    var getCurrentCategoryCard = [];
    console.log(checkboxValues, getCurrentCategoryCard);
    $(getAllCategoriesCard).hide();
    checkboxValues.forEach(function (checkBoxValues) {
      getCurrentCategoryCard.push($(".checkbox-primary-filters-showhide > div[sub-category~='" + checkBoxValues + "']"));
    });
    getCurrentCategoryCard.forEach(function (activeCard) {
      $(activeCard).show();
    });
  });
});