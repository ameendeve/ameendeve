// 65 compare Feature Cards Carousel Function
function initCompareFeatureCardCarousel() {
  $(document).find(".compare-feature-cards-wrap").each(function (index) {
      $(this).addClass('cfeaturePage' + index)
        var $compareCardCarousel = $(this);
        $compareCardCarousel.find(".swiper-pagination").addClass("cfeatureCarousel" + index);
        var swiperSlideLength = $('.cfeaturePage' + index + " .compare-feature-cards-carousel .swiper-slide").length;
        $compareCardCarousel.find(".swiper-button-next").addClass("featureCardsNext" + index);
        $compareCardCarousel.find(".swiper-button-prev").addClass("featureCardsPrev" + index);
        $compareCardCarousel.find(".swiper-pagination").addClass("featureCardsPagination" + index);

        $(this).addClass("swiper-with-" + swiperSlideLength + "-slides");
        if ($(window).width() > 1370) {
            if (swiperSlideLength <= 4) {
            $(".cfeaturePage" + index).addClass("destroyed");
            //$(".cfeaturePage" + index).find(".swiper-wrapper").addClass("row");
            $(".cfeaturePage" + index)
                .find(".swiper-wrapper.row")
                .children()
                .removeClass("swiper-slide");
                $(".cfeaturePage" + index)
                .find(".swiper-navigation")
                .addClass("deactive");
            } else {
                $(".cfeaturePage" + index).find(".swiper-wrapper").removeClass("row");
                var $carouselSliderwithProgress = new Swiper(
                    ".cfeaturePage" + index + " .compare-feature-cards-carousel",
                    {
                        loop: false,
                        slidesPerGroupSkip: 1,
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev",
                        },
                        breakpoints: {
                            1370: {
                                slidesPerView: 4.25,
                                spaceBetween: 16,
                            },
                            1170: {
                                slidesPerView: 3.2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2.25,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                                pagination: {
                                    el: ".swiper-pagination",
                                    clickable: true,
                                    type: "bullets"
                                },
                            }
                        }
                    }
                );
            }
        }
        else if ($(window).width() > 1170 ) {
            if (swiperSlideLength <= 3) {
                $(".cfeaturePage" + index).addClass("destroyed");
            //$(".cfeaturePage" + index).find(".swiper-wrapper").addClass("row");
            $(".cfeaturePage" + index)
                .find(".swiper-wrapper.row")
                .children()
                .removeClass("swiper-slide");
                $(".cfeaturePage" + index)
                .find(".swiper-navigation")
                .addClass("deactive");
            } else {
                $(".cfeaturePage" + index).find(".swiper-wrapper").removeClass("row");
                var $carouselSliderwithProgress = new Swiper(
                    ".cfeaturePage" + index + " .compare-feature-cards-carousel",
                    {
                        loop: false,
                        slidesPerGroupSkip: 1,
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev",
                        },
                        breakpoints: {
                            1370: {
                                slidesPerView: 4.25,
                                spaceBetween: 16,
                            },
                            1170: {
                                slidesPerView: 3.2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2.25,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                                pagination: {
                                    el: ".swiper-pagination",
                                    clickable: true,
                                    type: "bullets"
                                },
                            }
                        }
                    }
                );

                var $carouselSliderwithProgressFilter = new Swiper(
                    ".cfeaturePage" + index + " .compare-feature-cards-carousel-filters",
                    {
                        loop: false,
                        slidesPerGroupSkip: 1,
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev",
                        },
                        breakpoints: {
                            1370: {
                                slidesPerView: 2.25,
                                spaceBetween: 16,
                            },
                            1170: {
                                slidesPerView: 2.2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2.25,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                                pagination: {
                                    el: ".swiper-pagination",
                                    clickable: true,
                                    type: "bullets"
                                },
                            }
                        }
                    }
                );

            }
        }
        else if ($(window).width() > 767 ) {
            if (swiperSlideLength <= 2) {
                $(".cfeaturePage" + index).addClass("destroyed");
            //$(".cfeaturePage" + index).find(".swiper-wrapper").addClass("row");
            $(".cfeaturePage" + index)
                .find(".swiper-wrapper.row")
                .children()
                .removeClass("swiper-slide");
                $(".cfeaturePage" + index)
                .find(".swiper-navigation")
                .addClass("deactive");
            } else {
                $(".cfeaturePage" + index).find(".swiper-wrapper").removeClass("row");
                var $carouselSliderwithProgress = new Swiper(
                    ".cfeaturePage" + index + " .compare-feature-cards-carousel",
                    {
                        loop: false,
                        slidesPerGroupSkip: 1,
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev",
                        },
                        breakpoints: {
                            1370: {
                                slidesPerView: 4.25,
                                spaceBetween: 16,
                            },
                            1170: {
                                slidesPerView: 3.2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2.25,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                                pagination: {
                                    el: ".swiper-pagination",
                                    clickable: true,
                                    type: "bullets"
                                },
                            }
                        }
                    }
                );

                var $carouselSliderwithProgressFilter = new Swiper(
                    ".cfeaturePage" + index + " .compare-feature-cards-carousel-filters",
                    {
                        loop: false,
                        slidesPerGroupSkip: 1,
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev",
                        },
                        breakpoints: {
                            1370: {
                                slidesPerView: 2.25,
                                spaceBetween: 16,
                            },
                            1170: {
                                slidesPerView: 2.2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2.25,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                                pagination: {
                                    el: ".swiper-pagination",
                                    clickable: true,
                                    type: "bullets"
                                },
                            }
                        }
                    }
                );

            }
        } else {
        //$(".cfeaturePage" + index).find(".swiper-wrapper").removeClass("row");
            var $carouselSliderwithProgress = new Swiper(
            ".cfeaturePage" + index + " .compare-feature-cards-carousel",
                {
                    loop: false,
                    slidesPerGroupSkip: 1,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                    breakpoints: {
                        1370: {
                            slidesPerView: 4.25,
                            spaceBetween: 16,
                        },
                        1170: {
                            slidesPerView: 3.25,
                            spaceBetween: 16,
                        },
                        768: {
                            slidesPerView: 2.25,
                            spaceBetween: 16,
                        },
                        100: {
                            slidesPerView: 1.15,
                            spaceBetween: 10,
                            pagination: {
                                el: ".swiper-pagination",
                                clickable: true,
                                type: "bullets"
                            },
                        }
                    }
            });
            var $carouselSliderwithProgressFilter = new Swiper(
                ".cfeaturePage" + index + " .compare-feature-cards-carousel-filters",
                {
                    loop: false,
                    slidesPerGroupSkip: 1,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                    breakpoints: {
                        1370: {
                            slidesPerView: 2.25,
                            spaceBetween: 16,
                        },
                        1170: {
                            slidesPerView: 2.2,
                            spaceBetween: 16,
                        },
                        768: {
                            slidesPerView: 2.25,
                            spaceBetween: 16,
                        },
                        100: {
                            slidesPerView: 1.15,
                            spaceBetween: 10,
                            pagination: {
                                el: ".swiper-pagination",
                                clickable: true,
                                type: "bullets"
                            },
                        }
                    }
                }
            );
        }
    });
}

// 06 Filters Cards Carousel Function
function initCompareFeatureCardCarouselFilters() {
    $(document).find(".compare-feature-cards-filters-wrap").each(function (index) {
        $(this).addClass('cfeaturePage-filters' + index)
          var $compareCardCarouselFilters = $(this);
          $compareCardCarouselFilters.find(".swiper-pagination").addClass("cfeatureCarouselFilters" + index);
          var swiperSlideLengthFilters = $('.cfeaturePage-filters' + index + " .compare-feature-cards-carousel-filters .swiper-slide").length;
          $compareCardCarouselFilters.find(".swiper-button-next").addClass("featureCardsNextFilters" + index);
          $compareCardCarouselFilters.find(".swiper-button-prev").addClass("featureCardsPrevFilters" + index);
          $compareCardCarouselFilters.find(".swiper-pagination").addClass("featureCardsPaginationFilters" + index);

          $(this).addClass("swiper-with-" + swiperSlideLengthFilters + "-slides");
          if ($(window).width() > 1370) {
              if (swiperSlideLengthFilters <= 3) {
              $(".cfeaturePage-filters" + index).addClass("destroyed");
              //$(".cfeaturePage" + index).find(".swiper-wrapper").addClass("row");
              $(".cfeaturePage-filters" + index)
                  .find(".swiper-wrapper.row")
                  .children()
                  .removeClass("swiper-slide");
                  $(".cfeaturePage-filters" + index)
                  .find(".swiper-navigation")
                  .addClass("deactive");
              } else {
                  $(".cfeaturePage-filters" + index).find(".swiper-wrapper").removeClass("row");
                  var $carouselSliderwithProgressfil = new Swiper(
                      ".cfeaturePage-filters" + index + " .compare-feature-cards-carousel-filters",
                      {
                          loop: false,
                          slidesPerGroupSkip: 1,
                          navigation: {
                              nextEl: ".swiper-button-next",
                              prevEl: ".swiper-button-prev",
                          },
                          pagination: {
                            el: ".swiper-pagination",
                            clickable: true,
                            type: "progressbar",
                        },
                          breakpoints: {
                              1370: {
                                  slidesPerView: 3,
                                  spaceBetween: 24,

                              },
                              1170: {
                                  slidesPerView: 2,
                                  spaceBetween: 16,
                              },
                              768: {
                                  slidesPerView: 2,
                                  spaceBetween: 16,
                              },
                              100: {
                                  slidesPerView: 1.15,
                                  spaceBetween: 10,
                              }
                          }
                      }
                  );
              }
          }
          else if ($(window).width() > 1170 ) {
              if (swiperSlideLengthFilters <= 3) {
                  $(".cfeaturePage-filters" + index).addClass("destroyed");
              //$(".cfeaturePage" + index).find(".swiper-wrapper").addClass("row");
              $(".cfeaturePage-filters" + index)
                  .find(".swiper-wrapper.row")
                  .children()
                  .removeClass("swiper-slide");
                  $(".cfeaturePage-filters" + index)
                  .find(".swiper-navigation")
                  .addClass("deactive");
              } else {
                  $(".cfeaturePage-filters" + index).find(".swiper-wrapper").removeClass("row");
                  var $carouselSliderwithProgressfil = new Swiper(
                      ".cfeaturePage-filters" + index + " .compare-feature-cards-carousel-filters",
                      {
                          loop: false,
                          slidesPerGroupSkip: 1,
                          navigation: {
                              nextEl: ".swiper-button-next",
                              prevEl: ".swiper-button-prev",
                          },
                          pagination: {
                            el: ".swiper-pagination",
                            clickable: true,
                            type: "progressbar"
                          },
                          breakpoints: {
                            1370: {
                                slidesPerView: 3,
                                spaceBetween: 24,
                            },
                            1170: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                            }
                        }
                      }
                  );

                  var $carouselSliderwithProgressFilters = new Swiper(
                      ".cfeaturePage-filters" + index + " .compare-feature-cards-carousel-filters",
                      {
                          loop: false,
                          slidesPerGroupSkip: 1,
                          navigation: {
                              nextEl: ".swiper-button-next",
                              prevEl: ".swiper-button-prev",
                          },
                          pagination: {
                            el: ".swiper-pagination",
                            clickable: true,
                            type: "progressbar"
                          },
                          breakpoints: {
                            1370: {
                                slidesPerView: 3,
                                spaceBetween: 24,
                            },
                            1170: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                            }
                        }
                      }
                  );

              }
          }
          else if ($(window).width() > 767 ) {
              if (swiperSlideLengthFilters <= 2) {
                  $(".cfeaturePage-filters" + index).addClass("destroyed");
              //$(".cfeaturePage" + index).find(".swiper-wrapper").addClass("row");
              $(".cfeaturePage-filters" + index)
                  .find(".swiper-wrapper.row")
                  .children()
                  .removeClass("swiper-slide");
                  $(".cfeaturePage-filters" + index)
                  .find(".swiper-navigation")
                  .addClass("deactive");
              } else {
                  $(".cfeaturePage-filters" + index).find(".swiper-wrapper").removeClass("row");
                  var $carouselSliderwithProgressfil = new Swiper(
                      ".cfeaturePage-filters" + index + " .compare-feature-cards-carousel-filters",
                      {
                          loop: false,
                          slidesPerGroupSkip: 1,
                          navigation: {
                              nextEl: ".swiper-button-next",
                              prevEl: ".swiper-button-prev",
                          },
                          pagination: {
                            el: ".swiper-pagination",
                            clickable: true,
                            type: "progressbar"
                          },
                          breakpoints: {
                            1370: {
                                slidesPerView: 3,
                                spaceBetween: 24,
                            },
                            1170: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                            }
                        }
                      }
                  );

                  var $carouselSliderwithProgressFilters = new Swiper(
                      ".cfeaturePage-filters" + index + " .compare-feature-cards-carousel-filters",
                      {
                          loop: false,
                          slidesPerGroupSkip: 1,
                          navigation: {
                              nextEl: ".swiper-button-next",
                              prevEl: ".swiper-button-prev",
                          },
                          pagination: {
                            el: ".swiper-pagination",
                            clickable: true,
                            type: "progressbar"
                          },
                          breakpoints: {
                            1370: {
                                slidesPerView: 3,
                                spaceBetween: 24,
                            },
                            1170: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            768: {
                                slidesPerView: 2,
                                spaceBetween: 16,
                            },
                            100: {
                                slidesPerView: 1.15,
                                spaceBetween: 10,
                            }
                        }
                      }
                  );

              }
          } else {
          //$(".cfeaturePage" + index).find(".swiper-wrapper").removeClass("row");
              var $carouselSliderwithProgressfil = new Swiper(
              ".cfeaturePage-filters" + index + " .compare-feature-cards-carousel-filters",
                  {
                      loop: false,
                      slidesPerGroupSkip: 1,
                      navigation: {
                          nextEl: ".swiper-button-next",
                          prevEl: ".swiper-button-prev",
                      },
                      pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                        type: "progressbar"
                      },
                      breakpoints: {
                        1370: {
                            slidesPerView: 3,
                            spaceBetween: 24,
                        },
                        1170: {
                            slidesPerView: 2,
                            spaceBetween: 16,
                        },
                        768: {
                            slidesPerView: 2,
                            spaceBetween: 16,
                        },
                        100: {
                            slidesPerView: 1.15,
                            spaceBetween: 10,
                        }
                    }
              });
              var $carouselSliderwithProgressFilters = new Swiper(
                  ".cfeaturePage-filters" + index + " .compare-feature-cards-carousel-filters",
                  {
                      loop: false,
                      slidesPerGroupSkip: 1,
                      navigation: {
                          nextEl: ".swiper-button-next",
                          prevEl: ".swiper-button-prev",
                      },
                      pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                        type: "progressbar"
                      },
                      breakpoints: {
                        1370: {
                            slidesPerView: 3,
                            spaceBetween: 24,
                        },
                        1170: {
                            slidesPerView: 2,
                            spaceBetween: 16,
                        },
                        768: {
                            slidesPerView: 2,
                            spaceBetween: 16,
                        },
                        100: {
                            slidesPerView: 1.15,
                            spaceBetween: 10,
                        }
                    }
                  }
              );
          }
      });
  }
$(document).ready(function () {
    initCompareFeatureCardCarousel();
    initCompareFeatureCardCarouselFilters();
    var currentSlideComCard = $(".smb-page .compare-card-digital-internet .text-card-wrap .feature-cards-box .swiper .swiper-wrapper .swiper-slide .feature-card.current");
    if(currentSlideComCard.length){
    $(currentSlideComCard).parent().hide();
    }
});
