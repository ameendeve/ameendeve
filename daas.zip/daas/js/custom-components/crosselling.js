function crossellingBannerCarousel() {
    $(document).find(".crosselling-banners").each(function (index) {
        $(this).addClass("crossellingBannersCarousel" + index);
        var $ParentCrosselling = $(this);
        $ParentCrosselling.find(".swiper-button-next").addClass("crossellingBannersRight" + index);
        $ParentCrosselling.find(".swiper-button-prev").addClass("crossellingBannersLeft" + index);
        $ParentCrosselling.find(".swiper-pagination").addClass("crossellingBannerspage" + index);
        var crossellingBGrid = new Swiper(".crossellingBannersCarousel" + index + " .swiper", {
            navigation: false,
            loop: false,
            autoplay: false,
            slidesPerView: 1,
            centeredSlides: true,
            spaceBetween: 40,
            pagination: {
                el: '.swiper-pagination.crossellingBannerspage' + index,
                clickable: true
            }
        });
    });
} // register the event handlers


$(document).ready(function () {
    crossellingBannerCarousel();
});