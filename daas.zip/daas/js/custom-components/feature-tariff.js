/* ================
35 Feature Tarrif 
===================
*/
      function initFeatureTarrifCarousel() {
        // getting wrapper div and adding extra class with indexing to differentiate  
        $(document).find(".feature-tarrif-wrap").each(function (index) {
          $(this).addClass('featurTarrif' + index);
          var $featureTariffCarousel = $(this);
          $featureTariffCarousel.find(".swiper-pagination").addClass("featurTarrifPagination" + index); // getting length of children swiper-slide in 'feature-tarrif-carousel'
          // to enable or disable slider based on swiper-slide length

          var swiperSlideLength = $('.featurTarrif' + index + " .feature-tarrif-carousel .swiper-slide").length;
          $(this).addClass("swiper-with-" + swiperSlideLength + "-slides"); // if window.width is greater than 992 check if swiper-slide are more than 2 enable swiper 
          // else don't and show simple bootstrap grid

          if ($(window).width() > 992) {
            // if slides length less than or equal to 2 do not add run swiper js and add class 'row' to 'swiper-wrapper' in html
            if (swiperSlideLength <= 2) {
              $(".featurTarrif" + index).addClass("destroyed");
              $(".featurTarrif" + index).find(".swiper-wrapper").addClass("row");
              var good = $(".featurTarrif" + index).find(".swiper-wrapper.row").children().removeClass("swiper-slide");
              console.log(good);
              $(".featurTarrif" + index).find(".swiper-navigation").addClass("deactive");
            } // else add indexing and enable swiper
            else {
              $(".featurTarrif" + index).find(".swiper-wrapper").removeClass("row");
              var $carouselfeaturTarrif = new Swiper(".featurTarrif" + index + " .feature-tarrif-carousel", {
                slidesPerGroupSkip: 1,
                slidesPerView: 2.2,
                pagination: {
                  el: ".swiper-pagination",
                  clickable: true,
                  type: "progressbar"
                },
                breakpoints: {
                  1099: {
                    slidesPerView: 2.2,
                    spaceBetween: 24
                  },
                  768: {
                    slidesPerView: 1.2,
                    spaceBetween: 20,
                    pagination: {
                      type: "bullets",
                      clickable: true
                    }
                  },
                  100: {
                    slidesPerView: 1.2,
                    spaceBetween: 10,
                    pagination: {
                      type: "bullets",
                      clickable: true
                    }
                  }
                }
              });
            }
          } // if window.width less than 992 enable swiper no matter what number of swiper-slide exist in each wrapper
          else {
            $(".featurTarrif" + index).find(".swiper-wrapper").removeClass("row");
            var $carouselfeaturTarrif = new Swiper(".featurTarrif" + index + " .feature-tarrif-carousel", {
              slidesPerGroupSkip: 1,
              slidesPerView: 2.2,
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
                type: "progressbar"
              },
              breakpoints: {
                1099: {
                  slidesPerView: 2.2,
                  spaceBetween: 24
                },
                768: {
                  slidesPerView: 1.2,
                  spaceBetween: 20,
                  pagination: {
                    type: "bullets",
                    clickable: true
                  }
                },
                100: {
                  slidesPerView: 1.2,
                  spaceBetween: 10,
                  pagination: {
                    type: "bullets",
                    clickable: true
                  }
                }
              }
            });
          }
        });
      }

      $(document).ready(function () {
        initFeatureTarrifCarousel();
      });