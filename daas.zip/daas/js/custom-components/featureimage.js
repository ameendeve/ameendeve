"use strict";

/**
 * v20221101
 * Feature With Image Tab
 */
$(document).ready(function () {
	if ($(window).width() > 767) {
	  $(".feature-with-image-tab .desktop-head a").off('click').on("click", function (e) {
		var attrtab = $(this).attr("data-bs-target"); //console.log(attrtab);

		$(".feature-with-image-tab .desktop-head a").addClass("collapsed");
		$(this).removeClass("collapsed");
		$(".feature-with-image-tab .mobile-head .mobile-headinner .panel-collapse").removeClass("show");
		$(".feature-with-image-tab .mobile-head .mobile-headinner").find(attrtab).addClass("show");
	  });
	} else {
	  $(".feature-with-image-tab .mobile-head a").off('click').on("click", function (e) {
		var attrtab = $(this).attr("data-bs-target"); //console.log(attrtab);

		$(".feature-with-image-tab .mobile-head a").addClass("collapsed");
		$(this).removeClass("collapsed");
		$(".feature-with-image-tab .mobile-head .mobile-headinner .panel-collapse").removeClass("show");
		$(".feature-with-image-tab .mobile-head .mobile-headinner").find(attrtab).addClass("show");
	  });
	}
});
    