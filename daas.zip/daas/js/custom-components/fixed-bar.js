      $(document).ready(function () {
        $(window).scroll(function () {
          var scroll = $(window).scrollTop();
          if (scroll >= 1) {
           
            $('.fixed-bar').addClass('sticky-fixed-bar');
          } else {
            $('.fixed-bar').removeClass('sticky-fixed-bar');
          }
        });
      });