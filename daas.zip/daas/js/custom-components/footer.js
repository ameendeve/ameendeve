
$(document).ready(function () {
        $(".mobile-collapse").click(function () {
          $('.mobile-collapse').not(this).removeClass('collapse');
          $(this).toggleClass('collapse');
        });
});