function form_thankyou_page() {
    const queryString = window.location.search;
    const leadUrlParams = new URLSearchParams(queryString);
    const leadReference = leadUrlParams.get('referenceNo')
    var refNumber = document.getElementById("rfNumber");
    if (refNumber  != null) {
        const cleanedRef = DOMPurify.sanitize(leadReference, {
            ALLOWED_TAGS: [],
            ALLOWED_ATTR: []
        });
        refNumber.innerHTML = cleanedRef;
    }
}