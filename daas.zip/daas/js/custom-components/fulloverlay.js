 /**
* Full ScreenOverlay
*/


$(document).ready(function() {

      if (document.getElementsByClassName("overlay-link") !== null) {

      // popup
          $('.overlay-link').off('click').on('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            var dataLabel = $(this).attr("data-label");
            console.log(dataLabel);
            if(typeof dataLabel !== 'undefined'  && dataLabel !== '') {
                $('#'+dataLabel).addClass('show');
                $('body').addClass('freeze');
            }
          });
        };
        if (document.getElementsByClassName("fullscreen-overlay-wrap") !== null) {

          // close popup
          $('.fullscreen-overlay-wrap').off('click').on('click' , '.modal-close', function(e){
            e.stopPropagation();
            e.preventDefault();
            var currentOpendPopUp = $(this).closest('.overlay-modal');
            $(currentOpendPopUp).removeClass('show');
            $('body').removeClass('freeze');
          });

      };

});


 