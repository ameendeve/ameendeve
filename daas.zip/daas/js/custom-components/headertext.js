/**
* Icon Header Text
* 45-icon-header-text-file.js
*/


$(document).ready(function () {
	$('.view-more-wrap').click(function () {
		$('.more-content').toggleClass('show');
		$('.view-more').toggleClass('collapsed');
	});
	//trigger register the event handlers of aos animation on click

  $('.view-more-wrap').on('click', function () {
    $('.more-content .icon-header-text-tile').removeClass('aos-animate');
    setTimeout(function () {
      $('.more-content .icon-header-text-tile').addClass('aos-animate');
    }, 800);
  });
});
