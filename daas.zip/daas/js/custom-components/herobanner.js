/*
===========================
Hero Banners Module -- 4 Thumbnails Version
===========================
 */
import { swiperInit } from "../swipernwtcon";
 
var mainSlides = $(".hero-banner-carousel-wrap .swiper-slide").length;
var thumbnailSlideOne = $(".hero-banner-one-slide .hero-banner-thumbnails .swiper-slide").length;
var thumbnailSlidesTwo = $(".hero-banner-two-slides .hero-banner-thumbnails .swiper-slide").length;
var thumbnailSlidesThree = $(".hero-banner-three-slides .hero-banner-thumbnails .swiper-slide").length;
var thumbnailSlidesFour = $(".hero-banner-four-slides .hero-banner-thumbnails .swiper-slide").length;

// Main Banner Slider function
function heroCarouselmainSlider() {
    $(document)
    .find(".hero-banner-carousel-wrap")
    .each(function (index) {
        $(this).addClass("heroBannerCarousel" + index);
        var $heroBannerMainSlider = $(this);
        $heroBannerMainSlider
        .find(".swiper-button-next")
        .addClass("heroBannerRight" + index);
        $heroBannerMainSlider
        .find(".swiper-button-prev")
        .addClass("heroBannerLeft" + index);
        $heroBannerMainSlider
        .find(".swiper-pagination")
        .addClass("heroPagination" + mainSlides + index);
        var carouselHeroBanner = swiperInit(
                ".heroBannerCarousel" + index + " .hero-banner-slider", {
                slidesPerView: 1,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false,
                },
                speed: 500,
                effect: 'fade',
                pagination: {
                    el: ".swiper-pagination",
                    type: "bullets",
                    clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
            });
    });
}

// Thumbnails slider function
function heroCarouselThumbnails() {
    $(document)
    .find(".hero-banner-thumbnails")
    .each(function (index) {
        $(this).addClass("heroBannerCarouselTwo" + index);
        var $heroBannerThumbnails = $(this);
        $heroBannerThumbnails
        .find(".swiper-button-next")
        .addClass("heroBannerRight" + index);
        $heroBannerThumbnails
        .find(".swiper-button-prev")
        .addClass("heroBannerLeft" + index);
        $heroBannerThumbnails
        .find(".swiper-pagination")
        .addClass("newpage" + index);

        var carouselHeroBannerThumbnails = swiperInit(
                ".heroBannerCarouselTwo" + index + " .hero-banner-thumbnail-section", {
                slidesPerView: 'auto',
                spaceBetween: 0,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false,
                },
                speed: 500
            });
    });
}
// event handlers
$(document).ready(function () {
    
    // Applying the condition based on number os slides in each variation
    if (thumbnailSlideOne == 1) {
        $(".hero-banner-thumbnails-one").addClass("max-one-slide");
    }
    if (thumbnailSlidesTwo == 2) {
        $(".hero-banner-thumbnails-two").addClass("max-two-slides");
    }
    if (thumbnailSlidesThree == 3) {
        $(".hero-banner-thumbnails-three").addClass("max-three-slides");
    }
    if (thumbnailSlidesFour == 4) {
        $(".hero-banner-thumbnails-four").addClass("max-four-slides");
    }
    heroCarouselmainSlider();
    heroCarouselThumbnails();
});
