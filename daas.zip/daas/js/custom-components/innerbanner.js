// register the event handlers
$(document).ready(function () {
  const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

  $(document).find(".badge-wrapper").each(function (index) {
      $(this).addClass('badge-wrapper-counter' + index);

      let startDateFromAttribute = $('.badge-wrapper-counter' + index + " .inner-page-counter").attr("data-start-date") || "";
      let endDateFromAttribute = $('.badge-wrapper-counter' + index + " .inner-page-counter").attr("data-end-date") || "";
      let startTimeFromAttribute = $('.badge-wrapper-counter' + index + " .inner-page-counter").attr("data-start-time") || "0";
      let endTimeFromAttribute = $('.badge-wrapper-counter' + index + " .inner-page-counter").attr("data-end-time") || "0";

      function parseTime(timeStr) {
          let [hours, minutes] = timeStr.split(':').map(Number);
          minutes = minutes || 0;
          return { hours, minutes };
      }

      let { hours: startHours, minutes: startMinutes } = parseTime(startTimeFromAttribute);
      let { hours: endHours, minutes: endMinutes } = parseTime(endTimeFromAttribute);

      // Parse dates and times
      let startDateTime = new Date(startDateFromAttribute);
      startDateTime.setHours(startHours, startMinutes, 0, 0);

      let endDateTime = new Date(endDateFromAttribute);
      endDateTime.setHours(endHours, endMinutes, 0, 0);

      console.log(`Start Date Time: ${startDateTime}`);
      console.log(`End Date Time: ${endDateTime}`);

      $('.badge-wrapper-counter' + index).hide();

      if (new Date() >= startDateTime && new Date() <= endDateTime) {
          $('.badge-wrapper-counter' + index).show();

          var countDown = endDateTime.getTime();

          var x = setInterval(function () {
              var now = new Date().getTime();
              var distance = countDown - now;
              var days = Math.floor(distance / day);
              var hours = Math.floor((distance % day) / hour);
              var minutes = Math.floor((distance % hour) / minute);
              var seconds = Math.floor((distance % minute) / second);

              // Update HTML elements with countdown values
              $('.badge-wrapper-counter' + index + " .day-first-digit").text(Math.floor(days / 10));
              $('.badge-wrapper-counter' + index + " .day-second-digit").text(days % 10);
              $('.badge-wrapper-counter' + index + " .hour-first-digit").text(Math.floor(hours / 10));
              $('.badge-wrapper-counter' + index + " .hour-second-digit").text(hours % 10);
              $('.badge-wrapper-counter' + index + " .minute-first-digit").text(Math.floor(minutes / 10));
              $('.badge-wrapper-counter' + index + " .minute-second-digit").text(minutes % 10);
              $('.badge-wrapper-counter' + index + " .second-first-digit").text(Math.floor(seconds / 10));
              $('.badge-wrapper-counter' + index + " .second-second-digit").text(seconds % 10);

              // Check if countdown is finished
              if (distance < 0) {
                  clearInterval(x);
                  $('.badge-wrapper-counter' + index + " .day-first-digit").text('0');
                  $('.badge-wrapper-counter' + index + " .day-second-digit").text('0');
                  $('.badge-wrapper-counter' + index + " .hour-first-digit").text('0');
                  $('.badge-wrapper-counter' + index + " .hour-second-digit").text('0');
                  $('.badge-wrapper-counter' + index + " .minute-first-digit").text('0');
                  $('.badge-wrapper-counter' + index + " .minute-second-digit").text('0');
                  $('.badge-wrapper-counter' + index + " .second-first-digit").text('0');
                  $('.badge-wrapper-counter' + index + " .second-second-digit").text('0');

                  $('.badge-wrapper-counter' + index).hide();
              }
          }, second);
      } else if (new Date() < startDateTime) {
          setTimeout(function () {
              $('.badge-wrapper-counter' + index).show();

              var countDown = endDateTime.getTime();

              var x = setInterval(function () {
                  var now = new Date().getTime();
                  var distance = countDown - now;
                  var days = Math.floor(distance / day);
                  var hours = Math.floor((distance % day) / hour);
                  var minutes = Math.floor((distance % hour) / minute);
                  var seconds = Math.floor((distance % minute) / second);

                  $('.badge-wrapper-counter' + index + " .day-first-digit").text(Math.floor(days / 10));
                  $('.badge-wrapper-counter' + index + " .day-second-digit").text(days % 10);
                  $('.badge-wrapper-counter' + index + " .hour-first-digit").text(Math.floor(hours / 10));
                  $('.badge-wrapper-counter' + index + " .hour-second-digit").text(hours % 10);
                  $('.badge-wrapper-counter' + index + " .minute-first-digit").text(Math.floor(minutes / 10));
                  $('.badge-wrapper-counter' + index + " .minute-second-digit").text(minutes % 10);
                  $('.badge-wrapper-counter' + index + " .second-first-digit").text(Math.floor(seconds / 10));
                  $('.badge-wrapper-counter' + index + " .second-second-digit").text(seconds % 10);

                  if (distance < 0) {
                      clearInterval(x);
                      $('.badge-wrapper-counter' + index + " .day-first-digit").text('0');
                      $('.badge-wrapper-counter' + index + " .day-second-digit").text('0');
                      $('.badge-wrapper-counter' + index + " .hour-first-digit").text('0');
                      $('.badge-wrapper-counter' + index + " .hour-second-digit").text('0');
                      $('.badge-wrapper-counter' + index + " .minute-first-digit").text('0');
                      $('.badge-wrapper-counter' + index + " .minute-second-digit").text('0');
                      $('.badge-wrapper-counter' + index + " .second-first-digit").text('0');
                      $('.badge-wrapper-counter' + index + " .second-second-digit").text('0');

                      $('.badge-wrapper-counter' + index).hide();
                  }
              }, second);
          }, startDateTime.getTime() - new Date().getTime());
      }
  });
});