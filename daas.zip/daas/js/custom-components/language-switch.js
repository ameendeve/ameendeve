export const LANGUAGE_SWITCH = () => {
    $('#b2bcms').click(function (event) {
        console.log('b2bcms link clicked');
        changeLangAction(event);
    });
    $('.nav-lang').on('click', function(event) {
      event.preventDefault();
      console.log('mobile.lang-switch clicked');
      changeLangAction(event);
    });
    function checkLocal(lang) {
        let pathURL = window.location.pathname;
        let pathQryStr = window.location.search;
        let newQryStr = "";
        if (pathQryStr.trim() == "") {
            newQryStr = pathURL + "?locale=" + lang;
        } else if (pathQryStr.indexOf("locale=en") == -1 && pathQryStr.indexOf("locale=ar") == -1) {
            newQryStr = pathURL + pathQryStr + "&locale=" + lang;
        } else {
            if (lang == "en") {
                newQryStr = pathURL + pathQryStr.replace("locale=ar", "locale=en");
            }
            if (lang == "ar") {
                newQryStr = pathURL + pathQryStr.replace("locale=en", "locale=ar");
            }
        }
        return newQryStr;
    }

    function changeLangAction(e) {
        e.preventDefault();
        var currentURL = window.location.href;
        var newURLB2B = '';
        if (currentURL.indexOf('/b2bportal/') > 0) {
            if (currentLang == 'en' || currentLang == 'EN') {
                newURLB2B = checkLocal("ar");
                localStorage.setItem("curr_language", "Arabic");
            } else if (currentLang == 'ar' || currentLang == 'AR') {
                newURLB2B = checkLocal("en");
                localStorage.setItem("curr_language", "English");
            }
            window.location.href = newURLB2B;
        } else {
            var getCurrentURL = window.location.href;
            var getIndexForArabic = getCurrentURL.indexOf('/en/');
            var getIndexForEnglish = getCurrentURL.indexOf('/ar/');
            var resultString = '';
            if (getIndexForArabic != -1) {
                resultString = getCurrentURL.replaceAll("/en/", "/ar/");
                window.location.href = resultString;
            } else if (getIndexForEnglish != -1) {
                resultString = getCurrentURL.replaceAll("/ar/", "/en/");
                window.location.href = resultString;
            } else {
                return false;
            }
        }
    }
}
