import { FORM_SUCCESS, FORM_ERROR } from '../analytics/analytics';
       
$('#leadFormRequestTrialKit .EtisalatAccountNumber').addClass('d-none');
$(document).on('change','#leadFormRequestTrialKit input[name=havenumber]',function() {
    if (this.value == 'yes') {
        $('#leadFormRequestTrialKit .EtisalatAccountNumber').removeClass('d-none');
    } else {
        $('#leadFormRequestTrialKit .EtisalatAccountNumber').addClass('d-none');
    }
});
if(window.location.href.indexOf('error') !== -1){
    $("#leadFormRequestTrialKit #dErrorMessage").removeClass('hidden');
}

let simTypeval = $(".simtypevalue").val();
$(document).ready(function () {
  $("form :input").not("[name='description']").on("input change", function () {
        let totalLength = 0;  
        $("form :input").not("[name='description']").each(function () {
            totalLength += $(this).val().length;
        });  
        let remainingLength = 2000 - totalLength; 
        if (remainingLength < 0) remainingLength = 0; 
        $("#description").attr("maxlength", remainingLength);
    });
    $(document).on("change", ".select2-hidden-accessible", function () {
      $(this).valid(); // Revalidate the field
  });
});

var $leadFormRequestTrialKit = $("#leadFormRequestTrialKit");
var leadFormRequestTrialKitlang = $('html').attr('lang');
var leadFormRequestTrialKitresultMessageContainer = $("#leadFormRequestTrialKit .business-form-submitted");
var leadFormRequestTrialKitinvalidNumberError = window.location.href.indexOf(".ae/ar") > -1 ? "رقم هاف محمول غير صالح " : "Invalid Contact Number";
var leadFormRequestTrialKitGeneralErrorMsg = window.location.href.indexOf(".ae/ar") > -1 ? "هناك شيء خاطئ، يرجى المحاولة في وقت لاحق" : "Something went wrong, please try again later";
// if (!$leadFormRequestTrialKit.length) {
//   return false;
// }
const $SUBMIT_CTA = $('#leadFormRequestTrialKit #btnleadFormRequestTrialKit');
const currentURL = window.location.href;
$SUBMIT_CTA.on('click', function () {
  if ($leadFormRequestTrialKit.valid() == false) {
    FORM_ERROR($leadFormRequestTrialKit, 'validation error');
    return false;
  }
});
var leadFormRequestTrialKitmessagelocal;


function getFormData($leadFormRequestTrialKit) {
    var o = {};
    var a = $leadFormRequestTrialKit.serializeArray();
    $.each(a, function () {
      if (o[this.name]) {
        if (!o[this.name].push) {
          o[this.name] = [o[this.name]];
        }
        o[this.name].push(this.value || "");
      } else {
        o[this.name] = this.value || "";
      }
    });
    return o;
}

function showErrorMessageleadFormRequestTrialKit(text) {
  leadFormRequestTrialKitresultMessageContainer.text(text);
  leadFormRequestTrialKitresultMessageContainer.addClass("error");
  leadFormRequestTrialKitresultMessageContainer.removeClass("hidden");
  // show again the submit button, enable the form, hide the loadings
}
function getParameterByName(name, href) {
  name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
  const regexS = '[\\?&]' + name + '=([^&#]*)';
  const regex = new RegExp(regexS);
  const results = regex.exec(href);
  if (results == null) return '';
  else return decodeURIComponent(results[1].replace(/\-/g, ' '));
}
function queryParamValue(name, url = currentURL) {
  if (!name || !currentURL) return undefined;

  return getParameterByName(name, url)
    .replace(/_/g, ' ')
    .replace(/[\_\"\'\>\<\?\=\/\/]/g, ' ');
}


function bindingUIFromParamsProductLead() {
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  const productName = queryParamValue('productName', currentURL);
  const amountPrice = queryParamValue('p', currentURL);
  const contractPeriod = queryParamValue('contractPeriod', currentURL);
  if (productName) {
      const targetHeading = $(".smb-form-wrapper .order-details-box #productName h4");
      targetHeading.html(productName);

      const targetPrice = $(".smb-form-wrapper .order-details-box #productPrice h2")
      targetPrice.html(amountPrice);

      const targetContract = $(".smb-form-wrapper .order-details-box p#productContract")
      targetContract.html(contractPeriod);
      $("#leadFormRequestTrialKit .sec-main-headings span.ptitle").html(productName);
      $("#productInfoModal .side-inner .header .sec-main-headings h5").html(productName);
      $("#leadFormRequestTrialKit .form-text-area #backbtn").click(function(e) {
        e.preventDefault();
        history.back();
      })
  }
  if(amountPrice === '') {
    $('.price-details').addClass('hidenow');
  }

}
$(document).ready(function () {

    bindingUIFromParamsProductLead();

    $leadFormRequestTrialKit.validate({
            rules: {
              firstName: {
                  required: true,
                  realalphabeticlatinarabic: true,
                  maxlength: 248,
                },
                lastName: {
                  required: true,
                  realalphabeticlatinarabic: true,
                  maxlength: 248,
                },
                companyName: {
                    //required: true,
                    realalphabeticlatinarabic: true,
                    maxlength: 248,
                },
                positionrole: {
                  required: true,
                  realalphabeticlatinarabic: true,
                  maxlength: 248,
                },
                module:{
                  required: true,
                },
                businesstype:{
                    required: true,
                },
                simtype:{
                    required: true,
                },
                volumeforcast12month:{
                    required: true,
                },
                havmonth:{
                    required: true,
                },
                // description: {
                //     required: true,
                //     richtext: true
                // },
                contactNumber: {
                    required: true,
                    digits: true,
                    pattern: /^(050|052|054|055|056|057|058)/,
                    minlength: 10,
                    maxlength: 10,
                },
                accountNumber: {
                    required: true,
                    digits: true,
                    //number: true,
                    //pattern: /^(050|054|055|056|052)/,
                    minlength: 9,
                    maxlength: 10,
                },

                emailAddress: {
                    required: true,
                    email: true,
                }
            },
            errorPlacement:
            function( error, element ){
              if (element.is(":radio")) {
                // Find the last radio button in the group and insert the error after its label
                error.insertAfter(element.closest(".form-check").find("label").last());
              } else if (element.hasClass("select2-hidden-accessible")) { 
                error.insertAfter(element.next(".select2"));
              }else {
                // Default placement for other input fields
                error.insertAfter(element);
              }
            },
            messages: leadFormRequestTrialKitmessagelocal,
            submitHandler: function(form, event) {
                var dataObj = getFormData($leadFormRequestTrialKit);
                const product =  queryParamValue('product') || dataObj.product;
                const price = queryParamValue('price') || dataObj.price;
                const contractperiod = queryParamValue('contractPeriod') || dataObj.contractperiod;
                const subject = queryParamValue('subject') || dataObj.subject;
                const channel = queryParamValue('channel') || dataObj.channel;
                let descriptionArray = [
                  `Position: ${dataObj.positionrole}`,
                  `Module: ${dataObj.module}`,
                  `Business Type: ${dataObj.businesstype}`,
                  `SIM Type: ${simTypeval}`,
                  `Volume Forecast 12 Months: ${dataObj.volumeforcast12month}`,
                  `Requirement Timeframe: ${dataObj.havmonth}`,
                  `Project Description :  ${dataObj.description}`
              ];
              let formattedDescription = descriptionArray.join("\n");
                var formData = {
                  accountNumber: "null",
                  product,
                  subject,
                  channel,
                  existingAccount: "null",
                  contactFirstName: dataObj.firstName,
                  contactLastName: dataObj.lastName,
                  email: dataObj.emailAddress,
                  mobileNo: dataObj.contactNumber,
                  companyName: dataObj.companyName || "null",
                  //description: dataObj.description || "null",
                  description:formattedDescription || "null",
                }

                let dataObjwithJson = {
                  ClientCaptchaValue: sessionStorage.getItem("gcresponse"),
                  TYPE: 'CREATEOMNILEAD',
                  REQPAYLOAD: formData,
                };
                dataObjwithJson = JSON.stringify(dataObjwithJson, null, 2);
                console.log(dataObjwithJson);
                document.getElementById("btnleadFormRequestTrialKit").disabled = true;
                $.ajax({
                  type: 'POST',
                  url: $($leadFormRequestTrialKit).attr('action'),
                  data: dataObjwithJson.replace(/[\r\n]/gm, ''),
                  dataType: 'json',
                  headers: {
                    "content-type": "application/json",
                    'x-calling-application': 'cms',
                  },
                  encode: true
                })
                .done(function (response) {
                    const fromData = getFormData($leadFormRequestTrialKit);
                    console.log(fromData)
                    const authoredRedirectUrl = fromData[':redirect'] || `smb-thank-you-page.html`;
                    //let RE_URL = `${window.location.origin}${authoredRedirectUrl}`;
                    let RE_URL = '';
                    const ref = response?.bcrmTransactionId || '';

                    let path = window.location.pathname;
                    let page = path.split('/').pop();
                    // window.location.href = window.location.href.replace(page, authoredRedirectUrl);

                    if(window.location.search) {
                      RE_URL += `${window.location.search}&referenceNo=${ref}&formIDName=leadFormRequestTrialKit`;
                    } else {
                      RE_URL += `?referenceNo=${ref}&formIDName=leadFormRequestTrialKit`;
                    }

                    $(document).trigger('GA_FROM_TRACKING', { $type: 'submit' });
                    //FORM_SUCCESS($smbLeadorderForm, { ...PAYLOAD, productName, expectedRevenue, referenceNumber: ref });
                    FORM_SUCCESS($leadFormRequestTrialKit, formData);
                   
                    window.location.href = window.location.origin + window.location.pathname.replace(page, authoredRedirectUrl) + RE_URL; 
                    //window.location.href =  window.location.href.replace(page, authoredRedirectUrl)+RE_URL;

                    return true;
                  })
                  .fail(submitErrorResponseleadFormRequestTrialKit);

                // return false to prevent normal browser submit and page navigation
              return false;
            },

      })
            
    });




    function submitErrorResponseleadFormRequestTrialKit(jqXHR, textStatus, error) {
        let errorText = (jqXHR.responseJSON && jqXHR.responseJSON.message) || error;
        showErrorMessageleadFormRequestTrialKit(leadFormRequestTrialKitGeneralErrorMsg);
        
        //FORM_ERROR($leadFormRequestTrialKit, 'API error', errorText);
    }