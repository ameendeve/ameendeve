import { FORM_SUCCESS, FORM_ERROR } from '../analytics/analytics';
  // Google Event
  function googleClickEvent(dataObject) {
    if (typeof (window.dataLayer) !== "undefined") {
      dataLayer.push(dataObject);
    }
    console.log(dataObject)
  }
  // Generic Adobe Function
  function adobeFormEvent(dataObject) {
    if (typeof (window.dataLayer) !== "undefined") {
        dataLayer.push(dataObject);
    }
    console.log(dataObject)
  }

  function leadFormsErrorGoogle(msg) {
    var DisplayFormName = window.location.href;
    var errorMessage = $('.smbform .business-form-submitted.error').text();
    var fielNameHTML = DisplayFormName.split('/').pop().split('?')[0].split('#')[0].split('.')[0]
    var object = {
      'event': 'lead_'  + msg,
      'form_id': "smbLeadorderForm",
      'form_name': "smbLeadorderForm",
      'currency': '',
      'value': '',
      'error_code': '',
      'error_message': errorMessage,
      'error_type': 'system_error',
      'items': {
        'item_id': '',
        'item_name': '',
        'item_category': '',
        'price': '',
      }
    }
    googleClickEvent(object);
  }

  function leadFormsSuccessGoogle(msg) {
    var DisplayFormName = window.location.href
    var fielNameHTML = DisplayFormName.split('/').pop().split('?')[0].split('#')[0].split('.')[0]
    var object = {
      'event': 'lead_'  + msg,
      'form_id': "smbLeadorderForm",
      'form_name': "smbLeadorderForm",
      'currency': '',
      'value': '',
      'items': {
        'item_id': '',
        'item_name': '',
        'item_category': '',
        'price': '',
      }
    }
    googleClickEvent(object);
  }

   // all SMB Lead LEad forms Error state Adobe
   function leadFormsErrorAdobe(msg) {
    var DisplayFormName = window.location.href;
    var errorMessage = $('.smbform .business-form-submitted.error').text();
    var object = {
        "event": "form " + msg,
        "formDetails": {
            "formName": "smbLeadorderForm",
        },
        "eventInfo": {
            "formStart": 1
        },
        "errorInfo": {
          "formError": 1,
          "errorMessage": errorMessage,
          "errorCode": "",
          "errorType": ""
        },
        "productListItems": {
            "name": '',
            "_merchVars": {
                "productType": "",
                "productCategory": "",
                "price": ''
            }
        }
    }
    adobeFormEvent(object);
}

// all SMB LEad LEad forms Success state Adobe
function leadFormsSuccessAdobe(msg) {
var DisplayFormName = window.location.href
var object = {
    "event": "form " + msg,
    "formDetails": {
        "formName": "smbLeadorderForm",
    },
    "eventInfo": {
        "formSubmit": 1
    },
    "productListItems": {
        "name": '',
        "_merchVars": {
            "productType": "",
            "productCategory": "",
            "price":  ''
        }
    }
}
adobeFormEvent(object);
}
  $(document).on('change','#smbLeadorderForm input[name=havenumber]',function() {
      if (this.value == 'yes') {
          $('#smbLeadorderForm .EtisalatAccountNumber').removeClass('d-none');
      } else {
          $('#smbLeadorderForm .EtisalatAccountNumber').addClass('d-none');
      }
  });
  if(window.location.href.indexOf('error') !== -1){
      $("#smbLeadorderForm #dErrorMessage").removeClass('hidden');
  }

  var $smbLeadorderForm = $("#smbLeadorderForm");
  var smbLeadorderFormlang = $('html').attr('lang');
  var smbLeadorderFormresultMessageContainer = $("#smbLeadorderForm .business-form-submitted");
  var smbLeadorderForminvalidNumberError = window.location.href.indexOf(".ae/ar") > -1 ? "رقم هاف محمول غير صالح " : "Invalid Contact Number";
  var smbLeadorderFormGeneralErrorMsg = window.location.href.indexOf(".ae/ar") > -1 ? "هناك شيء خاطئ، يرجى المحاولة في وقت لاحق" : "Something went wrong, please try again later";
  // if (!$smbLeadorderForm.length) {
  //   return false;
  // }
  const $SUBMIT_CTA = $('#smbLeadorderForm #btnsmbLeadorderForm');
  const currentURL = window.location.href;
  $SUBMIT_CTA.on('click', function () {
    if ($smbLeadorderForm.valid() == false) {
      FORM_ERROR($smbLeadorderForm, 'validation error');
      return false;
    }
  });
  var smbLeadorderFormmessagelocal;
  var smbLeadorderFormvalidateMessage = {
    en: {
      name: {
        required: "Name is required",
        number: "Name connot contain numbers",
        maxlength: "Name cannot be longer than 50 characters.",
        alphanumeric: "Letters only please",
        lettersonly: "Letters only please",
      },
    },
    ar: {
      name: {
        required: "يرجى كتابة الاسم ",
      },
      email: {
        required: "يرجى كتابة البريد الإلكتروني",
      },
      reason: {
        required: "يرجى كتابة سؤالك",
      },
    },
  };
  if (document.documentElement.smbLeadorderFormlang == "ar") {
    smbLeadorderFormmessagelocal = smbLeadorderFormvalidateMessage.ar;
  } else {
    smbLeadorderFormmessagelocal = smbLeadorderFormvalidateMessage.en;
  }

  function getFormData($smbLeadorderForm) {
      var o = {};
      var a = $smbLeadorderForm.serializeArray();
      $.each(a, function () {
        if (o[this.name]) {
          if (!o[this.name].push) {
            o[this.name] = [o[this.name]];
          }
          o[this.name].push(this.value || "");
        } else {
          o[this.name] = this.value || "";
        }
      });
      return o;
  }

    function showErrorMessage(text) {
      smbLeadorderFormresultMessageContainer.text(text);
      smbLeadorderFormresultMessageContainer.addClass("error");
      smbLeadorderFormresultMessageContainer.removeClass("hidden");
      // show again the submit button, enable the form, hide the loadings
    }
    function getParameterByName(name, href) {
      name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
      const regexS = '[\\?&]' + name + '=([^&#]*)';
      const regex = new RegExp(regexS);
      const results = regex.exec(href);
      if (results == null) return '';
      else return decodeURIComponent(results[1].replace(/\-/g, ' '));
    }
    function queryParamValue(name, url = currentURL) {
      if (!name || !currentURL) return undefined;

      return getParameterByName(name, url)
        .replace(/_/g, ' ')
        .replace(/[\_\"\'\>\<\?\=\/\/]/g, ' ');
    }

    function bindingUIFromParams() {
      const productName = queryParamValue('productName', currentURL);
      if (productName) {
        const targetElement = $('#smbLeadorderForm').find('.sec-main-headings span.ptitle');
        //const targetElementValue = $('#smbLeadorderForm').find('.sec-main-headings span.ptitle').text().trim();
        //const valueWithProductName = targetElementValue + ' ' + productName + '?';
        targetElement.html(productName);
      }
    }

  $(document).ready(function () {
    bindingUIFromParams();
      $smbLeadorderForm.validate({
              rules: {
                firstName: {
                    required: true,
                    realalphabeticlatinarabic: true,
                    maxlength: 248,
                  },
                  lastName: {
                    required: true,
                    realalphabeticlatinarabic: true,
                    maxlength: 248,
                  },
                  companyName: {
                      //required: true,
                      realalphabeticlatinarabic: true,
                      maxlength: 248,
                  },
                  // description: {
                  //     required: true,
                  //     richtext: true
                  // },
                  contactNumber: {
                      required: true,
                      digits: true,
                      pattern: /^(050|052|054|055|056|057|058)/,
                      minlength: 10,
                      maxlength: 10,
                  },
                  accountNumber: {
                      required: true,
                      digits: true,
                      //number: true,
                      //pattern: /^(050|054|055|056|052)/,
                      minlength: 9,
                      maxlength: 10,
                  },

                  emailAddress: {
                      required: true,
                      email: true,
                  }
              },
              errorPlacement:
              function( error, element ){
                error.insertAfter(element);
              },
              messages: smbLeadorderFormmessagelocal,
              submitHandler: function(form, event) {
                  var dataObj = getFormData($smbLeadorderForm);
                  const product = queryParamValue('product') || dataObj.product;
                  const subject = queryParamValue('subject') || dataObj.subject;
                  const channel = queryParamValue('channel') || dataObj.channel;
                  var formData = {
                    accountNumber: "null",
                    product,
                    subject,
                    channel,
                    existingAccount: "null",
                    contactFirstName: dataObj.firstName,
                    contactLastName: "null",
                    email: dataObj.emailAddress,
                    mobileNo: dataObj.contactNumber,
                    companyName: dataObj.companyName || "null",
                    description: dataObj.description || "null",

                  }
                  let dataObjwithJson = {
                    ClientCaptchaValue: sessionStorage.getItem("gcresponse"),
                    TYPE: 'CREATEOMNILEAD',
                    REQPAYLOAD: formData,
                  };
                  dataObjwithJson = JSON.stringify(dataObjwithJson, null, 2);
                  document.getElementById("btnsmbLeadorderForm").disabled = true;

                  $.ajax({
                    type: 'POST',
                    url: $($smbLeadorderForm).attr('action'),
                    data: dataObjwithJson.replace(/[\r\n]/gm, ''),
                    dataType: 'json',
                    headers: {
                      'content-type': 'application/json',
                      'x-calling-application': 'cms',
                    },
                    encode: true
                  })
                  .done(function (response) {
                      const fromData = getFormData($smbLeadorderForm);


                      const authoredRedirectUrl = fromData[':redirect'] || `smb-thank-you-page.html`;
                      //let RE_URL = `${window.location.origin}${authoredRedirectUrl}`;
                      let RE_URL = '';
                      const ref = response?.bcrmTransactionId || '';

                      let path = window.location.pathname;
                      let page = path.split('/').pop();
                     // window.location.href = window.location.href.replace(page, authoredRedirectUrl);

                      if(window.location.search) {
                        RE_URL += `${window.location.search}&referenceNo=${ref}`;
                      } else {
                        RE_URL += `?referenceNo=${ref}`;
                      }

                      $(document).trigger('GA_FROM_TRACKING', { $type: 'submit' });
                      leadFormsSuccessGoogle('submit');
                      leadFormsSuccessAdobe('submit');
                      //FORM_SUCCESS($smbLeadorderForm, { ...PAYLOAD, productName, expectedRevenue, referenceNumber: ref });
                      FORM_SUCCESS($smbLeadorderForm, formData);
                      window.location.href = window.location.origin + window.location.pathname.replace(page, authoredRedirectUrl) + RE_URL; 
                     // window.location.href =  window.location.href.replace(page, authoredRedirectUrl)+RE_URL;

                      return true;
                    })
                    .fail(submitErrorResponse);

                  // return false to prevent normal browser submit and page navigation
                 return false;
              },

        })
      });




      function submitErrorResponse(jqXHR, textStatus, error) {
          let errorText = (jqXHR.responseJSON && jqXHR.responseJSON.message) || error;
          showErrorMessage(smbLeadorderFormGeneralErrorMsg);
          FORM_ERROR($smbLeadorderForm, 'API error', errorText);
          leadFormsErrorGoogle('error');
          leadFormsErrorAdobe('error');

      }