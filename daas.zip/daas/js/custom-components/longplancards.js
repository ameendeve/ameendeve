function initCompareCardCarousel() {  
  $(document)
    .find(".compare-card-wexpand-wrapper")
    .each(function (index) {
        $(this).addClass('slideronPage' + index)
        var $compareCardCarousel = $(this);
        $compareCardCarousel
        .find(".swiper-pagination")
        .addClass("compareCarousel" + index);
        
      var swiperSlideLength = $('.slideronPage' + index + " .compare-card-wexpand-carousel .swiper-slide").length;
      $(this).addClass("swiper-with-" + swiperSlideLength + "-slides");
      if ($(window).width() > 992) {
        if (swiperSlideLength <= 3) {
          
          $(".slideronPage" + index).addClass("destroyed");
          $(".slideronPage" + index).find(".swiper-wrapper").addClass("row");
          $(".slideronPage" + index)
            .find(".swiper-wrapper.row")
            .children()
            .removeClass("swiper-slide");
          $(".slideronPage" + index)
            .find(".swiper-navigation")
            .addClass("deactive");
        } else {
          $(".slideronPage" + index).find(".swiper-wrapper").removeClass("row");
          var $carouselSliderwithProgress = new Swiper(
            ".slideronPage" + index + " .compare-card-wexpand-carousel",
            {
              slidesPerView: 3,
              slidesPerGroupSkip: 1,
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
                type: "progressbar",
              },
              breakpoints: {
                1099: {
                  slidesPerView: 3,
                  spaceBetween: 24,
                },
                768: {
                  slidesPerView: 1.75,
                  spaceBetween: 16,
                  pagination: {
                    type: "progressbar",
                    clickable: true,
                  },
                },
                100: {
                  slidesPerView: 1,
                  spaceBetween: 0,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  },
                },
              },
            }
          );
        }
      } else {
        $(".slideronPage" + index).find(".swiper-wrapper").removeClass("row");
        var $carouselSliderwithProgress = new Swiper(
          ".slideronPage" + index + " .compare-card-wexpand-carousel",
          {
            slidesPerView: 3,
            slidesPerGroupSkip: 1,
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
                type: "progressbar",
              },
              breakpoints: {
                1099: {
                  slidesPerView: 3,
                  spaceBetween: 24,
                },
                768: {
                  slidesPerView: 1.75,
                  spaceBetween: 16,
                  pagination: {
                    type: "progressbar",
                    clickable: true,
                  },
                },
                100: {
                  slidesPerView: 1,
                  spaceBetween: 0,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  },
                },
              },
            }
        );
      }
    });
  
}
// Show hide Parent categories Function
function initProductsCardsParentCategory() {
  $('.product-filter-sidebar .accordion-item .accordion-header .checkboxes-wrap input').click(function () {
    // console.log("long plan cards main category");
    $(this).parents('li').siblings().removeClass('active-item'); 
    $(this).parents('li').addClass('active-item'); 

    if($(this).attr("value") == 'all') {
      // console.log('all categories')
      var checked = $(this).prop("checked");
      if(checked) {
        $(".accordion").find("input:checkbox").prop("checked", false);  
      }
      var getAllCategoriesCard = $(this).closest('.container').find(".filter-wrap > .cat-box > div");
      $(getAllCategoriesCard).show();
      let currentUrl = new URL(window.location.href);
      currentUrl.searchParams.set('selectedFilterID', 'all-contracts');
      window.history.pushState({ path: currentUrl.href }, '', currentUrl.href);
      // console.log('all-contracts value all')
    } else if ($(this).attr("data-label") == 'all-contracts') {
      var checked = $(this).prop("checked");
      if(checked) {
        $(".accordion").find("input:checkbox").prop("checked", false);  
      }
      var getAllCategoriesCard = $(this).closest('.container').find(".filter-wrap > .cat-box > div");
      $(getAllCategoriesCard).show();
      let currentUrl = new URL(window.location.href);
      currentUrl.searchParams.set('selectedFilterID', 'all-contracts');
      window.history.pushState({ path: currentUrl.href }, '', currentUrl.href);
      // console.log('all-contracts data-label')
    } else {
      // console.log('no all cats')
      let radiobtnLabelName = $(this).attr("data-label");
      // let currentUrl = new URL(window.location.href);
      // currentUrl.searchParams.set('selectedFilterID', radiobtnLabelName);
      // var getTabIdNumber = window.location.hash;
      // console.log(`${radiobtnLabelName}${getTabIdNumber}`)
      // if(getTabIdNumber != '') {
      //   currentUrl.searchParams.set('selectedFilterID', radiobtnLabelName);
      // }
      // var radiobtnLabelName = $(this).attr("data-label");
      // var _currentUrl2 = new URL(window.location);
      // _currentUrl2.searchParams.set('selectedFilterID', radiobtnLabelName);
      // var getTabIdNumber = $(".tab-content-section .tab-content>.tab-pane.active").attr('id')
      // console.log(getTabIdNumber)
      // var tabNumber = getTabIdNumber.match(/\d/g);
      // tabNumber = tabNumber.join("");
      // // tabNumber += 1
      // // tabNumber = Number(tabNumber) + 1;
      // tabNumber = + tabNumber + 1;
      // if (getTabIdNumber != '') {
      //   //radiobtnLabelName += `#`
      //   window.location.hash = '#' + tabNumber;
      // }
      // window.history.pushState({ path: _currentUrl2.href }, null , _currentUrl2.href);
      var url = new URL(window.location.href);
      var search_params = url.searchParams;
      search_params.set('selectedFilterID', radiobtnLabelName);
      url.search = search_params.toString();
      var new_url = url.toString();
      // console.log(new_url);
      history.pushState({}, null, new_url);
      
      if ($(this).closest('.container').find('.product-filter-sidebar .accordion-item .accordion-collapse .checkboxes-wrap input').is(':checked')) { 
          $(this).closest('.container').find(".accordion-item input:checkbox").prop("checked", false);
      }
      $(this).closest('.container').find('.accordion-header').removeClass('checkbuttons')
      $(this).closest('.container').find(".accordion-collapse").removeClass("activeradio")
      $(this).closest(".accordion-header").addClass("checkbuttons");
      $(this).closest('.container').find(".checkbuttons").next(".accordion-collapse").addClass("activeradio");
      
      var checked = $(this).prop("checked");
      $(this).closest('.container').find(".activeradio").find("input:checkbox").prop("checked", checked);
      $(this).closest('.container').find(".activeradio").find("input:radio").prop("checked", checked);
      
      var checkboxValues = [];
      $(this).closest('.container').find('.product-filter-sidebar .accordion-item .accordion-header input:checked').each(function (
        index,
        elem
      ) {
        checkboxValues.push($(elem).val());
      });
      var getAllCategoriesCard = $(this).closest('.container').find(".filter-wrap > .cat-box > div");
      var getCurrentCategoryCard = [];

      $(getAllCategoriesCard).hide();
      checkboxValues.forEach((checkBoxValues) => {
        getCurrentCategoryCard.push(
          $(this).closest('.container').find(".filter-wrap > .cat-box > div[main-category~='" + checkBoxValues + "']")
        );
      });
      getCurrentCategoryCard.forEach((activeCard) => {
        $(activeCard).show();
      });
      
    }
  });
}

// on tab change 
var tabEl = document.querySelectorAll('.cardsFilterTabs button[data-bs-toggle="tab"]')
for (let i = 0; i < tabEl.length; i++) {
  tabEl[i].addEventListener('shown.bs.tab', function(event) {
    var getTabIdNumber = $(".tab-content-section .tab-content>.tab-pane.active").attr('id');
    var tabNumber = getTabIdNumber.match(/\d/g);
    tabNumber = tabNumber.join("");
    tabNumber = + tabNumber + 1;
    window.location.hash = '#' + tabNumber;
    $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane.active").each(function(index, element) {
      var url = new URL(window.location.href);
      var search_params = url.searchParams;
      var filtereditem = search_params.get('selectedFilterID');
      if ($(element).find(".checkboxes-wrap input[data-label='" + filtereditem + "']").length > 0) {
        $(element).find('.checkboxes-wrap input').each(function(indexr, radior){
          if($(radior).attr('data-label') === filtereditem) {
            let activeRadioValue = $(radior).attr('value')
            $(this).prop("checked", true)
            $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
            var checkboxValues = [];
            $(this).closest('.container').find('.product-filter-sidebar .accordion-item .accordion-header input:checked').each(function (
              index,
              elem
            ) {
              checkboxValues.push($(elem).val());
            });

            var getAllCategoriesCard = $(this).closest('.container').find(".filter-wrap > .cat-box > div");
            var getCurrentCategoryCard = [];

            $(getAllCategoriesCard).hide();
            checkboxValues.forEach((checkBoxValues) => {
              getCurrentCategoryCard.push(
                $(this).closest('.container').find(".filter-wrap > .cat-box > div[main-category~='" + activeRadioValue + "']")
              );
            });
            getCurrentCategoryCard.forEach((activeCard) => {
              $(activeCard).show();
            });
            
          } else if (filtereditem === 'all-contracts') {
            var getAllCategoriesCard = $('.tab-content-section .tab-content>.tab-pane.active').find('.filter-wrap > .cat-box > div');
            $(getAllCategoriesCard).show();
          } 
          
        })
      } else {
        // console.log('all ctas asd')
        var url = new URL(window.location.href);
        var search_params = url.searchParams;
        search_params.set('selectedFilterID', 'all-contracts');
        url.search = search_params.toString();
        var new_url = url.toString();
        history.pushState({}, null, new_url);
      }
    })
    // $(".productCardsTabs" + index).find(".product-filter-sidebar .accordion-item .accordion-header .checkboxes-wrap input").each(function (index) {
      
      
      // $(this).closest('.row').find(".accordion").find("input:radio").prop("checked", true);
      // var getInputID = $(this).attr('id');
      // var newInputID = getInputID + '-' + newTabID
      // $(this).attr('id', newInputID)

      // var getInputValue = $(this).attr('value');
      // var newInputValue = getInputValue + '-' + newTabID
      // $(this).attr('value', newInputValue)

      // var getInputName = $(this).attr('name');
      // var newInputName = getInputName + '-' + newTabID
      // $(this).attr('name', newInputName)
      
    // })
  })
}
// var tabEl = document.querySelector('.nav-tabs-section .nav-tabs button[data-bs-toggle="tab"]')
// tabEl.addEventListener('shown.bs.tab', function (event) {
//   alert('working')
//   // event.target // newly activated tab
//   // event.relatedTarget // previous active tab
// })
// $('a[data-bs-toggle="tab"]').on('shown.bs.tab', function(e) {
//   var _currentUrl2 = new URL(window.location);
//       _currentUrl2.searchParams.set('selectedFilterID', 'all-categories');
//       var getTabIdNumber = $(".tab-content-section .tab-content>.tab-pane.active").attr('id')
//       console.log(getTabIdNumber)
//       var tabNumber = getTabIdNumber.match(/\d/g);
//       tabNumber = tabNumber.join("");
//       // tabNumber += 1
//       // tabNumber = Number(tabNumber) + 1;
//       tabNumber = + tabNumber + 1;
//       if (getTabIdNumber != '') {
//         // radiobtnLabelName += `#`
//         _currentUrl2.searchParams.set('selectedFilterID', 'all-categories#'  + tabNumber);
//       }
//       window.history.pushState({ path: _currentUrl2.href }, '' , _currentUrl2.href);
// })
// Show hide Child categories Function
function initProductsCardsChildCategory() {
  var radioButtons = $('.product-filter-sidebar .accordion-item .accordion-header .checkboxes-wrap input');
  $('.product-filter-sidebar .accordion-item .accordion-collapse .checkboxes-wrap input').click(function () {
// console.log("long plan cards child category");
    var ck_box = $('.active .product-filter-sidebar .accordion-item .accordion-collapse .checkboxes-wrap input[type="checkbox"]:checked').length;
    // console.log(ck_box)
    if(ck_box === 0) {
      $(this).parents('li').addClass('dontclick')
      $(this).prop("checked", true);
    } else {
      $(this).parents('li').removeClass('dontclick')
    }
    $(this).parents('li.accordion-item').siblings().find("input:checkbox").prop("checked", false);
    $(this).parents('li.accordion-item').find("input:radio").prop("checked", true);
    var checkboxValues = [];
    $(this).closest('.container').find('.product-filter-sidebar .accordion-item .accordion-collapse .checkboxes-wrap input:checked').each(function (index,elem) {
      checkboxValues.push($(elem).val());
    });
    var getAllCategoriesCard = $(this).closest('.container').find(".filter-wrap > .cat-box > div");
    var getCurrentCategoryCard = [];
    // console.log(checkboxValues, getCurrentCategoryCard);
    $(getAllCategoriesCard).hide();
    checkboxValues.forEach((checkBoxValues) => {
      getCurrentCategoryCard.push(
        //$("#filter-wrap > .cat-box > div[sub-category~='" + checkBoxValues + "']");
        $(this).closest('.container').find(".filter-wrap > .cat-box > div[sub-category~='" + checkBoxValues + "']")
      );
    });
    getCurrentCategoryCard.forEach((activeCard) => {
      $(activeCard).show();
    });
  });
}
// Reset Button Function
function initProductsCardsresetButton() {
  $(".reset-filters-btn").click(function () {
    var getAllCategoriesCard = $(this).closest('.row').find(".filter-wrap > .cat-box > div");
    $(getAllCategoriesCard).show();
    $(this).closest('.row').find(".accordion-flush li.active-item .accordion-collapse").removeClass("show");
    $(this).closest('.row').find(".accordion-flush li.active-item .accordion-button").addClass("collapsed");
    $(this).closest('.row').find(".accordion").find("input:checkbox").prop("checked", false);
    $(this).closest('.row').find(".accordion").find("input:radio").prop("checked", false);
    $(this).closest('.row').find(".accordion-flush .accordion-collapse.activeradio").collapse("hide");
    $(this).closest('.row').find(".accordion-flush .accordion-collapse.activeradio").removeClass("show");
    $(this).closest('.row').find(".accordion-flush .accordion-collapse.activeradio").addClass("collapse");
    $(this).closest('.row').find(".checkbuttons .accordion-button").addClass("collapsed");
    $(this).closest('.row').find('.p-category-list-wrap li.accordion-item').removeClass('active-item');
    $(this).closest('.row').addClass('reset')
    $(this).closest('.row').find(".accordion-item input[data-label='all-contracts']").prop("checked", true);
  });
}
function productsCardsget_query(){
  var url = document.location.href;
  var qs = url.substring(url.indexOf('?') + 1).split('&');
  for(var i = 0, result = {}; i < qs.length; i++){
      qs[i] = qs[i].split('=');
      result[qs[i][0]] = decodeURIComponent(qs[i][1]);
  }
  var queryExist = (result.selectedFilterID === undefined)
  // console.log(queryExist)
  var getTabId = window.location.hash;
  var cleargetTabId = getTabId.replace("#","");
  var lengthofTabs = $(".cardsFilterTabs .nav-tabs-section .nav-tabs").children('.nav-item').length;
  
  if(!queryExist) {
    if(cleargetTabId > lengthofTabs) {
      // console.warn('insterted number is higher than tabs')
      var url = window.location.href;
      if(url.indexOf("?") > 0) {
        url = url.substring(0, url.indexOf("?"));
      } 
      url += "";
      window.location.replace(url);
    } else if (getTabId == '') {
      // console.warn('it is time to run only category condition');
      $(".withoutTabsFilters .product-filter-sidebar .accordion-item .accordion-header .checkboxes-wrap input").each(function(index, value) {
        var getLabelRadio = $(this).closest('.container').find(value);
        var getValueUrl = result.selectedFilterID
        var getActiveRadioLabel = $(value).attr('data-label')

        // console.log(getLabelRadio, getValueUrl)
        if($(getLabelRadio).attr('data-label') === getValueUrl) {
          let activeRadioValue = $(getLabelRadio).attr('value')
          $(this).prop("checked", true)
          $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
          var getAllCategoriesCard = $('.withoutTabsFilters').find(".filter-wrap > .cat-box > div");
              $(getAllCategoriesCard).each((index, elem) => {
                if($(elem).attr('main-category') === activeRadioValue) {
                  $(elem).show()
                } else {
                  $(elem).hide()
                }
              }); 
          
        }
        else {
          // console.warn('else without Tabs working')
          if (getValueUrl === 'all-contracts') {
            // console.log('inside all categories')
            var getAllCategoriesCard = $('.withoutTabsFilters').find(".filter-wrap > .cat-box > div");
            $(getAllCategoriesCard).each((index, elem) => {
              $(elem).show()
            });
          } else {
            // console.log('outside all categories');
          }
        }
      })
      $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").each(function(index, element) {
        $(element).find('.checkboxes-wrap input').each(function(indexr, radior){
          $(radior).addClass('checkedAllDefault' + indexr)
          // console.log('working' + indexr)
          if($(radior).hasClass('checkedAllDefault0')) {
            $(this).prop("checked", true);
            $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
          }
        })
      })
    } else {
        // console.warn('it is time to run only tab and category condition')
        $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").removeClass('show');
        $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").removeClass('active');
        $(`.cardsFilterTabs .tab-content-section .tab-content>.tab-pane:nth-child(${cleargetTabId})`).addClass('show');
        $(`.cardsFilterTabs .tab-content-section .tab-content>.tab-pane:nth-child(${cleargetTabId})`).addClass('active');
        $(`.tabs-section.tab-center .nav-tabs .nav-item .nav-link`).removeClass('active');
        $(`.tabs-section.tab-center .nav-tabs .nav-item:nth-child(${cleargetTabId}) .nav-link`).addClass('active');
        $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").each(function(index, element) {
          $(element).find('.checkboxes-wrap input').each(function(indexr, radior){
            $(radior).addClass('checkedAllTab' + indexr)
            if($(radior).hasClass('checkedAllTab0')) {
              $(this).prop("checked", true);
              $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
            }
          })
        })
        var getValueUrl = result.selectedFilterID.split('#')[0]
        $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane .product-filter-sidebar .accordion-item .accordion-header .checkboxes-wrap input").each(function(index, value) {
          var getLabelRadio = $(this).closest('.container').find(value).attr('data-label');
          if(getLabelRadio === getValueUrl) {
            let getActiveRadio = $('.cardsFilterTabs .tab-content-section .tab-content>.tab-pane.active').find(value)
            let activeRadioValue = $(getActiveRadio).attr('value')
            // console.log(activeRadioValue)
            if($(getActiveRadio).attr('data-label') === getValueUrl) {
              $(this).prop("checked", true)
              $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
              var getAllCategoriesCard = $('.cardsFilterTabs .tab-content-section .tab-content>.tab-pane.active').find(".filter-wrap > .cat-box > div");
              $(getAllCategoriesCard).each((index, elem) => {
                if($(elem).attr('main-category') === activeRadioValue) {
                  $(elem).show()
                } else {
                  $(elem).hide()
                }
              }); 
            }
            $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").not(".active").each(function(index, element) {
              $(element).not(".active").find('.checkboxes-wrap input').each(function(indexr, radior){
                $(radior).addClass('checkedAll' + indexr)
                if($(radior).hasClass('checkedAll0')) {
                  $(this).prop("checked", true);
                  $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
                }
              })
            })
          } 
          // else {
          //   var getAllCategoriesCard = $('.cardsFilterTabs .tab-content-section .tab-content>.tab-pane').find(".filter-wrap > .cat-box > div");
          //   $(getAllCategoriesCard).each((index, elem) => {
          //     $(elem).show()
          //   }); 
          // }
          // else if (getValueUrl === 'all-categories') {
          //   console.warn('all categories tab')
          //   var getAllCategoriesCard = $('.cardsFilterTabs .tab-content-section .tab-content>.tab-pane.active').find(".filter-wrap > .cat-box > div");
          //   $(getAllCategoriesCard).each((index, elem) => {
          //     $(elem).show()
          //   });
          // }
          else {
            // console.log('else with tabs radio label and url')
            if (getValueUrl === 'all-contracts') {
              // console.log('inside all categories')
              var getAllCategoriesCard = $('.cardsFilterTabs .tab-content-section .tab-content>.tab-pane.active').find(".filter-wrap > .cat-box > div");
              $(getAllCategoriesCard).each((index, elem) => {
                $(elem).show()
              });
            } else {
              // console.log('outside all categories')
              $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane.active").each(function(index, element) {
                var url = new URL(window.location.href);
                var search_params = url.searchParams;
                var filtereditem = search_params.get('selectedFilterID');
                if ($(element).find(".checkboxes-wrap input[data-label='" + filtereditem + "']").length > 0) {
                  $(element).find('.checkboxes-wrap input').each(function(indexr, radior){
                    if($(radior).attr('data-label') === filtereditem) {
                      let activeRadioValue = $(radior).attr('value')
                      $(this).prop("checked", true)
                      $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
                      var checkboxValues = [];
                      $(this).closest('.container').find('.product-filter-sidebar .accordion-item .accordion-header input:checked').each(function (
                        index,
                        elem
                      ) {
                        checkboxValues.push($(elem).val());
                      });

                      var getAllCategoriesCard = $(this).closest('.container').find(".filter-wrap > .cat-box > div");
                      var getCurrentCategoryCard = [];
          
                      $(getAllCategoriesCard).hide();
                      checkboxValues.forEach((checkBoxValues) => {
                        getCurrentCategoryCard.push(
                          $(this).closest('.container').find(".filter-wrap > .cat-box > div[main-category~='" + activeRadioValue + "']")
                        );
                      });
                      getCurrentCategoryCard.forEach((activeCard) => {
                        $(activeCard).show();
                      });
                      
                    } else if (filtereditem === 'all-contracts') {
                      var getAllCategoriesCard = $('.tab-content-section .tab-content>.tab-pane.active').find('.filter-wrap > .cat-box > div');
                      $(getAllCategoriesCard).show();
                    } 
                    
                  })
                } else {
                  // console.log('all ctas asd')
                  var url = new URL(window.location.href);
                  var search_params = url.searchParams;
                  search_params.set('selectedFilterID', 'all-contracts');
                  url.search = search_params.toString();
                  var new_url = url.toString();
                  history.pushState({}, null, new_url);
                }
              })
              // let getActiveRadio = $('.cardsFilterTabs .tab-content-section .tab-content>.tab-pane.active').find(value)
              // let activeRadioLabel = $(getActiveRadio).attr('data-label')
              // console.log(getActiveRadio)
              // console.log(getLabelRadio)
              // var url = new URL(window.location.href);
              // var search_params = url.searchParams;
              // search_params.set('selectedFilterID', 'all-contracts');
              // url.search = search_params.toString();
              // var new_url = url.toString();
              // history.pushState({}, null, new_url);
              // const currentUrl = new URL(window.location.href);
              // currentUrl.searchParams.set('selectedFilterID', activeRadioLabel);
              // window.history.pushState({ path: currentUrl.href }, '', currentUrl.href);
            }
            // var url = window.location.href;
            // if(url.indexOf("?") > 0) {
            //   url = url.substring(0, url.indexOf("?"));
            // } 
            // url += "?selectedFilterID=all-categories#1";
            // window.location.replace(url);
          }
        });
    }
    // var getValueRadio = $(value).attr('value');
    
  } else {
    // console.warn('it is time to run no condition')
    $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").each(function(index, element) {
      $(element).find('.checkboxes-wrap input').each(function(indexr, radior){
        $(radior).addClass('checkedAllDefault' + indexr)
        // console.log('working' + indexr)
        if($(radior).hasClass('checkedAllDefault0')) {
          $(this).prop("checked", true);
          $(this).closest(".accordion-item").find("input:checkbox").prop("checked", true);
        }
      })
    })
  }
}
function setDynamicIdsCards () {
  $(document).find(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").each(function (index, element) {
    var getTabDivID = $(this).attr('id');
    var newTabID = getTabDivID + '-' + index
    $(this).attr('id', newTabID)
    $(this).addClass("productCardsTabs" + index);
    
    $(".productCardsTabs" + index).find(".product-filter-sidebar .accordion-item .accordion-header .checkboxes-wrap input").each(function (index) {
      var getInputID = $(this).attr('id');
      var newInputID = getInputID + '-' + newTabID
      $(this).attr('id', newInputID)

      var getInputValue = $(this).attr('value');
      var newInputValue = getInputValue + '-' + newTabID
      $(this).attr('value', newInputValue)

      var getInputName = $(this).attr('name');
      var newInputName = getInputName + '-' + newTabID
      $(this).attr('name', newInputName)
      
    })
    
    $(".productCardsTabs" + index).find(".product-filter-sidebar .accordion-item .accordion-header .checkboxes-wrap label").each(function (index) {
      var getLabelFor = $(this).attr('for');
      var newLabelFor = getLabelFor + '-' + newTabID
      $(this).attr('for', newLabelFor)
    })
    $(".productCardsTabs" + index).find(".filter-wrap > .cat-box > div").each(function (index) {
      var getMainCategory = $(this).attr('main-category');
      var newMainCategory = getMainCategory + '-' + newTabID
      $(this).attr('main-category', newMainCategory)
    })
    
  })

  $(document).find(".tabs-section.tab-center.cardsFilterTabs .nav-tabs .nav-item").each(function (index) {
    var getTabDivID = $(this).children('button').attr('data-bs-target');
    var newTabID = getTabDivID + '-' + index
    $(this).children('button').attr('data-bs-target', newTabID)
  })
  
}
$(document).ready(function () {
  // $(".cardsFilterTabs").find('.withoutTabsFilters').removeClass('withoutTabsFilters')
  // $(".cardsFilterTabs").removeClass("withoutTabsFilters");
  // console.log($(".cardsFilterTabs"))
  $(".cardsFilterTabs .withoutTabsFilters").each(function(index, wtabs) {
    $(wtabs).removeClass('withoutTabsFilters')
  })
  setDynamicIdsCards();
  initProductsCardsChildCategory();
  initProductsCardsresetButton();
  initCompareCardCarousel();
  initProductsCardsParentCategory();
  productsCardsget_query();
  // if($('.cardsFilterTabs .tab-content-section .tab-content>.tab-pane').find('li.active-item').length !== 0) {
  //   console.log($(this).parents('.tab-pane'))
  // }
  $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").each(function (index,elem) {
    // if((elem).hasClass('active-item')) {
    //   $(this).parents('.compare-card-wexpand-wrapper').addClass('hello')
    // }
    // if((elem).children('li.active-item').length > 0) {
    //   alert($(this))
    // }
    if ($(this).find('li.active-item').length !== 0) {
      $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").removeClass('show');
      $(".cardsFilterTabs .tab-content-section .tab-content>.tab-pane").removeClass('active');
      $(this).addClass('show');
      $(this).addClass('active');
      let activeTabID = $(this).attr('id')
      // console.log(activeTabID)
      $('.nav-tabs-section .nav-tabs .nav-item .nav-link').removeClass('active');
      $(".nav-tabs-section .nav-tabs .nav-item .nav-link[aria-controls~='" + activeTabID + "']").addClass('active')
    }
  })
  
//   $('.same-height-boxes').each(function(){  
//     var highestBox = 0;
//     $(this).find('.compare-card-wexpand-box').each(function(){
//       if($(this).height() > highestBox){  
//           highestBox = $(this).height();  
//     }
//   })
//   $(this).find('.compare-card-wexpand-box').css('min-height', highestBox)
// });    
  
  
  // Compare Cards Cards
  // function compareCardsLeadForm(receiveElement) {
  //   var currentPagePath = window.location.pathname
  //   var DisplayName = receiveElement.parents('.compare-card-wexpand-wrapper .compare-card-wexpand-box').find('.sec-main-headings h6').text().trim();
  //   var PaymentAmount = receiveElement.parents('.compare-card-wexpand-wrapper .compare-card-wexpand-box').find('.sec-main-headings h3').text().replace(/[^\d.-]/g, '');
  //   var moreinfoPoup = receiveElement.attr('moreinfopopup');
  //   location.href = `/smb-form.html?Name=${DisplayName}&Amount=${PaymentAmount}&PreviousPage=${currentPagePath}&moreinfoPopup=${moreinfoPoup}`;
  // }
  // // getting all buttons inside select products cards component and adding function    
  // function btncompareCardsLeadForm () {
  //     let targetedBtn = document.querySelectorAll('.compare-card-wexpand-wrapper .content-wrapper .price-and-action .btn')
  //     targetedBtn.forEach(element => {
  //         element.addEventListener('click', function(e) {
  //             e.preventDefault()
  //             compareCardsLeadForm($(this)) 
  //         })
  //     });
  // }
  // btncompareCardsLeadForm()
});