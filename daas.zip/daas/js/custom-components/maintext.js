import { swiperInit } from "../swipernwtcon";

function mainTextslider() {
    $(document).find(".eand-main-text-slider").each(function (index) {
        $(this).addClass("cpSlider" + index);
        var $maintextslider = $(this);
        $maintextslider.find(".swiper-button-next").addClass("cpRight" + index);
        $maintextslider.find(".swiper-button-prev").addClass("cpLeft" + index);
        var etiSlidesCount = $maintextslider.find(".swiper-slide").length;
        $(this).addClass("cp-tiles-" + etiSlidesCount); //console.log(etiSlidesCount);

        var maintextslider = swiperInit(".cpSlider" + index + " .swiper", {
            slidesPerView: 1,
            spaceBetween: 16,
            navigation: {
                nextEl: ".swiper-button-next.cpRight" + index,
                prevEl: ".swiper-button-prev.cpLeft" + index,
                clickable: true
            },
            breakpoints: {
                310: {
                    slidesPerView: 1,
                    spaceBetween: 16
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 16
                },
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 24
                },
                1200: {
                    slidesPerView: 3,
                    spaceBetween: 24
                }
            }
        });
    });
} // register the event handlers


$(document).ready(function () {
    if ($(window).innerWidth() >= 768) {
        mainTextslider();
    } else {}
});