/**
* v###version###
* Mega Menu

(function (window) {*/

$(document).ready(function() {

      $(window).scroll(function () {
        var sticky = $(".main-menu-desktop .navbar-default"),
          scroll = $(window).scrollTop();

        if (scroll >= 1) {
          sticky.addClass("fixedNav");
        } else {
          sticky.removeClass("fixedNav");
        }
      });

      // hover on menu add class to handle backdrop
      $(".main-mega-menu-desktop .navbar-items .navbar-nav > li").mouseover(
        function (e) {
          var $backdropHeight = $(".main-mega-menu-desktop");
          if ($(this).closest(".link-only").hasClass("link-only")) {
            //  $backdropHeight.removeClass('backdrop');
            //  $backdropHeight.css('height', 100 + '%')
          } else {
            var body = document.body,
              html = document.documentElement;
            var height = Math.max(
              body.scrollHeight,
              body.offsetHeight,
              html.clientHeight,
              html.scrollHeight,
              html.offsetHeight
            );

            $backdropHeight.addClass("backdrop");
            $backdropHeight.css("height", height);
            $backdropHeight.css("z-index", 999);
            $(".mega-dropdown.search-4-0.open").removeClass("open");
            $(".main-mega-menu-desktop").removeClass("backdrop-search-4-0");
          }
        }
      );
      $(".main-mega-menu-desktop .navbar-items .navbar-nav > li").mouseleave(
        function (e) {
          $(".main-mega-menu-desktop").removeClass("backdrop");
          $(".main-mega-menu-desktop").css("height", 100 + "%");
        }
      );

      // register the event handlers
      $(document).ready(function () {
        $(".hamburger").click(function () {
          var ua = navigator.userAgent.toLowerCase();
          if (ua.indexOf("safari") != -1) {
            if (ua.indexOf("chrome") > -1) {
            } else {
              // Safari
              $("body").toggleClass("safari");
            }
          }
          $(this).toggleClass("is-active");
          $(".main-menu-mobile").toggleClass("mob-visible");
          $("body").toggleClass("freeze");
        });

        $(document).mouseup(function (e) {
          var signOutWrap = $(".sub-account-menu-wrap");
          var container = $(
            ".sub-account-menu-wrap, .navbar-left .desktop-menu-link"
          );
          if (!container.is(e.target) && container.has(e.target).length === 0) {
            signOutWrap.hide();
            $(".logedin-user").removeClass("active");
          }
        });

        var host = window.location.host;
        if (host.indexOf("qa-dx") == -1) {
          host = "https://" + host;
        } else {
          host = "http://" + host;
        }
        //var host = 'http://qa-dx.etisalat.ae';

        var currLang = $("html").attr("lang");

        var searchIframe = document.createElement("iframe");
        searchIframe.setAttribute(
          "src",
          host + "/b2c/advanced-search.html?locale=" + currLang + ""
        );
        var iFrameLoaded = true;
        // search overlay active in-active

        $(".search-link a svg")
          .off("click")
          .on("click", function (e) {
            e.preventDefault();

            $(".search-overlay").addClass("active");

            if (iFrameLoaded) {
              $(".search-overlay .search-body").append(searchIframe);

              iFrameLoaded = false;
            }

            $("body").addClass("freeze");

            //google analyticss
            if (typeof window.dataLayer !== "undefined") {
              window.dataLayer.push({
                event: "searchStart",
                info1: "search", //String - Event Category
                info2: "start", //String - Event Action
                info3: "", //String - Blank
              });
            }
          });

        $(".search-close")
          .off("click")
          .on("click", function () {
            $(".search-overlay").removeClass("active");
            $("body").removeClass("freeze");
          });

        // not using for the moment
        // var currentPath = window.location.href;
        // if( currentPath.indexOf('/rd-login') === -1 ){
        //     sessionStorage.setItem("returnURL", currentPath);
        // }


        //search icon on menu
        $(".mobile-search-icon .nav-item .nav-link-icon").on(
          "click",
          function (e) {
            e.stopPropagation();
            $(".mobile-search-icon .nav-expand").toggleClass("active");
          }
        );
        $(".nav-wrap .mobile-search-icon .popup-close-blk svg").on(
          "click",
          function (e) {
            e.stopPropagation();
            $(".mobile-search-icon .nav-expand").removeClass("active");
          }
        );
        var navExpand = [].slice.call(document.querySelectorAll(".nav-expand"));
        // var backLink = '<li class="nav-item">'+
        //     '<a class="nav-link nav-back-link" href="javascript:;">'+
        //     '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="12px" height="12px" viewBox="26 26 12 12" enable-background="new 26 26 12 12" xml:space="preserve" class="nav-link-icon replaced-svg">'+
        //     '<g><path fill="#554D56" d="M28.85,36.725c-0.3,0.301-0.3,0.766,0,1.051c0.286,0.3,0.75,0.3,1.05,0l5.25-5.25   c0.3-0.301,0.3-0.765,0-1.051l-5.25-5.25c-0.3-0.3-0.765-0.3-1.05,0c-0.3,0.286-0.3,0.75,0,1.05L33.575,32L28.85,36.725z"></path></g>'+
        //     '</svg>'+
        //     'main menu</a>'+
        //     '</li>';

        navExpand.forEach(function (item) {
          //  item.querySelector('.nav-expand-content').insertAdjacentHTML('afterbegin', backLink);
          item
            .querySelector(".nav-link")
            .addEventListener("click", function () {
              item.classList.add("active");
              if (this.classList.contains("search-link")) {
                $(".nav-drill").addClass("search-nav-drill");
              }
            });
          if (item.querySelector(".nav-back-link")) {
            item
              .querySelector(".nav-back-link")
              .addEventListener("click", function () {
                item.classList.remove("active");
                if ($(".nav-drill").hasClass("search-nav-drill")) {
                  $(".nav-drill").removeClass("search-nav-drill");
                }
              });
          }
        });

        // ---------------------------------------
        // not-so-important stuff starts here

        var ham = document.getElementById("m-hamburger");
        if (ham) {
          ham.addEventListener("click", function () {
            document.body.classList.toggle("nav-is-toggled");
          });
        }

        $(document).mouseup(function(e) {
          var selectBox = $('.topnav-dropdown');
          if (!selectBox.is(e.target) && selectBox.has(e.target).length === 0)
          {
            $('.topnav-dropdown .dropdown-menu').hide();
            $('.topnav-dropdown').removeClass('open');
          }
        });
        $(document).on('keydown', function(event) {
          if (event.key == "Escape") {
            $('.topnav-dropdown .dropdown-menu').hide();
            $('.topnav-dropdown').removeClass('open');
          }
        });

        $(document).ready(function () {
          $('.topnav-dropdown .dropdown-toggle').click(function(){
            $('.topnav-dropdown').toggleClass('open');
            $('.topnav-dropdown .dropdown-menu').toggle();
          });
          $(window).scroll(function(){
            var scroll = $(window).scrollTop();
            var onlyDesktop = $(window).width();
            if (scroll >= 150 && onlyDesktop > 992) {
              $('body').addClass('hide-topbar');
              if($("body").hasClass("push-menu-open")) {
                $('.inc-push-meu-icon a').click();
              }
            } else {
              $('body').removeClass('hide-topbar');
            }
          });
        });

        //--------------------
        // mobile sub menus

        $(".mega-dropdown-mob a").click(function () {
          $(this)
            .closest("ul")
            .children(".mega-dropdown-mob-menu")
            .slideToggle("100");
          $(this).parent().toggleClass("open");
        });
      });

      //google analytics page view
      if (typeof window.dataLayer !== "undefined") {
        //page view
        window.dataLayer.push({
          event: "PageView",
          page_details: {
            page_type: pageInfo(document.URL, "page_type"), //String - Page Type
            category: pageInfo(document.URL, "category"), //String - Page Category
            subcategory: pageInfo(document.URL, "subcategory"), //String - Page Subcategory
            url: document.URL, //JS command - Page URL
            title: document.title, //JS command - Page Title
            name: document.location.pathname, //JS command - Page Pathname
            language: document.documentElement.lang, //JS command - Page Language
          },

          user_details: {
            login_status: "", //String - "Logged In" or "Not Logged In"
            user_id: "", //String - Account ID
          },
        });
      }
      //google analytics menu item click GA
      $(".menu-items-wrapper .sub-menu a").on("click", function (e) {
        if (typeof window.dataLayer !== "undefined") {
          var link = e.target.innerText.trim().replace(/ /g, "_");
          var eventLabel =
            e.target.parentElement.parentElement.firstElementChild.innerText
              .trim()
              .replace(/ /g, "_");
          window.dataLayer.push({
            event: "navigation",
            eventCategory: "navigation",
            eventAction: "top",
            eventLabel: eventLabel,
            Link: link,
          });
        }
      });

      function pageInfo(url, type) {
        var respose = "";
        switch (type) {
          case "page_type":
            respose = "CMS";
            if (url.indexOf("eshop") !== -1) {
              respose = "eShop";
            }
            break;

          case "category":
            respose = "";
            if (url.indexOf("category") !== -1) {
              respose = getParameterByName("category", url);
            }
            break;

          case "subcategory":
            respose = "";
            if (url.indexOf("subcategory") !== -1) {
              respose = getParameterByName("subcategory", url);
            }
            break;
        }

        return respose;
      }
      function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
          results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return "";
        return decodeURIComponent(results[2].replace(/\+/g, " "));
      }

      var menuLinks = document.querySelectorAll('.topnav-dropdown .dropdown-menu li a');
      var menuSelected = document.querySelector('.topnav-dropdown .dropdown-toggle');
      var dropdownMenuText = document.querySelector('.topnav-dropdown .dropdown-menu li a').innerText;
      menuLinks.forEach((menuLink) => {
        menuLink.addEventListener("click", () => {
          let selectedOption = menuLink.innerText;
          localStorage.setItem('dropdownValue', selectedOption);
          var getValue = localStorage.getItem('dropdownValue');
          menuSelected.innerHTML = getValue;
        });
      });
      let prevActivesMenu = localStorage.getItem('dropdownValueAnchor') ? localStorage.getItem('dropdownValueAnchor') : document.getElementById('smenu-1').id;
      if(prevActivesMenu) {
        document.getElementById(prevActivesMenu).classList.add('active')
      } else {
        document.getElementById('smenu-1').classList.add('active')
      }
      for (let i = 0; i < menuLinks.length; i++) {
        menuLinks[i].onclick = function() {
          for (let j = 0; j < menuLinks.length; j++) {
            menuLinks[j].classList.remove('active');
          }
          this.classList.add('active');
          localStorage.setItem('dropdownValueAnchor', this.id);
        }
      }
      if (menuSelected.innerText == '') {
        menuSelected.innerText = dropdownMenuText;
      } else {
        var activeLinkValue = document.querySelector('.topnav-dropdown .dropdown-menu li a.active').innerText;
        localStorage.setItem('dropdownValue', activeLinkValue);
        menuSelected.innerText = localStorage.getItem('dropdownValue');
      }
      
      //Top Nav Mobile Dropdown
      var megaMenuUrl = window.location.href;
        if (megaMenuUrl.indexOf("smb") > -1) {
          document.getElementById('smenu-2').classList.remove('active');
          document.getElementById('smenu-1').classList.add('active');
          menuSelected.innerText = dropdownMenuText;
        } else if (megaMenuUrl.indexOf("enterprise") > -1) {
          document.getElementById('smenu-1').classList.remove('active');
          document.getElementById('smenu-2').classList.add('active');
          menuSelected.innerText = document.getElementById('smenu-2').innerText;
        }



        var mmenuLinks = document.querySelectorAll('.mega-dropdown-mob-menu .nav-item .dropdown-nav-site-switch');
        mmenuLinks.forEach((mmenuLink) => {
          mmenuLink.addEventListener("click", () => {
            let mselectedOption = mmenuLink.innerText;
            localStorage.setItem('mdropdownValue', mselectedOption);
          });

        });

        let mprevActivesMenu = localStorage.getItem('mdropdownValueAnchor') ? localStorage.getItem('mdropdownValueAnchor') : document.getElementById('m-menu-1').id;
        if(mprevActivesMenu) {
          document.getElementById(mprevActivesMenu).classList.add('active')
        }
        else {
          document.getElementById('m-menu-1').classList.add('active')
        }

        for (let i = 0; i < mmenuLinks.length; i++) {
          mmenuLinks[i].onclick = function() {
                for (let j = 0; j < mmenuLinks.length; j++) {
                  mmenuLinks[j].classList.remove('active');
                }
                this.classList.add('active');
                localStorage.setItem('mdropdownValueAnchor', this.id);
            }

        }
        var mobileMegaMenuUrl = window.location.href;
        if (mobileMegaMenuUrl.indexOf("smb") > -1) {
          document.getElementById('m-menu-2').classList.remove('active');
          document.getElementById('m-menu-1').classList.add('active');
        } else if (mobileMegaMenuUrl.indexOf("enterprise") > -1) {
          document.getElementById('m-menu-1').classList.remove('active');
          document.getElementById('m-menu-2').classList.add('active');
        }

});
/*})(window);*/
