function initMobilePlanCarousel() {
  $(document).find(".mobile-plan-cards-wrap").each(function (index) {
    $(this).addClass('slideronPage' + index);
    var $compareCardCarousel = $(this);
    $compareCardCarousel.find(".swiper-pagination").addClass("mplanCarousel" + index);
    var swiperSlideLength = $('.slideronPage' + index + " .mobile-plan-cards-carousel .swiper-slide").length;
    $(this).addClass("swiper-with-" + swiperSlideLength + "-slides");

    if ($(window).width() > 992) {
      if (swiperSlideLength <= 4) {
        $(".slideronPage" + index).addClass("destroyed");
        $(".slideronPage" + index).find(".swiper-wrapper").addClass("row");
        $(".slideronPage" + index).find(".swiper-wrapper.row").children().removeClass("swiper-slide");
        $(".slideronPage" + index).find(".swiper-navigation").addClass("deactive");
      } else {
        $(".slideronPage" + index).find(".swiper-wrapper").removeClass("row");
        var $carouselSliderwithProgress = new Swiper(".slideronPage" + index + " .mobile-plan-cards-carousel", {
          slidesPerGroupSkip: 1,
          slidesPerView: 4.2,
          keyboard: {
            enabled: true
          },
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
            type: "progressbar"
          },
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
          },
          breakpoints: {
            1099: {
              slidesPerView: 4.2,
              spaceBetween: 23
            },
            768: {
              slidesPerView: 2.65,
              spaceBetween: 23
            },
            100: {
              slidesPerView: 1.2,
              spaceBetween: 15,
              pagination: {
                type: "bullets",
                clickable: true
              },
              navigation: false
            }
          }
        });
      }
    } else {
      $(".slideronPage" + index).find(".swiper-wrapper").removeClass("row");
      var $carouselSliderwithProgress = new Swiper(".slideronPage" + index + " .mobile-plan-cards-carousel", {
        slidesPerGroupSkip: 1,
        slidesPerView: 4.2,
        keyboard: {
          enabled: true
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
          type: "progressbar"
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
        },
        breakpoints: {
          1099: {
            slidesPerView: 4.2,
            spaceBetween: 23
          },
          768: {
            slidesPerView: 2.65,
            spaceBetween: 23
          },
          100: {
            slidesPerView: 1.2,
            spaceBetween: 15,
            pagination: {
              type: "bullets",
              clickable: true
            },
            navigation: false
          }
        }
      });
    }
  });
  $(document).find(".withOutSlider").each(function () {
    $(this).addClass("destroyed");
    $(this).find(".swiper-wrapper").addClass("row");
    $(this).find(".swiper-wrapper.row").children().removeClass("swiper-slide");
  });
}

$(document).ready(function () {
  // Compare Cards Cards
  function mobilePlanCardsLeadForm(receiveElement) {
    var currentPagePath = window.location.pathname;
    var getAnchorLink = $(receiveElement).attr('href')
    console.log(getAnchorLink)
    // var DisplayName;
    // var PaymentAmount;
    // var DisplayNameV1 = receiveElement.closest('.mobile-plan-box').find('.img-overlay-text > .overlay-badge + .sec-secondary-headings + .sec-main-headings').children(":first").text().trim(); //replace(/\s/g, '');

    // var DisplayNameV2 = receiveElement.closest('.mobile-plan-box').find('.img-overlay-text .sec-single-subheadings h3').text(); //replace(/\s/g, '');

    // var PaymentAmount1 = receiveElement.closest('.mobile-plan-box').find('.img-overlay-text .price-and-action .sec-main-headings').children(":first").children('span').text().trim(); //.replace(/\s/g, '');

    // var PaymentAmount2 = receiveElement.closest('.mobile-plan-box').find('.img-overlay-text .price-and-action .sec-main-headings').children(":nth-child(2)").children('span').text().trim(); //.replace(/\s/g, '');

    // var contractTime = receiveElement.closest('.mobile-plan-box').find('.content-wrapper .content-table .contract-row strong').text().trim(); //.replace(/\s/g, '');

    var moreinfoPoup = receiveElement.attr('moreinfopopup');

    // if (DisplayNameV1 != '') {
    //   DisplayName = DisplayNameV1;
    // } else if (DisplayNameV2 != '') {
    //   DisplayName = DisplayNameV2;
    // }

    // if (PaymentAmount1 != '') {
    //   PaymentAmount = PaymentAmount1;
    // } else if (PaymentAmount2 != '') {
    //   PaymentAmount = PaymentAmount2;
    // }
    location.href = getAnchorLink + "&productinfoPopup=".concat(moreinfoPoup)
    // location.href = "product-lead-order-form.html?productName=".concat(DisplayName, "&productPrice=").concat(PaymentAmount, "&productinfoPopup=").concat(moreinfoPoup, "&productContract=").concat(contractTime);
  } // getting all buttons inside select products cards component and adding function    


  function btnmobilePlanCardsLeadForm() {
    var targetedBtn = document.querySelectorAll('.mobile-plan-cards-wrap .mobile-plan-box .content .productLeadBTN');
    targetedBtn.forEach(function (element) {
      element.addEventListener('click', function (e) {
        e.preventDefault();
        mobilePlanCardsLeadForm($(this));
      });
    });
  }

  btnmobilePlanCardsLeadForm();
  initMobilePlanCarousel(); // popup

  $(".overlay-link").off("click").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    var dataLabel = $(this).attr("data-label");
    console.log(dataLabel);

    if (typeof dataLabel !== "undefined" && dataLabel !== "") {
      $("#" + dataLabel).addClass("show");
      $("body").addClass("freeze");
    }
  }); // close popup

  $(".fullscreen-overlay-wrap").off("click").on("click", ".modal-close", function (e) {
    e.stopPropagation();
    e.preventDefault();
    var currentOpendPopUp = $(this).closest(".overlay-modal");
    $(currentOpendPopUp).removeClass("show");
    $("body").removeClass("freeze");
  });
});