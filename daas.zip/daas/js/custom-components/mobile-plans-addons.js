$(document).ready(function () {
  $("#mobile-plan-addons-filter-menu").change(function(){
    var dropdownValue = this.value;
    var categoryList = $('.category-list-wrapper .category-list');
    for (var i = 0; i < categoryList.length; i++) {
      var listValue = categoryList[i].getAttribute("mobile-plan-addons-category");
      if (dropdownValue == listValue) {
        $('.category-list-wrapper .category-list').removeClass("mobile-plan-addons-active");
        categoryList[i].classList.add("mobile-plan-addons-active");
      }
      else if (dropdownValue == 'All') {
        $('.category-list-wrapper .category-list').addClass("mobile-plan-addons-active");
      }
    }
 });
});