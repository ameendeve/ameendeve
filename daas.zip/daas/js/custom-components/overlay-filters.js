$(document).ready(function () {
  $('.overlay-filters input[name="singleq"]').click(function () {
    var inputValue = $(this).attr("value");
    var targetBill = $("." + inputValue);
    $(".bill").not(targetBill).hide();
    $(targetBill).show();
  });
  $('.overlay-filters input[name="bulkq"]').click(function () {
    var inputValue = $(this).attr("value");
    var targetBill = $("." + inputValue);
    $(".bill").not(targetBill).hide();
    $(targetBill).show();
  });
   //trigger register the event handlers of aos animation on click
  $('.overlay-filters input[name="singleq"],.overlay-filters input[name="bulkq"] ').on('click', function () {
    $('.overlay-filters .bill *').removeClass('aos-animate');
    setTimeout(function () {
      $('.overlay-filters .bill *').addClass('aos-animate');
    }, 800);
  });
});
