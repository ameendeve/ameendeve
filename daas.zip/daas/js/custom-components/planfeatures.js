$(document).ready(function () {
    $('.btns-wrap .feature-btn-link').click(function (e) {
        var target = $(e.target).data('target');
        $(target).addClass('active show').siblings('.tab-pane.active').removeClass('active show');
    }); // active link

    $('.feature-btn-link').click(function () {
        $('.feature-btn-link').removeClass('active-link');

        if ($(this).hasClass('active-link')) {
            $(this).removeClass('active-link');
        } else {
            $(this).addClass('active-link');
        }
    });
});