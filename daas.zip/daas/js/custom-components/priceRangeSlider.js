      import ionRangeSlider from 'ion-rangeslider';
      var maxPriceValueCard = $('.maxPriceValue .eand-price-wrapper .price .sec-main-headings h2').text();
      Number(maxPriceValueCard);
       //price range slider start
       $(document).ready(function () {
        $(".priceRangeSlider").ionRangeSlider({
          type: "double",
          grid: false,
          prettify_enabled: false,
          min: 0,
          max: 2000,
          from: 350,
          to: 1500,
          max_postfix: ' AED',
          decorate_both: true
        });

        $(".priceRangeSliderCards").ionRangeSlider({
          type: "double",
          grid: false,
          prettify_enabled: false,
          min: 0,
          max: 2000,
          from: 0,
          to: 1999,
          max_postfix: ' AED',
          decorate_both: true,
          onChange: function (data) {
            $(".priceRange-wrapper .filter-wrap > .cat-box > div").each((index, elem) => {
              var productCard = $(elem).attr('data-price')
              if(productCard > data.from && productCard <= data.to) {
                $(elem).show()
              } else {
                $(elem).hide();
              }
            })
          }
        });
        var currencyName = 'AED'
        var theLanguage = $('html').attr("lang");
        if(theLanguage === "ar"){
          currencyName = 'درهم '
        }
  
        $("#priceRangeSlider63Laptops").ionRangeSlider({
          type: "double",
          grid: false,
          prettify_enabled: false,
          min: 0,
          max: maxPriceValueCard.replaceAll(",","").split('.')[0],
          from: 0,
          to: maxPriceValueCard.replaceAll(",","").split('.')[0],
          max_postfix: ' ' + currencyName,
          decorate_both: true,
          onChange: function (data) {
            $('#seeMoreTwo').hide();
            $('#seeMore').hide();
            var newTextToRange = $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g,'');
            $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange)
            $(".laptops-cards-wrap .smartphone-card").each((index, elem) => {
              var phoneCard = $(elem).attr('data-price');
              var visibleCards = $(".laptops-cards-wrap .smartphone-card").is(":visible");
              if(!visibleCards) {
                $(".laptops-cards-wrap #norecords").show();
              } else {
                $("#norecords").hide();
              }
              if(phoneCard > data.from && phoneCard <= data.to) {
                var singleBrand = $('.single-filter input[name="laptopBrands"]:checked').attr('data-label')
                var smartphoneCardsList = [];
                switch(true) {
                  // brand all
                  case singleBrand === 'allbrands' && singleBrand !== undefined:
                    if($(elem).attr('categoryname')) {
                      $(elem).show()
                    } else {
                      $(elem).hide()
                    } 
                  break;
                  // brand selected
                  case singleBrand !== 'allbrands' && singleBrand !== undefined:
                    if($(elem).attr('categoryname') === singleBrand) {
                      $(elem).show();
                      smartphoneCardsList.push(elem)
                    } else {
                      $(elem).hide()
                    }
                    // $('.single-filter input[name="laptopBrands"] + label .badge').each(function (index, value) {
                    //   var selectedBrandBoxes = $(".smartphone-card[categoryname='" + singleBrand + "']:visible").length;
                    //   var allBrandBoxes = $(".smartphone-card[categoryname]:visible").length;
                    //   if ($(value).attr('category') == 'allbrands') {
                    //       $(value).html(allBrandBoxes);
                    //   } else {
                    //       $(value).html(selectedBrandBoxes);
                    //   }
                    // });
                  break;
                  default : 
                  console.log('default case')
                }
              } else {
                $(elem).hide();
              }
            })
          }
        });

        $("#priceRangeSlider62Filters").ionRangeSlider({
            type: "double",
            grid: false,
            prettify_enabled: false,
            min: 0,
            max: maxPriceValueCard.replaceAll(",","").split('.')[0],
            from: 0,
            to: maxPriceValueCard.replaceAll(",","").split('.')[0],
            max_postfix: ' AED',
            decorate_both: true,
            onChange: function (data) {
              $('#seeMore').hide();
              $('#seeMoreTwo').css('display', 'none');
              var newTextToRange = $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
	            $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange)
              var checkedBrand = $('input[name="brands"]:checked').attr('data-label');
              var checkedColor = $('input[name="colors"]:checked').attr('data-color');
              var checkedSpace = $('input[name="storages"]:checked').attr('data-space');
              var checkedOs = $('input[name="osystems"]:checked').attr('data-os');

              $(".smartphone-card").each((index, elem) => {
                var phoneCard = $(elem).attr('data-price')
                var visibleCards = $(".smartphone-card").is(":visible");

                if(!visibleCards) {
                  $("#norecords").show();
                  $("#seeMore").hide();
                  $('#seeMoreTwo').hide();
                  $("input + label .badge").each(function (index, value) {
                    $(value).html('0');
                  });
                } else {
                  $("#norecords").hide();
                }
                if(phoneCard > data.from && phoneCard <= data.to) {
                  switch(true) {
                    // storage, os and brand checked
                    case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked') && $('input[name="osystems"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
                        console.log('storage, os and brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][colorname][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][colorname][categoryname='" + checkedBrand + "']:visible").length;
                          console.log(allBrandBoxesAll,allcolorBoxes)
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color, os and brand checked
                    case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked') && $('input[name="osystems"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
                        console.log('color, os and brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          console.log(allBrandBoxesAll,allcolorBoxes)
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color, storage and brand checked
                    case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked') && $('input[name="storages"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
                        console.log('color, storage and brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          console.log(allBrandBoxesAll,allcolorBoxes)
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color, storage and os checked
                    case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="osystems"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename') === checkedSpace) {
                        console.log('color, storage and os name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][categoryname][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][categoryname][storagename='" + checkedSpace + "']:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          console.log(allBrandBoxesAll,allcolorBoxes)
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color, os and brand checked
                    case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked') && $('input[name="colors"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
                        console.log('color, os and brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          console.log(allBrandBoxesAll,allcolorBoxes)
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color and brand checked
                    case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand) {
                        console.log('color and brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname][storagename][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname][storagename][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname][storagename][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']:visible").length;
                          console.log(allBrandBoxesAll,allcolorBoxes)
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // storage and brand checked
                    case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') === checkedBrand) {
                        console.log('storage and brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][colorname][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname][categoryname='" + checkedBrand + "']:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // os and brand checked
                    case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('osname') === checkedOs && $(elem).attr('categoryname') === checkedBrand) {
                        console.log('osname and brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname][categoryname='" + checkedBrand + "'][storagename]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname][categoryname='" + checkedBrand + "']:visible").length;
                          console.log(allBrandBoxesAll)
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color and storage checked
                    case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="storages"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace) {
                        console.log('storage and color name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][categoryname][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][categoryname][storagename='" + checkedSpace + "']:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color and os checked
                    case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="osystems"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs) {
                        console.log('os and color name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][categoryname][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][categoryname][storagename]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // storage and os checked
                    case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="osystems"]:not(:eq(0))').is(':checked'):
                      if($(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
                        console.log('os and storage name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][colorname][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][categoryname][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname][categoryname][storagename='" + checkedSpace + "']:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][colorname][categoryname]:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // operating systems checked
                    case $('input[name="osystems"]:not(:eq(0))').is(':checked') :
                      if($(elem).attr('osname') === checkedOs) {
                        console.log('os name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname][categoryname='" + catChecked + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename][categoryname][colorname='" + colorChecked + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname='" + checkedOs + "'][storagename='" + storageChecked + "'][categoryname][colorname]:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname][storagename][categoryname]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname='" + checkedOs + "'][storagename][colorname][categoryname]:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // color checked
                    case $('input[name="colors"]:not(:eq(0))').is(':checked') :
                      if($(elem).attr('colorname') === checkedColor) {
                        console.log('color name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname][storagename][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][storagename][categoryname][colorname='" + checkedColor + "']:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][categoryname][colorname='" + checkedColor + "']:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname][colorname='" + colorChecked + "'][storagename][categoryname]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname][storagename][colorname='" + checkedColor + "'][categoryname]:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // brand checked
                    case $('input[name="brands"]:not(:eq(0))').is(':checked') :
                      if($(elem).attr('categoryname') === checkedBrand) {
                        console.log('brand name checked price Range')
                        $(elem).show()
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allcolorBoxes = $(".smartphone-card[osname][storagename][colorname='" + colorChecked + "'][categoryname='" + checkedBrand + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][storagename][categoryname='" + checkedBrand + "'][colorname]:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][categoryname='" + checkedBrand + "'][colorname]:visible").length;
                          var allBrandBoxes = $(".smartphone-card[osname][colorname][storagename][categoryname='" + catChecked + "']:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname][storagename][colorname][categoryname='" + checkedBrand + "']:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // storage checked
                    case $('input[name="storages"]:not(:eq(0))').is(':checked') :
                      if($(elem).attr('storagename') === checkedSpace) {
                        console.log('storage name checked price Range')
                        $(elem).show();
                      } else {
                        $(elem).hide()
                      }
                      $("input + label .badge").each(function (index, value) {
                          var storageChecked = $(value).attr('space');
                          var colorChecked = $(value).attr('color');
                          var catChecked = $(value).attr('cat');
                          var osystemChecked = $(value).attr('osname');
                          var allBrandBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname][categoryname='" + catChecked + "']:visible").length;
                          var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][storagename='" + checkedSpace + "'][categoryname][colorname]:visible").length;
                          var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][categoryname][colorname]:visible").length;
                          var allcolorBoxes = $(".smartphone-card[osname][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "'][categoryname]:visible").length;
                          var allBrandBoxesAll = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname][categoryname]:visible").length;
                          if ($(value).attr('cat')) {
                            if ($(value).attr('cat') === 'allcategories') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allBrandBoxes);
                            }
                          } else if ($(value).attr('color')) {
                            if ($(value).attr('color') === 'allcolors') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allcolorBoxes);
                            }
                          } else if ($(value).attr('space')) {
                            if ($(value).attr('space') === 'allspaces') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allstorageBoxes);
                            }
                          } else if ($(value).attr('osname')) {
                            if ($(value).attr('osname') === 'allos') {
                              $(value).html(allBrandBoxesAll);
                            } else {
                              $(value).html(allosBoxes);
                            }
                          }
                      });
                    break;
                    // all not checked
                    default:
                      $(elem).show()
                      var visibleCardsShown = $(".smartphone-card:visible").length;
                      var x = 6;
                      $(".smartphone-card:visible").addClass('hideCard');
                      $('.smartphone-cards-box .smartphone-card:visible:lt('+x+')').addClass('showCard');
                      $('.smartphone-cards-box .smartphone-card:visible:lt('+x+')').removeClass('hideCard');
                      $('#seeMoreTwo').click(function () {
                        x= (x+3 <= visibleCardsShown) ? x+3 : visibleCardsShown;
                        $('.smartphone-cards-box .smartphone-card:visible:lt('+x+')').addClass('showCard');
                        $('.smartphone-cards-box .smartphone-card:visible:lt('+x+')').removeClass('hideCar');
                        // console.log(x,visibleCardsShown)
                        if(x == visibleCardsShown) {
                          console.log('true state')
                        }
                      });
                      $(".smartphone-cards-wrap #seeMoreTwo").hide();
                      console.log(visibleCardsShown)
                      console.log('default case')
                      $("input + label .badge").each(function (index, value) {
                        var storageChecked = $(value).attr('space');
                        var colorChecked = $(value).attr('color');
                        var catChecked = $(value).attr('cat');
                        var osystemChecked = $(value).attr('osname');
                        var allBrandBoxes = $(".smartphone-card[osname][storagename][colorname][categoryname='" + catChecked + "']:visible").length;
                        var allcolorBoxes = $(".smartphone-card[osname][storagename][categoryname][colorname='" + colorChecked + "']:visible").length;
                        var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][categoryname][colorname]:visible").length;
                        var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname][storagename][categoryname]:visible").length;
                        var allBrandBoxesAll = $(".smartphone-card[osname][storagename][colorname][categoryname]:visible").length;
                        if ($(value).attr('cat')) {
                          if ($(value).attr('cat') === 'allcategories') {
                            $(value).html(allBrandBoxesAll);
                          } else {
                            $(value).html(allBrandBoxes);
                          }
                        } else if ($(value).attr('color')) {
                          if ($(value).attr('color') === 'allcolors') {
                            $(value).html(allBrandBoxesAll);
                          } else {
                            $(value).html(allcolorBoxes);
                          }
                        } else if ($(value).attr('space')) {
                          if ($(value).attr('space') === 'allspaces') {
                            $(value).html(allBrandBoxesAll);
                          } else {
                            $(value).html(allstorageBoxes);
                          }
                        } else if ($(value).attr('osname')) {
                          if ($(value).attr('osname') === 'allos') {
                            $(value).html(allBrandBoxesAll);
                          } else {
                            $(value).html(allosBoxes);
                          }
                        }
                      });
                  }
                } else {
                  $(elem).hide();
                }
             });
             $(".range-slider-wrap").removeClass("resetSlider");
            },
        });

          let priceRangeSlider62Filters = $("#priceRangeSlider62Filters").data("ionRangeSlider");
          $('input[name="brands"], input[name="colors"], input[name="storages"], input[name="osystems"], .smartphone-cards-wrap #resetbtn, .smartphone-cards-wrap #resetbtn-two').on("click", function () {
            priceRangeSlider62Filters.reset();
            var newTextToRange = $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
            $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange)
          });

          var newTextToRange = $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
	        $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange)


          let priceRangeSliderforCards = $(".priceRangeSliderCards").data("ionRangeSlider");
          $('.reset-filters-btn').on("click", function () {
            priceRangeSliderforCards.reset();
            priceRangeSlider62Filters.reset();
            
          });
  
          let priceRangeSlider63Laptops = $("#priceRangeSlider63Laptops").data("ionRangeSlider");
          $('.laptops-cards-wrap input[name="laptopBrands"], .laptops-cards-wrap #resetbtn-laptops, .laptops-cards-wrap #resetbtnTwo-laptops').on("click", function () {
            priceRangeSlider63Laptops.reset();
            var newTextToRange = $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
            $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange)
          });
       });
