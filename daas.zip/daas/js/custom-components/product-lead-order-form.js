import { FORM_SUCCESS, FORM_ERROR } from '../analytics/analytics';
    // Google Event
    function googleClickEvent(dataObject) {
      if (typeof (window.dataLayer) !== "undefined") {
        dataLayer.push(dataObject);
      }
      console.log(dataObject)
    }

    // Generic Adobe Function
    function adobeFormEvent(dataObject) {
      if (typeof (window.dataLayer) !== "undefined") {
          dataLayer.push(dataObject);
      }
      console.log(dataObject)
    }

    function productsFormsErrorGoogle(msg) {
      var DisplayFormName = window.location.href;
      var errorMessage = $('.smbform .business-form-submitted.error').text();
      var object = {
        'event': 'lead_'  + msg,
        'form_id': "productLeadorderForm",
        'form_name': "productLeadorderForm",
        'currency': 'AED',
        'value': queryParamValue('p', DisplayFormName) || '',
        'error_code': '',
        'error_message': errorMessage,
        'error_type': 'system_error',
        'items': {
          'item_id': queryParamValue('product', DisplayFormName) || '',
          'item_name': queryParamValue('productName', DisplayFormName) || '',
          'item_category': '',
          'price': queryParamValue('p', DisplayFormName) || '',
        }
      }
      googleClickEvent(object);
    }

    function productsFormsSuccessGoogle(msg) {
      var DisplayFormName = window.location.href
      var object = {
        'event': 'lead_'  + msg,
        'form_id': "productLeadorderForm",
        'form_name': "productLeadorderForm",
        'currency': 'AED',
        'value': queryParamValue('p', DisplayFormName),
        'items': {
          'item_id': queryParamValue('product', DisplayFormName) || '',
          'item_name': queryParamValue('productName', DisplayFormName) || '',
          'item_category': '',
          'price': queryParamValue('p', DisplayFormName) || '',
        }
      }
      googleClickEvent(object);
    }

    // all SMB Product LEad forms Error state Adobe
    function productsFormsErrorAdobe(msg) {
          var DisplayFormName = window.location.href;
          var errorMessage = $('.smbform .business-form-submitted.error').text();
          var object = {
              "event": "form " + msg,
              "formDetails": {
                  "formName": "productLeadorderForm",
              },
              "eventInfo": {
                  "formStart": 1
              },
              "errorInfo": {
                "formError": 1,
                "errorMessage": errorMessage,
                "errorCode": "",
                "errorType": ""
              },
              "productListItems": {
                  "name": queryParamValue('productName', DisplayFormName) || '',
                  "_merchVars": {
                      "productType": "",
                      "productCategory": "",
                      "price": queryParamValue('p', DisplayFormName) || ''
                  }
              }
          }
          adobeFormEvent(object);
    }

    // all SMB Product LEad forms Success state Adobe
    function productsFormsSuccessAdobe(msg) {
      var DisplayFormName = window.location.href
      var object = {
          "event": "form " + msg,
          "formDetails": {
              "formName": "productLeadorderForm",
          },
          "eventInfo": {
              "formSubmit": 1
          },
          "productListItems": {
              "name": queryParamValue('productName', DisplayFormName) || '',
              "_merchVars": {
                  "productType": "",
                  "productCategory": "",
                  "price": queryParamValue('p', DisplayFormName) || ''
              }
          }
      }
      adobeFormEvent(object);
    }
    $('#productLeadorderForm .EtisalatAccountNumber').addClass('d-none');
    $(document).on('change','#productLeadorderForm input[name=havenumber]',function() {
        if (this.value == 'yes') {
            $('#productLeadorderForm .EtisalatAccountNumber').removeClass('d-none');
        } else {
            $('#productLeadorderForm .EtisalatAccountNumber').addClass('d-none');
        }
    });
    if(window.location.href.indexOf('error') !== -1){
        $("#productLeadorderForm #dErrorMessage").removeClass('hidden');
    }

    var $productLeadorderForm = $("#productLeadorderForm");
    var productLeadorderFormlang = $('html').attr('lang');
    var productLeadorderFormresultMessageContainer = $("#productLeadorderForm .business-form-submitted");
    var productLeadorderForminvalidNumberError = window.location.href.indexOf(".ae/ar") > -1 ? "رقم هاف محمول غير صالح " : "Invalid Contact Number";
    var productLeadorderFormGeneralErrorMsg = window.location.href.indexOf(".ae/ar") > -1 ? "هناك شيء خاطئ، يرجى المحاولة في وقت لاحق" : "Something went wrong, please try again later";
    // if (!$productLeadorderForm.length) {
    //   return false;
    // }
    const $SUBMIT_CTA = $('#productLeadorderForm #btnproductLeadorderForm');
    const currentURL = window.location.href;
    $SUBMIT_CTA.on('click', function () {
      if ($productLeadorderForm.valid() == false) {
        FORM_ERROR($productLeadorderForm, 'validation error');
        return false;
      }
    });
    var productLeadorderFormmessagelocal;


    function getFormData($productLeadorderForm) {
        var o = {};
        var a = $productLeadorderForm.serializeArray();
        $.each(a, function () {
          if (o[this.name]) {
            if (!o[this.name].push) {
              o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || "");
          } else {
            o[this.name] = this.value || "";
          }
        });
        return o;
    }

    function showErrorMessageProductLeadOrderForm(text) {
      productLeadorderFormresultMessageContainer.text(text);
      productLeadorderFormresultMessageContainer.addClass("error");
      productLeadorderFormresultMessageContainer.removeClass("hidden");
      // show again the submit button, enable the form, hide the loadings
    }
    function getParameterByName(name, href) {
      name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
      const regexS = '[\\?&]' + name + '=([^&#]*)';
      const regex = new RegExp(regexS);
      const results = regex.exec(href);
      if (results == null) return '';
      else return decodeURIComponent(results[1].replace(/\-/g, ' '));
    }
    function queryParamValue(name, url = currentURL) {
      if (!name || !currentURL) return undefined;

      return getParameterByName(name, url)
        .replace(/_/g, ' ')
        .replace(/[\_\"\'\>\<\?\=\/\/]/g, ' ');
    }


    function bindingUIFromParamsProductLead() {
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      const productName = queryParamValue('productName', currentURL);
      const amountPrice = queryParamValue('p', currentURL);
      const contractPeriod = queryParamValue('contractPeriod', currentURL);
      const orderSummaryXFPath = urlParams.get('orderSummary');
      const moreinfoPopup = urlParams.get('productinfoPopup');
      if (productName) {
          const targetHeading = $(".smb-form-wrapper .order-details-box #productName h4");
          targetHeading.html(productName);

          const targetPrice = $(".smb-form-wrapper .order-details-box #productPrice h2")
          targetPrice.html(amountPrice);

          const targetContract = $(".smb-form-wrapper .order-details-box p#productContract")
          targetContract.html(contractPeriod);
          $("#productLeadorderForm .sec-main-headings span.ptitle").html(productName);
          $("#productInfoModal .side-inner .header .sec-main-headings h5").html(productName);
          $("#productLeadorderForm .form-text-area #backbtn").click(function(e) {
            e.preventDefault();
            history.back();
          })
      }
      if(amountPrice === '') {
         $('.price-details').addClass('hidenow');
      }

      if(orderSummaryXFPath){
        $.ajax({
          url: orderSummaryXFPath,
          success: function(responseData) {
              $('.summary-details .table-wrap').prepend(responseData);
          },
          error: function(error) {
              console.log(JSON.stringify(error));
              let errorCode = JSON.stringify(error)
              if (error.status == 0) {
                // console.log('error message working')
              }
          }
        });
      } else {
        $('.smb-form-wrapper .summary-details').hide();
        $('.summaryFormFields').removeClass('col-lg-6');
        $('.summaryFormFields').addClass('col-lg-12');
        $('.summaryFormFields .form-section').not('.description-section').removeClass('col-md-12');
        $('.summaryFormFields .form-section').not('.description-section').addClass('col-md-6');
        $('#productLeadorderForm').addClass('smb-simple-lead-order-form');
        $('#productLeadorderForm').addClass('withoutSummaryDetails');
        $('.smb-form-wrapper .modal-summary-btn').hide();
      }

       const promoCode = urlParams.get('promoCode', currentURL);
      if(promoCode) {
        console.log(promoCode)
        $('.smb-form-wrapper .order-details .order-details-box .price-details .promo-code').show();
        $('.promoCode').text(promoCode.split('_').join(' '));
      } else {
        $('.smb-form-wrapper .order-details .order-details-box .price-details .promo-code').hide();
      }

      if(moreinfoPopup){
        $.ajax({
          url: moreinfoPopup,
          success: function(responseData) {
            $("#productInfoModal .side-inner .body-content").html(responseData);
          },
          error: function(error) {
              console.log(JSON.stringify(error));
              let errorCode = JSON.stringify(error)
              if (error.status == 0) {
                // console.log('error message working')
              }
          }
        });
      } else {
         $('.product-details .side-overlay-link').addClass('d-none');
      }
  }
    $(document).ready(function () {

        bindingUIFromParamsProductLead();

        $productLeadorderForm.validate({
                rules: {
                  firstName: {
                      required: true,
                      realalphabeticlatinarabic: true,
                      maxlength: 248,
                    },
                    lastName: {
                      required: true,
                      realalphabeticlatinarabic: true,
                      maxlength: 248,
                    },
                    companyName: {
                        //required: true,
                        realalphabeticlatinarabic: true,
                        maxlength: 248,
                    },
                    // description: {
                    //     required: true,
                    //     richtext: true
                    // },
                    contactNumber: {
                        required: true,
                        digits: true,
                        pattern: /^(050|052|054|055|056|057|058)/,
                        minlength: 10,
                        maxlength: 10,
                    },
                    accountNumber: {
                        required: true,
                        digits: true,
                        //number: true,
                        //pattern: /^(050|054|055|056|052)/,
                        minlength: 9,
                        maxlength: 10,
                    },

                    emailAddress: {
                        required: true,
                        email: true,
                    }
                },
                errorPlacement:
                function( error, element ){
                  error.insertAfter(element);
                },
                messages: productLeadorderFormmessagelocal,
                submitHandler: function(form, event) {
                    var dataObj = getFormData($productLeadorderForm);
                    const product =  queryParamValue('product') || dataObj.product;
                    const price = queryParamValue('price') || dataObj.price;
                    const contractperiod = queryParamValue('contractPeriod') || dataObj.contractperiod;
                    const subject = queryParamValue('subject') || dataObj.subject;
                    const channel = queryParamValue('channel') || dataObj.channel;
                    var formData = {
                      accountNumber: "null",
                      product,
                      subject,
                      channel,
                      existingAccount: "null",
                      contactFirstName: dataObj.firstName,
                      contactLastName: "null",
                      email: dataObj.emailAddress,
                      mobileNo: dataObj.contactNumber,
                      companyName: dataObj.companyName || "null",
                      description: dataObj.description || "null",

                    }

                    let dataObjwithJson = {
                      ClientCaptchaValue: sessionStorage.getItem("gcresponse"),
                      TYPE: 'CREATEOMNILEAD',
                      REQPAYLOAD: formData,
                    };
                    dataObjwithJson = JSON.stringify(dataObjwithJson, null, 2);

                    document.getElementById("btnproductLeadorderForm").disabled = true;
                    $.ajax({
                      type: 'POST',
                      url: $($productLeadorderForm).attr('action'),
                      data: dataObjwithJson.replace(/[\r\n]/gm, ''),
                      dataType: 'json',
                      headers: {
                        "content-type": "application/json",
                        'x-calling-application': 'cms',
                      },
                      encode: true
                    })
                    .done(function (response) {
                        const fromData = getFormData($productLeadorderForm);
                        const authoredRedirectUrl = fromData[':redirect'] || `smb-thank-you-page.html`;
                        //let RE_URL = `${window.location.origin}${authoredRedirectUrl}`;
                        let RE_URL = '';
                        const ref = response?.bcrmTransactionId || '';

                        let path = window.location.pathname;
                        let page = path.split('/').pop();
                        // window.location.href = window.location.href.replace(page, authoredRedirectUrl);

                        if(window.location.search) {
                          RE_URL += `${window.location.search}&referenceNo=${ref}&formIDName=productLeadorderForm`;
                        } else {
                          RE_URL += `?referenceNo=${ref}&formIDName=productLeadorderForm`;
                        }

                        $(document).trigger('GA_FROM_TRACKING', { $type: 'submit' });
                        //FORM_SUCCESS($smbLeadorderForm, { ...PAYLOAD, productName, expectedRevenue, referenceNumber: ref });
                        FORM_SUCCESS($productLeadorderForm, formData);
                        productsFormsSuccessGoogle('submit');
                        productsFormsSuccessAdobe('submit');

                        window.location.href = window.location.origin + window.location.pathname.replace(page, authoredRedirectUrl) + RE_URL; 
                       // window.location.href =  window.location.href.replace(page, authoredRedirectUrl)+RE_URL;

                        return true;
                      })
                      .fail(submitErrorResponseProductLeadOrderForm);

                    // return false to prevent normal browser submit and page navigation
                  return false;
                },

          })
                $('.smb-form-wrapper .view-summary-btn').click(function() {

                  $('.smb-form-wrapper .summary-details.mobile-only').slideDown();

                  $('body').addClass('summary-overlay');

                  $('.smb-form-wrapper .order-details').addClass('fixed');

                  $(this).addClass('hidden');

                });

                $('.smb-form-wrapper .close-summary-btn').click(function() {

                  $('.smb-form-wrapper .summary-details.mobile-only').hide();

                  $('body').removeClass('summary-overlay');

                  $('.smb-form-wrapper .order-details').removeClass('fixed');

                  $('.smb-form-wrapper .view-summary-btn').removeClass('hidden');

                });
        });




        function submitErrorResponseProductLeadOrderForm(jqXHR, textStatus, error) {
            let errorText = (jqXHR.responseJSON && jqXHR.responseJSON.message) || error;
            showErrorMessageProductLeadOrderForm(productLeadorderFormGeneralErrorMsg);
            productsFormsErrorGoogle('error');
            productsFormsErrorAdobe('error');
            //FORM_ERROR($productLeadorderForm, 'API error', errorText);
        }