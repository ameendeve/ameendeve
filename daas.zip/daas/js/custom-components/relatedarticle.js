import { swiperInit } from "../swipernwtcon";

function relatedArticleCarouselFour() {
    $(document).find(".related-articles-four-slides").each(function (index) {
        $(this).addClass("relatedArticlesCarouselwith4" + index);
        var $relatedArticlesWrapper = $(this);
        $relatedArticlesWrapper.find(".swiper-button-next").addClass("relatedRightwith4" + index);
        $relatedArticlesWrapper.find(".swiper-button-prev").addClass("relatedLeftwith4" + index);
        $relatedArticlesWrapper.find(".swiper-pagination").addClass("relatedpagewith4" + index);
        var carouselSliderArticleGrid1 = swiperInit(".relatedArticlesCarouselwith4" + index + " .relatedArticlesFourCards", {
            loop: false,
            slidesPerGroupSkip: 1,
            keyboard: {
                enabled: true
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev"
            },
            breakpoints: {
                1099: {
                    slidesPerView: 4,
                    spaceBetween: 24
                },
                768: {
                    slidesPerView: 3.1,
                    spaceBetween: 16
                },
                668: {
                    slidesPerView: 2.2,
                    spaceBetween: 16
                },
                100: {
                    slidesPerView: 1.15,
                    spaceBetween: 16
                }
            }
        });
    });
} // 2nd Variation with 3 cards


function relatedArticleCarouselThree() {
    $(document).find(".related-articles-three-slides").each(function (index) {
        $(this).addClass("relatedArticlesCarouselwith3" + index);
        var $relatedArticlesWrapper = $(this);
        $relatedArticlesWrapper.find(".swiper-button-next").addClass("relatedRightwith3" + index);
        $relatedArticlesWrapper.find(".swiper-button-prev").addClass("relatedLeftwith3" + index);
        $relatedArticlesWrapper.find(".swiper-pagination").addClass("relatedpagewith3" + index);
        var carouselSliderArticleGrid1 = swiperInit(".relatedArticlesCarouselwith3" + index + " .relatedArticlesThreeCards", {
            loop: false,
            slidesPerGroupSkip: 1,
            keyboard: {
                enabled: true
            },
            navigation: false,
            breakpoints: {
                1099: {
                    slidesPerView: 3,
                    spaceBetween: 24,
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                        type: "bullets"
                    }
                },
                768: {
                    slidesPerView: 2.15,
                    spaceBetween: 16,
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                        type: "bullets"
                    }
                },
                100: {
                    slidesPerView: 1.15,
                    spaceBetween: 16,
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                        type: "bullets"
                    }
                }
            }
        });
    });
} // Bottom variation 2 cards slider


function relatedArticleCarouselTwo() {
    $(document).find(".related-articles-two-cards-smallimg").each(function (index) {
        $(this).addClass("relatedArticlesCarouselwith2" + index);
        var $relatedArticlesWrapper = $(this);
        $relatedArticlesWrapper.find(".swiper-button-next").addClass("relatedRightwith2" + index);
        $relatedArticlesWrapper.find(".swiper-button-prev").addClass("relatedLeftwith2" + index);
        $relatedArticlesWrapper.find(".swiper-pagination").addClass("relatedpagewith2" + index);
        var carouselSliderArticleGrid1 = swiperInit(".relatedArticlesCarouselwith2" + index + " .relatedArticlesTwoCardsSmallimg", {
			loop: false,
            slidesPerGroupSkip: 1,
            pagination: {
            el: ".swiper-pagination",
            clickable: true,
            type: "bullets"
        },
            navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
            breakpoints: {
            1099: {
                slidesPerView: 2,
                spaceBetween: 24
            },
            668: {
                slidesPerView: 1.15,
                spaceBetween: 24
            },
            100: {
                slidesPerView: 1.15,
                spaceBetween: 24
            }
        }
});
});
} // register the event handlers


$(document).ready(function () {
    relatedArticleCarouselFour();
    relatedArticleCarouselTwo();
    relatedArticleCarouselThree();
});