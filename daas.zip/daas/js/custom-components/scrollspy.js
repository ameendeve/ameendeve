$(document).ready(function () {
    // Mobile dropDown Functionality
    var optionMenu = document.querySelector(".t-and-c-filter-accordion");
    if(optionMenu){
      var selectBtn = optionMenu.querySelector(".t-and-c-filter-accordion .vertical-accordion-header"),
      options = optionMenu.querySelectorAll(".t-and-c-filter-accordion .vertical-accordion-list-inner"),
      sBtn_text = optionMenu.querySelector(".t-and-c-filter-accordion .vertical-accordion-header-text");
      selectBtn.addEventListener("click", function () {
          return optionMenu.classList.toggle("dropdown-active");
      });
      options.forEach(function (option) {
          option.addEventListener("click", function () {
              var selectedOption = option.querySelector(".t-and-c-filter-accordion .vertical-accordion-text").innerText;
              sBtn_text.innerText = selectedOption;
              optionMenu.classList.remove("dropdown-active");
              var windowsize = $(window).width();

              if (windowsize <= 768) {
                  optionMenu.classList.remove("dropdown-active");
              }
          });
      });
    }
});

