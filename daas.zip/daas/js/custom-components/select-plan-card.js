function selectPlanCardCarousel() {
  $(document).find(".select-plan-card-wrapper").each(function (index) {
    $(this).addClass('selectPlanCardSlider' + index)
    var $selectProductsCardCarousel = $(this);
    $selectProductsCardCarousel.find(".swiper-pagination").addClass("splanCardCarousel" + index);    
    var swiperSlideLength = $('.selectPlanCardSlider' + index + " .swiper-container .swiper-slide").length;
    $(this).addClass("swiper-with-" + swiperSlideLength + "-slides");
      if ($(window).width() > 992) {
        if (swiperSlideLength < 4) {
          $(".selectPlanCardSlider" + index).addClass("destroyed");
          $(".selectPlanCardSlider" + index).find(".swiper-wrapper").addClass("row");
          $(".selectPlanCardSlider" + index).find(".swiper-wrapper.row").children().removeClass("swiper-slide");
          $(".selectPlanCardSlider" + index).find(".swiper-navigation").addClass("deactive");
        } else {
          $(".selectPlanCardSlider" + index).find(".swiper-wrapper").removeClass("row");
          var $carouselSliderwithProgress = new Swiper(
            ".selectPlanCardSlider" + index + " .swiper-container",
            {
              slidesPerView: 4,
              spaceBetween: 16,
              slidesPerGroupSkip: 1,
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
                type: "progressbar",
              },
              breakpoints: {
                1099: {
                  slidesPerView: 4,
                  spaceBetween: 16,
                },
                768: {
                  slidesPerView: 2.75,
                  spaceBetween: 16,
                  pagination: {
                    type: "progressbar",
                    clickable: true,
                  },
                },
                100: {
                  slidesPerView: 1,
                  spaceBetween: 0,
                  pagination: {
                    type: "bullets",
                    clickable: true,
                  },
                },
              },
            }
          );
        }
      } else {
        $(".selectPlanCardSlider" + index).find(".swiper-wrapper").removeClass("row");
        var $carouselSliderwithProgress = new Swiper(
          ".selectPlanCardSlider" + index + " .swiper-container",
          {
            slidesPerView: 4,
            spaceBetween: 16,
            slidesPerGroupSkip: 1,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
              type: "progressbar",
            },
            breakpoints: {
              1099: {
                slidesPerView: 4,
                spaceBetween: 16,
              },
              768: {
                slidesPerView: 2.75,
                spaceBetween: 16,
                pagination: {
                  type: "progressbar",
                  clickable: true,
                },
              },
              100: {
                slidesPerView: 1.25,
                spaceBetween: 16,
                pagination: {
                  type: "bullets",
                  clickable: true,
                },
              },
            },
          }
        );
      }
    });
    if($('.select-product-cards-wrap').hasClass("destroyed")) {
      $(".destroyed").find(".swiper-wrapper").addClass("row");
      $(".destroyed").find(".swiper-wrapper.row").children().removeClass("swiper-slide");
      $(".destroyed").find(".swiper-navigation").addClass("deactive");
    }
}

// Filter Area required functions
function initParentCategory() {
  $('.select-plancard-box input[name="checkbox_list_main_plan"]').click(function () {
    console.log("select plan cards parent category");
    $(this).parents('li').siblings().removeClass('active-item'); 
    $(this).parents('li').addClass('active-item'); 
    if($(this).attr("value") == 'all') {
      console.log('all categories')
      var checked = $(this).prop("checked");
      if(checked) {
        $(".accordion").find("input:checkbox").prop("checked", false);  
      }
      var getAllCategoriesCard = $(".select-plancard-box .filter-wrap > .cat-box > div");
      $(getAllCategoriesCard).show();
    } else {
      if ($('.select-plancard-box input[name="checkbox_list_sub"]').is(':checked')) { 
        $(".accordion-item").find("input:checkbox").prop("checked", false);
      }
      $('.accordion-header').removeClass('checkbuttons')
      $(".accordion-collapse").removeClass("activeradio")
      $(this).closest(".accordion-header").addClass("checkbuttons");
      $(".checkbuttons").next(".accordion-collapse").addClass("activeradio");
      
      var checked = $(this).prop("checked");
      $(".activeradio").find("input:checkbox").prop("checked", checked);
      $(".activeradio").find("input:radio").prop("checked", checked);
      
      var checkboxValues = [];
      $('.select-plancard-box input[name="checkbox_list_main"]:checked').each(function (
        index,
        elem
      ) {
        checkboxValues.push($(elem).val());
      });
      var getAllCategoriesCard = $(".select-plancard-box .filter-wrap > .cat-box > div");
      var getCurrentCategoryCard = [];

      $(getAllCategoriesCard).hide();
      checkboxValues.forEach((checkBoxValues) => {
        getCurrentCategoryCard.push(
          $(".select-plancard-box .filter-wrap > .cat-box > div[main-category~='" + checkBoxValues + "']")
        );
      });
      getCurrentCategoryCard.forEach((activeCard) => {
        $(activeCard).show();
      });
      console.log(checkboxValues);
    }
  });
}
// Show hide Child categories Function
function initChildCategory() {
  var radioButtons = $('input[name="checkbox_list_main"]');
  $(".select-plancard-box input[name='checkbox_list_sub_plan']").click(function () {
    var ck_box = $(".select-plancard-box input[name='checkbox_list_sub']:checked").length;
    if(ck_box === 0) {
      $(this).parents('li').addClass('dontclick')
      $(this).prop("checked", true);
    } else {
      $(this).parents('li').removeClass('dontclick')
    }
    $(this).closest(".accordion-item").find('.accordion-header').addClass("checkbuttons");
    $(".checkbuttons").next(".accordion-collapse").addClass("activeradio");
    $(this).parents('li.accordion-item').siblings().find("input:checkbox").prop("checked", false);
    $(this).parents('li.accordion-item').find("input:radio").prop("checked", true);
    var checkboxValues = [];
    $('.select-plancard-box input[name="checkbox_list_sub"]:checked').each(function (index,elem) {
      checkboxValues.push($(elem).val());
    });
    var getAllCategoriesCard = $(".select-plancard-box .filter-wrap > .cat-box > div");
    var getCurrentCategoryCard = [];
    console.log(checkboxValues, getCurrentCategoryCard);
    $(getAllCategoriesCard).hide();
    checkboxValues.forEach((checkBoxValues) => {
      getCurrentCategoryCard.push(
        $(".select-plancard-box .filter-wrap > .cat-box > div[sub-category~='" + checkBoxValues + "']")
      );
    });
    getCurrentCategoryCard.forEach((activeCard) => {
      $(activeCard).show();
    });
  });
}

// view more and view less functionality for category list ( filters )
function vewCategoriesMoreLessPlans() {
  var viewMorebutton = $(this);
  viewMorebutton
    .closest(".p-category-list-wrap")
    .find("ul")
    .toggleClass("full-list");
  viewMorebutton.toggleClass("toggleView");
}
$(".p-category-list-wrap .view-more")
  .off("click")
  .on("click", vewCategoriesMoreLessPlans);

// filter mobile view popup open close
function filtersMobileView(thisValue) {
  if (window.innerWidth < 992) {
    var currentElement = $(thisValue).attr("data-label");
    if (currentElement) {
      $(".responsive-" + currentElement).addClass("mobileViewActive");
      $("body").addClass("freeze");
    }
  }
}
$(".filter-compare-sort-section a")
  .off("click")
  .on("click", function () {
    filtersMobileView(this);
  });

// to make filters popup in-active ( hide )in mobile view
$(".filter-close")
  .off("click")
  .on("click", function () {
    $(".responsive-filters").removeClass("mobileViewActive");
    $(".responsive-sort").removeClass("mobileViewActive");
    $("body").removeClass("freeze");
  });
  function get_queryselectPlan(){
    var url = document.location.href;
    var qs = url.substring(url.indexOf('?') + 1).split('&');
    for(var i = 0, result = {}; i < qs.length; i++){
        qs[i] = qs[i].split('=');
        result[qs[i][0]] = decodeURIComponent(qs[i][1]);
    }
    var queryExist = (result.selectedFilterID === undefined)
    if(!queryExist) {
      $(".select-product-cards-wrap input[name='checkbox_list_main']").each(function(index, value) {
        var getValueRadio = $(value).attr('value');
        var getValueUrl = result.selectedFilterID
        //console.log(getValueRadio, getValueUrl)
        if(getValueRadio === getValueUrl) {
          $(value).prop("checked", true);
          $(value).closest(".accordion-item").find("input:checkbox").prop("checked", true);
          $(value).parents('li').addClass('active-item')
          var getAllCategoriesCard = $(".select-plancard-box .filter-wrap > .cat-box > div");
          $(getAllCategoriesCard).each((index, elem) => {
            if($(elem).attr('main-category') === getValueUrl) {
              $(elem).show()
            } else {
              $(elem).hide()
            }
          }); 
        } else {
          $(value).prop("checked", false); 
        }
      });
    } else {
      // console.log('no url query')
    }
}
// register the event handlers
$(document).ready(function () {
  // getting parent categories length to show hide view more button
  var catnumber = $(
    ".product-filter-sidebar .responsive-filters .p-category-list-wrap ul > li.accordion-item"
  ).length;
  var viewmoreBtn = $(
    ".product-filter-sidebar .p-category-list-wrap .view-more"
  );
  if (catnumber > 5) {
    viewmoreBtn.show();
  } else {
    viewmoreBtn.hide();
  }
  // Initializing Functions
  get_queryselectPlan()

  initParentCategory();
  initChildCategory();
  vewCategoriesMoreLessPlans();
  selectPlanCardCarousel();
});
// // open popup
// $('.overlay-link').off('click').on('click', function(e){
//   e.preventDefault();
//   e.stopPropagation();
//   var dataLabel = $(this).attr("data-label");
//   //console.log(dataLabel);
//   if(typeof dataLabel !== 'undefined'  && dataLabel !== '') {
//       $('#'+dataLabel).addClass('show');
//       $('body').addClass('freeze');
//   }
// });

// // close popup
// $('.fullscreen-overlay-wrap').off('click').on('click' , '.modal-close', function(e){
//   e.stopPropagation();
//   e.preventDefault();
//   var currentOpendPopUp = $(this).closest('.overlay-modal');
//   $(currentOpendPopUp).removeClass('show');
//   $('body').removeClass('freeze');
// });

// $('body').attr('data-bs-spy', '');
// $('body').attr('data-bs-target', '');
// $('.content-scrollspy').attr('data-bs-spy', 'scroll');
// $('.content-scrollspy').attr('data-bs-target', 'eandscrollNav');



// // popup
// $('.side-overlay-link').off('click').on('click', function(e){
//   e.preventDefault();
//   e.stopPropagation();
//   var dataLabel = $(this).attr("data-label");
//   if(typeof dataLabel !== 'undefined'  && dataLabel !== '') {
//       $('#'+dataLabel).addClass('show');
//       $('body').addClass('freeze');
//   }
// });

// // close popup
// $('.side-overlay-wrap').off('click').on('click' , '.side-overlay-close', function(e){
//   e.stopPropagation();
//   e.preventDefault();
//   var currentOpendPopUp = $(this).closest('.side-overlay-modal');
//   $(currentOpendPopUp).removeClass('show');
//   $('body').removeClass('freeze');
// });
