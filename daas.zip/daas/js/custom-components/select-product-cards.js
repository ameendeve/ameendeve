function initParentCategoryProductCards() {
    $('.select-product-cards-wrap input[name="checkbox_list_main_product"]').click(function () {
        $(this).parents('li').siblings().removeClass('active-item');
        $(this).parents('li').addClass('active-item');

        if ($(this).attr("value") == 'all') {
            console.log('all categories');
            var checked = $(this).prop("checked");

            if (checked) {
                $(".accordion").find("input:checkbox").prop("checked", false);
            }

            var getAllCategoriesCard = $("select-product-cards-wrap .filter-wrap > .cat-box > div");
            $(getAllCategoriesCard).show();
        } else {
            if ($('.select-product-cards-wrap input[name="checkbox_list_sub"]').is(':checked')) {
                $(".accordion-item").find("input:checkbox").prop("checked", false);
            }

            $('.accordion-header').removeClass('checkbuttons');
            $(".accordion-collapse").removeClass("activeradio");
            $(this).closest(".accordion-header").addClass("checkbuttons");
            $(".checkbuttons").next(".accordion-collapse").addClass("activeradio");
            var checked = $(this).prop("checked");
            $(".activeradio").find("input:checkbox").prop("checked", checked);
            $(".activeradio").find("input:radio").prop("checked", checked);
            var checkboxValues = [];
            $('.select-product-cards-wrap input[name="checkbox_list_main"]:checked').each(function (index, elem) {
                checkboxValues.push($(elem).val());
            });
            var getAllCategoriesCard = $("select-product-cards-wrap .filter-wrap > .cat-box > div");
            var getCurrentCategoryCard = [];
            $(getAllCategoriesCard).hide();
            checkboxValues.forEach(function (checkBoxValues) {
                getCurrentCategoryCard.push($("select-product-cards-wrap .filter-wrap > .cat-box > div[main-category~='" + checkBoxValues + "']"));
            });
            getCurrentCategoryCard.forEach(function (activeCard) {
                $(activeCard).show();
            });
            console.log(checkboxValues);
        }
    });
} // Show hide Child categories Function


function initChildCategoryProductCards() {
    var radioButtons = $('.select-product-cards-wrap input[name="checkbox_list_main"]');
    $(".select-product-cards-wrap input[name='checkbox_list_sub_product']").click(function () {
        console.log("select product cards parent category");
        var ck_box = $(".select-product-cards-wrap input[name='checkbox_list_sub']:checked").length;

        if (ck_box === 0) {
            $(this).parents('li').addClass('dontclick');
            $(this).prop("checked", true);
        } else {
            $(this).parents('li').removeClass('dontclick');
        }
        $(this).closest(".accordion-item").find('.accordion-header').addClass("checkbuttons");
        $(".checkbuttons").next(".accordion-collapse").addClass("activeradio");
        $(this).parents('li.accordion-item').siblings().find("input:checkbox").prop("checked", false);
        $(this).parents('li.accordion-item').find("input:radio").prop("checked", true);
        var checkboxValues = [];
        $('.select-product-cards-wrap input[name="checkbox_list_sub"]:checked').each(function (index, elem) {
            checkboxValues.push($(elem).val());
        });
        var getAllCategoriesCard = $("select-product-cards-wrap .filter-wrap > .cat-box > div");
        var getCurrentCategoryCard = [];
        console.log(checkboxValues, getCurrentCategoryCard);
        $(getAllCategoriesCard).hide();
        checkboxValues.forEach(function (checkBoxValues) {
            getCurrentCategoryCard.push($("select-product-cards-wrap .filter-wrap > .cat-box > div[sub-category~='" + checkBoxValues + "']"));
        });
        getCurrentCategoryCard.forEach(function (activeCard) {
            $(activeCard).show();
        });
    });
} // Reset Button Function


$(".p-category-list-wrap ul").each(function () {
    var liCount;
    liCount = $(this).children("li").length;

    if (liCount <= 5) {
        $(this).next(".view-more").addClass("d-none");
    }
}); // view more and view less functionality for category list ( filters )

function vewCategoriesMoreLess() {
    var viewMorebutton = $(this);
    viewMorebutton.closest(".p-category-list-wrap").find("ul").toggleClass("full-list");
    viewMorebutton.toggleClass("toggleView");
}

$(".p-category-list-wrap .view-more").off("click").on("click", vewCategoriesMoreLess); // filter mobile view popup open close

function filtersMobileView(thisValue) {
    if (window.innerWidth < 992) {
        var currentElement = $(thisValue).attr("data-label");

        if (currentElement) {
            $(".responsive-" + currentElement).addClass("mobileViewActive");
            $("body").addClass("freeze");
        }
    }
}

$(".filter-compare-sort-section a").off("click").on("click", function () {
    filtersMobileView(this);
}); // to make filters popup in-active ( hide )in mobile view

$(".filter-close").off("click").on("click", function () {
    $(".responsive-filters").removeClass("mobileViewActive");
    $(".responsive-sort").removeClass("mobileViewActive");
    $("body").removeClass("freeze");
});

function get_queryselectPrduct() {
    var url = document.location.href;
    var qs = url.substring(url.indexOf('?') + 1).split('&');

    for (var i = 0, result = {}; i < qs.length; i++) {
        qs[i] = qs[i].split('=');
        result[qs[i][0]] = decodeURIComponent(qs[i][1]);
    }

    var queryExist = result.selectedFilterID === undefined;

    if (!queryExist) {
        $(".select-product-cards-wrap input[name='checkbox_list_main']").each(function (index, value) {
            var getValueRadio = $(value).attr('value');
            var getValueUrl = result.selectedFilterID; //console.log(getValueRadio, getValueUrl)

            if (getValueRadio === getValueUrl) {
                $(value).prop("checked", true);
                $(value).closest(".accordion-item").find("input:checkbox").prop("checked", true);
                $(value).parents('li').addClass('active-item');
                var getAllCategoriesCard = $("select-product-cards-wrap .filter-wrap > .cat-box > div");
                $(getAllCategoriesCard).each(function (index, elem) {
                    if ($(elem).attr('main-category') === getValueUrl) {
                        $(elem).show();
                    } else {
                        $(elem).hide();
                    }
                });
            } else {
                $(value).prop("checked", false);
            }
        });
    } else {
        // console.log('no url query');
    }
}

$(document).ready(function () {
    // var filterID = window.location.search;
    // if(window.location.search === '?selectedFilterID=apple') {
    //   console.log('apple brand should work')
    // }
    //console.log(urlParams.toString()); // "?post=1234&action=edit"
    // console.log(window.location.search); // "?
    // getting parent categories length to show hide view more button
    var catnumber = $(".product-filter-sidebar .responsive-filters .p-category-list-wrap ul > li.accordion-item").length;
    var viewmoreBtn = $(".product-filter-sidebar .p-category-list-wrap .view-more");

    if (catnumber > 5) {
        console.log("more than 5");
        viewmoreBtn.show();
    } else {
        viewmoreBtn.hide();
    } // Initializing Functions


    get_queryselectPrduct();

    initParentCategoryProductCards();
    initChildCategoryProductCards();
    vewCategoriesMoreLess();
});
