/**
* Side Overlay
*/

  $(document).ready(function() {

        if (document.getElementsByClassName("side-overlay-link") !== null) {
  
        // register the event handlers
          // popup
          $('.side-overlay-link').off('click').on('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            var dataLabel = $(this).attr("data-label");
            if(typeof dataLabel !== 'undefined'  && dataLabel !== '') {
                $('#'+dataLabel).addClass('show');
                $('body').addClass('freeze');
            }
          });
        };
		
		//trigger register the event handlers of aos animation on click        

        $('.side-overlay-link').on('click', function () {
          $('.side-overlay-modal *').removeClass('aos-animate');
          setTimeout(function () {
            $('.side-overlay-modal *').addClass('aos-animate');
          }, 800);
        }); // close popup


        if (document.getElementsByClassName("side-overlay-wrap") !== null) {

          // close popup
          $('.side-overlay-wrap').off('click').on('click' , '.side-overlay-close', function(e){
            e.stopPropagation();
            e.preventDefault();
            var currentOpendPopUp = $(this).closest('.side-overlay-modal');
            $(currentOpendPopUp).removeClass('show');
            $('body').removeClass('freeze');
          });

        };


  });