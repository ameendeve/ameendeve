/**
 * Slider Module
 */


$(document)
.find(".slider-module-wrap")
.each(function (index) {
    $(this).addClass('rangeSliderModule' + index);
    $(document).ready(function () {
      function updateCard() {
        $('.rangeSliderModule' + index + " .data-card-inner").hide();
        setTimeout(function() { 
          $('.rangeSliderModule' + index + " .data-card-inner").show();
          let curPrice =  $('.rangeSliderModule' + index + " .active .pacakage-price").attr("data-price");
          let curPackage = $('.rangeSliderModule' + index + " .active .package").attr("data-package");
          let curDuration = $('.rangeSliderModule' + index + " .active .duration").attr("data-duration");
          let businessData = $('.rangeSliderModule' + index + " .active .business-data").attr("data-business");
          let packageName = $('.rangeSliderModule' + index + " .active .package-uses").attr("data-uses");
          let vat = $('.rangeSliderModule' + index + " .active .vat").attr("data-vat");
          let contract = $('.rangeSliderModule' + index + " .active .contract").attr("data-contract");
          let moreInfo = $('.rangeSliderModule' + index + " .active .more-info-link").attr("data-more-info");
          let moreInfoOverlay = $('.rangeSliderModule' + index + " .active .more-info-link").attr("data-label");
          let buyNow = $('.rangeSliderModule' + index + " .active .buy-now-link").attr("data-buy-now");
          $('.rangeSliderModule' + index + " .p-price").text(curPrice);
          $('.rangeSliderModule' + index + " .p-data").text(curPackage);
          $('.rangeSliderModule' + index + " .sBtn-text").text(curPackage);
          $('.rangeSliderModule' + index + " .p-duration").text(curDuration);
          $('.rangeSliderModule' + index + " .business-data-title").text(businessData);
          $('.rangeSliderModule' + index + " .vat-value").text(vat);
          $('.rangeSliderModule' + index + " .p-data-name").text(packageName);
          $('.rangeSliderModule' + index + " .contract-name-value").text(contract);
          $('.rangeSliderModule' + index + " .more-info-value").attr("href", moreInfo);
          $('.rangeSliderModule' + index + " .more-info-value").attr("data-label", moreInfoOverlay);
          $('.rangeSliderModule' + index + " .buy-now").attr("href", buyNow);
          $('.rangeSliderModule' + index + " .range-options .option").find('.option-text').each(function () {
            var optionValue = $(this).text();
            if (optionValue == curPackage) {
              $(this).parent().addClass('active');
            }
          });
         }, 0);
     }
      $('.rangeSliderModule' + index + " .packageInputId")[0].oninput = function() {
        updateCard();
        var value = (this.value-this.min)/(this.max-this.min)*100;
        if ($('html').is(':lang(ar)')) {
          this.style.background = 'linear-gradient(to left, #232323 0%, #353738 ' + value + '%, #fff ' + value + '%, white 100%)'
        }
        else {
          this.style.background = 'linear-gradient(to right, #232323 0%, #353738 ' + value + '%, #fff ' + value + '%, white 100%)'
        }
      };

      // calculate dynamic width of lables
      var maxValue = $('.rangeSliderModule' + index + " .packageInputId")[0].max;
      var stepWidth = (100/maxValue)+'%';
      $('.range-data li').css('width', stepWidth);

      var sheet = document.createElement('style');  
      var $rangeInput = $('.rangeSliderModule' + index + " .packageInputId");
      var prefs = ['webkit-slider-runnable-track', 'moz-range-track', 'ms-track'];

      document.body.appendChild(sheet);

      var getTrackStyle = function (el) {  
        var curVal = el.value,
        val = (curVal - 1) * 13,
        style = '';
        
        // Set active label
        $('.rangeSliderModule' + index + " .range-data li").removeClass('active selected');
        var curLabel = $('.rangeSliderModule' + index + " .range-data").find('li:nth-child(' + curVal + ')');
        
        curLabel.addClass('active selected');
        curLabel.prevAll().addClass('selected');
        
        // Change background gradient
        for (var i = 0; i < prefs.length; i++) {
          style += '.range {background: linear-gradient(to right, #A3B712 0%, #4D780C ' + val + '%, #fff ' + val + '%, #fff 100%)}';
          style += '.range input::-' + prefs[i] + '{background: linear-gradient(to right, #37adbf 0%, #37adbf ' + val + '%, #b2b2b2 ' + val + '%, #b2b2b2 100%)}';
        }

        return style;
      }

      $rangeInput.on('input', function () {
        sheet.textContent = getTrackStyle(this);
      });

      // Change input value on label click
      $('.rangeSliderModule' + index + " .range-data li").on('click', function () {
        var getValue = $(this).index();
        $rangeInput.val(getValue + 1).trigger('input');
        //animation
        // $("#data-card-inner").fadeOut();
        // setTimeout(function() { $("#data-card-inner").fadeIn(); }, 100);
        
        updateCard();

      });

      //get active li and update input style
      var activeClassIndex = $('.rangeSliderModule' + index + " .range-data li.active").index();
      $rangeInput.val(activeClassIndex + 1).trigger('input');

      // dropdown selection
      const optionMenu = document.querySelector('.rangeSliderModule' + index + " .select-menu"),
      selectBtn = optionMenu.querySelector('.rangeSliderModule' + index + " .select-btn"),
      options = optionMenu.querySelectorAll('.rangeSliderModule' + index + " .option"),
      sBtn_text = optionMenu.querySelector('.rangeSliderModule' + index + " .sBtn-text");

      $(document).on('keydown', function(event) {
        if (event.key == "Escape") {
          optionMenu.classList.remove("active");
        }
      });

      // active link
      $('.rangeSliderModule' + index + " .option").click(function() {
        $('.rangeSliderModule' + index + " .option").removeClass('active');
        if ($(this).hasClass('active')) {
          $(this).removeClass('active');
        } else {
          $(this).addClass('active');
        }
      });

      // sideoverlay
      $('.rangeSliderModule' + index + " .side-overlay-link").off('click').on('click', function(e){
        e.preventDefault();
        e.stopPropagation();
        var dataLabel = $(this).attr("data-label");
        if(typeof dataLabel !== 'undefined'  && dataLabel !== '') {
            $('#'+dataLabel).addClass('show');
            $('body').addClass('freeze');
        }
      });

      $(document).mouseup(function(e) {
        var selectBox = $('.rangeSliderModule' + index + " .select-menu");
        if (!selectBox.is(e.target) && selectBox.has(e.target).length === 0)
        {
          optionMenu.classList.remove("active");
        }
      });

      // popup
      $('.rangeSliderModule' + index + " .overlay-link").off('click').on('click', function(e){
        e.preventDefault();
        e.stopPropagation();
        var dataLabel = $(this).attr("data-label");
        if(typeof dataLabel !== 'undefined'  && dataLabel !== '') {
            $('#'+dataLabel).addClass('show');
            $('body').addClass('freeze');
        }
      });

      //remove href when modal class added
      $('.rangeSliderModule' + index + " .more-info-value").click(function() {
        if($(this).hasClass('overlay-link')) {
          $(this).attr("href","javascript:void(0)")
        }
        else {
          $(this).attr("href",dmoreInfo)
        }
      });

      selectBtn.addEventListener("click", () =>
        optionMenu.classList.toggle("active")
      );

      options.forEach((option) => {
        option.addEventListener("click", () => {
          let selectedOption = option.querySelector(".option-text").innerText;
          sBtn_text.innerText = selectedOption;
          optionMenu.classList.remove("active");
          $('.rangeSliderModule' + index + " .data-card-inner").fadeOut();
          setTimeout(function() { 
            $('.rangeSliderModule' + index + " .data-card-inner").fadeIn();
            let dPackage = option.querySelector('.rangeSliderModule' + index + " .active .d-package").getAttribute("data-package");
            let dcurPrice = option.querySelector('.rangeSliderModule' + index + " .active .d-price").getAttribute("data-price");
            let dcurDuration = option.querySelector('.rangeSliderModule' + index + " .active .d-duration").getAttribute("data-duration");
            let dbusinessData = option.querySelector('.rangeSliderModule' + index + " .active .d-business-data").getAttribute("data-business");
            let dpackageName = option.querySelector('.rangeSliderModule' + index + " .active .d-package-uses").getAttribute("data-uses");
            let dvat = option.querySelector('.rangeSliderModule' + index + " .active .d-vat").getAttribute("data-vat");
            let dcontract = option.querySelector('.rangeSliderModule' + index + " .active .d-contract").getAttribute("data-contract");
            let dmoreInfo = option.querySelector('.rangeSliderModule' + index + " .active .d-more-info-link").getAttribute("data-more-info");
            let dMoreInfoOverlay = option.querySelector('.rangeSliderModule' + index + " .active .d-more-info-link").getAttribute("data-label");
            let dbuyNow = option.querySelector('.rangeSliderModule' + index + " .active .d-buy-now-link").getAttribute("data-buy-now");
            $('.rangeSliderModule' + index + " .p-data").text(dPackage);
            $('.rangeSliderModule' + index + " .p-price").text(dcurPrice);
            $('.rangeSliderModule' + index + " .p-duration").text(dcurDuration);
            $('.rangeSliderModule' + index + " .business-data-title").text(dbusinessData);
            $('.rangeSliderModule' + index + " .vat-value").text(dvat);
            $('.rangeSliderModule' + index + " .p-data-name").text(dpackageName);
            $('.rangeSliderModule' + index + " .contract-name-value").text(dcontract);
            $('.rangeSliderModule' + index + " .more-info-value").attr("href", dmoreInfo);
            $('.rangeSliderModule' + index + " .more-info-value").attr("data-label", dMoreInfoOverlay);
            $('.rangeSliderModule' + index + " .buy-now").attr("href", dbuyNow);
          }, 100);
        });
      });

    
    });
});

// register the event handlers
$(document).ready(function () {

// close popup
$('.fullscreen-overlay-wrap').off('click').on('click' , '.modal-close', function(e){
  e.stopPropagation();
  e.preventDefault();
  var currentOpendPopUp = $(this).closest('.overlay-modal');
  $(currentOpendPopUp).removeClass('show');
  $('body').removeClass('freeze');
});

// close popup
$('.side-overlay-wrap').off('click').on('click' , '.side-overlay-close', function(e){
  e.stopPropagation();
  e.preventDefault();
  var currentOpendPopUp = $(this).closest('.side-overlay-modal');
  $(currentOpendPopUp).removeClass('show');
  $('body').removeClass('freeze');
});

});
