    // click see More Cards 
    function seeMoreBtn() {
        var size_cards = $(".laptops-cards-wrap .smartphone-card").length;
        var x = 6;
        $('.laptops-cards-wrap #seeMore').click(function () {
            x = (x + 3 <= size_cards) ? x + 3 : size_cards;
            console.log(x, size_cards)
            $('.laptops-cards-wrap .smartphone-card:lt(' + x + ')').show();
            if (x === size_cards) {
                $(this).hide()
            }
        });
    }
    seeMoreBtn();
    
    //view more button show hide if category is less then or equal to 5
    $(".p-category-list-wrap ul").each(function () {
        var liCount;
        liCount = $(this).children("li").length;
        if (liCount <= 5) {
            $(this).next(".view-more-laptops").addClass("d-none");
        }
    });

    // view more and view less functionality for category list ( filters )
    function vewCategoriesMoreLess() {
        var viewMorebutton = $(this);
        viewMorebutton
            .closest(".p-category-list-wrap")
            .find("ul")
            .toggleClass("full-list");
        viewMorebutton.toggleClass("toggleView");
    }
    $(".p-category-list-wrap .view-more-laptops").off("click").on("click", vewCategoriesMoreLess);

    // filter mobile view popup open close
    function filtersMobileView(thisValue) {
        if (window.innerWidth < 992) {
            var currentElement = $(thisValue).attr("data-label");
            if (currentElement) {
                $(".responsive-" + currentElement).addClass("mobileViewActive");
                $("body").addClass("freeze");
            }
        }
    }

    // filter mobile view popup close close
    $(".filter-compare-sort-section a").off("click").on("click", function () {
        filtersMobileView(this);
    });

    // to make filters popup in-active ( hide )in mobile view
    $(".filter-close").off("click").on("click", function () {
        $(".responsive-filters").removeClass("mobileViewActive");
        $(".responsive-sort").removeClass("mobileViewActive");
        $("body").removeClass("freeze");
    });

    // Cards Filtration Functionality
    var productDetails = $(".single-filter .smartphone-card");
    var cardsList = [];
    $(productDetails).each(function (index, value) {
        var productImpration = {}
        var selectedProductMain = $(this);
        var categoryname = selectedProductMain.attr('categoryname');
        var colorname = selectedProductMain.attr('colorname');
        var cardname = selectedProductMain.find('.title h5').text();
        productImpration = {
            'categoryname': categoryname,
            'colorname': colorname,
            'cardtitle': cardname,
        }
        cardsList.push(productImpration);
    });
    
    // Calculate Category Cards on page load
    $('.single-filter input[name="laptopBrands"] + label .badge').each(function (index, value) {
        var brand = $(value).attr('category')
        var filteredBrand = cardsList.filter((card) => {
            return card.categoryname == brand
        })
        if ($(value).attr('category') == 'allbrands') {
            $(value).html(cardsList.length);
        } else {
            $(value).html(filteredBrand.length);
        }
    });

    // Category Filters on click
    $('.single-filter input[name="laptopBrands"]').click(function () {
        var allBrandsBoxes = $(".single-filter .smartphone-card");
        var singleBrand = $(this).attr("data-label");
        $("#seeMore").hide();
        $("#seeMoreTwo").hide();
        if (singleBrand === 'allbrands') {
            console.log('brands are alls');
            $(allBrandsBoxes).each((index, elem) => {
                if ($(elem).attr('categoryname')) {
                    $(elem).show();
                } else {
                    $(elem).hide();
                }
            });
            var url = new URL(window.location.href);
            var search_params = url.searchParams;
            search_params.set('selectedCategory', 'allbrands');
            url.search = search_params.toString();
            var new_url = url.toString();
            history.pushState({}, null, new_url);
            if($(".single-filter .smartphone-card").is(":visible")) {
                $(".laptops-cards-wrap #norecords").hide();
            } else {
                $(".laptops-cards-wrap #norecords").show();
            }
            console.log('brands all numbering filtering works')
        } else {
            console.log('brands is selected');
            $(allBrandsBoxes).each((index, elem) => {
                if ($(elem).attr('categoryname') === singleBrand) {
                    $(elem).show();
                } else {
                    $(elem).hide();
                }
            });
            var url = new URL(window.location.href);
            var search_params = url.searchParams;
            search_params.set('selectedCategory', singleBrand);
            url.search = search_params.toString();
            var new_url = url.toString();
            history.pushState({}, null, new_url);
            if($(".single-filter .smartphone-card").is(":visible")) {
                $(".laptops-cards-wrap #norecords").hide();
            } else {
                $(".laptops-cards-wrap #norecords").show();
            }
            console.log('brands is selected numbering filtering works')
        }
        var newTextToRange = $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
        $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange)
    })


    // Filtration based on url parameters
    const currentURL = window.location.href;
    
    function getParameterByNamePhones(name, href) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        const regexS = '[\\?&]' + name + '=([^&#]*)';
        const regex = new RegExp(regexS);
        const results = regex.exec(href);
        if (results == null) return '';
        else return decodeURIComponent(results[1].replace(/\-/g, ' '));
    }

    function queryParamValuePhones(name, url = currentURL) {
        if (!name || !currentURL) return undefined;
        return getParameterByNamePhones(name, url).replace(/_/g, ' ').replace(/[\_\"\'\>\<\?\=\/\/]/g, ' ');
    }

    function updateCardsByQueryParameter() {
        const singleBrand = queryParamValuePhones('selectedCategory', currentURL) || undefined;
        var allBrandsBoxes = $(".single-filter .smartphone-card");
        $("#seeMore").hide();
        $("#seeMoreTwo").hide();
        console.log(singleBrand)
        if (singleBrand === undefined) {
            console.log('brand is undefined')
        } else if (singleBrand === 'allbrands') {
            console.log('brand is all')
            $(allBrandsBoxes).each((index, elem) => {
                if ($(elem).attr('categoryname')) {
                    $(elem).show();
                } else {
                    $(elem).hide();
                }
            });
        } else {
            $(allBrandsBoxes).each((index, elem) => {
                if ($(elem).attr('categoryname') === singleBrand) {
                    $(elem).show();
                } else {
                    $(elem).hide();
                }
            });

            // Calculate Category Cards on page load
            $('.single-filter input[name="laptopBrands"] + label .badge').each(function (index, value) {
                console.log($(value).attr('category'))
                if ($(value).attr('category') == singleBrand) {
                    console.log($(this).closest("div.checkboxes-wrap"))
                    $(".laptops-cards-wrap .checkboxes-wrap").find("input#allbrands").prop("checked", false);
                    $(this).closest("div.checkboxes-wrap").find("input[name='laptopBrands']").prop("checked", true)
                }
            });
            if($(".single-filter .smartphone-card").is(":visible")) {
                $(".laptops-cards-wrap #norecords").hide();
            } else {
                $(".laptops-cards-wrap #norecords").show();
            }
        }

    }

    // Sorting Dropdown
    $(document).on("change", ".laptops-cards-wrap #sortbyLaptops", function() {
        var sortingMethod = $(this).val();
        if(sortingMethod == 'l2h') {
            sortProductsPriceAscendingLaptops();
        } else if(sortingMethod == 'h2l') {
            sortProductsPriceDescendingLaptops();
        } else if(sortingMethod == 'mpopular') {
            sortProductsbyMostPopularLaptops();
        } else if(sortingMethod == 'recommended') {
            sortProductsbyRecommendedLaptops();
        }
    });

    // sort by low to hight
    function sortProductsPriceAscendingLaptops(){
        let smartphonesUrl = window.location.href;
        if ($('.laptops-cards-wrap input[name=laptopBrands]:checked').attr > 0 && $('.laptops-cards-wrap input[name=laptopBrands]:checked').attr('id') !== 'allcategories' || smartphonesUrl.indexOf("selectedCategory") > -1) {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card:visible');
            allCards.show();
            console.log('filters selected no load more');
        } else {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card');
            allCards.show();
            $("#seeMore").hide();
            $("#seeMoreTwo").hide();
            console.log('filters not selected set to All no load more');
        }
        var ascendingProducts = $('.laptops-cards-wrap .smb-smartphonecardsrevamp');
        var newAscendingProducts = $(ascendingProducts).find('.smartphone-card').sort(function (a, b) {
            return $(a).data("price") - $(b).data("price")
        });
        var NewAscendingList = []
        var NewAscendingListProducts = []
        newAscendingProducts.each(function (index, value) {
            NewAscendingList.push($(value).wrap('<div class="card-box"></div>').parent())
        })
        for (const elements of NewAscendingList) {
            NewAscendingListProducts.push($(elements).wrap('<div class="smb-smartphonecardsrevamp"></div>').parent())
        }
        $(".laptops-cards-wrap .smartphone-cards-box").html(NewAscendingListProducts);
    }

    // sort by high to low
    function sortProductsPriceDescendingLaptops(){
        let smartphonesUrl = window.location.href;
        if ($('.laptops-cards-wrap input[name=laptopBrands]:checked').attr > 0 && $('.laptops-cards-wrap input[name=laptopBrands]:checked').attr('id') !== 'allcategories' || smartphonesUrl.indexOf("selectedCategory") > -1) {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card:visible');
            allCards.show();
            console.log('filters selected no load more');
        } else {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card');
            allCards.show();
            $("#seeMore").hide();
            $("#seeMoreTwo").hide();
            console.log('filters not selected set to All no load more');
        }
        var descendingProducts = $('.laptops-cards-wrap .smb-smartphonecardsrevamp');
        var newDescendingProducts = $(descendingProducts).find('.smartphone-card').sort(function (a, b) {
            return $(b).data("price") - $(a).data("price")
        });
        var NewAscendingList = []
        var NewAscendingListProducts = []
        newDescendingProducts.each(function (index, value) {
            NewAscendingList.push($(value).wrap('<div class="card-box"></div>').parent())
        })
        for (const elements of NewAscendingList) {
            NewAscendingListProducts.push($(elements).wrap('<div class="smb-smartphonecardsrevamp"></div>').parent())
        }
        $(".laptops-cards-wrap .smartphone-cards-box").html(NewAscendingListProducts);
    }

    // sort by popular
    function sortProductsbyMostPopularLaptops(){
        let smartphonesUrl = window.location.href;
        if ($('.laptops-cards-wrap input[name=laptopBrands]:checked').attr > 0 && $('.laptops-cards-wrap input[name=laptopBrands]:checked').attr('id') !== 'allcategories' || smartphonesUrl.indexOf("selectedCategory") > -1) {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card:visible');
            allCards.show();
            console.log('filters selected no load more');
        } else {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card');
            allCards.show();
            $("#seeMore").hide();
            $("#seeMoreTwo").hide();
            console.log('filters not selected set to All no load more');
        }
        $('.laptops-cards-wrap .smb-smartphonecardsrevamp').each(function () {
            if ($(this).find('.smartphone-card').hasClass('popular')) {
                $(this).prependTo('.smartphone-cards-box')
            }
        });
    }

    // sort by recommended
    function sortProductsbyRecommendedLaptops(){
        let smartphonesUrl = window.location.href;
        if ($('.laptops-cards-wrap input[name=laptopBrands]:checked').attr > 0 && $('.laptops-cards-wrap input[name=laptopBrands]:checked').attr('id') !== 'allcategories' || smartphonesUrl.indexOf("selectedCategory") > -1) {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card:visible');
            allCards.show();
            console.log('filters selected no load more');
        } else {
            var allCards = $('.laptops-cards-wrap .smartphone-cards-box .smartphone-card');
            allCards.show();
            $("#seeMore").hide();
            $("#seeMoreTwo").hide();
            console.log('filters not selected set to All no load more');
        }
        $('.laptops-cards-wrap .smb-smartphonecardsrevamp').each(function () {
            if ($(this).find('.smartphone-card').hasClass('recommended')) {
                $(this).prependTo('.smartphone-cards-box')
            }
        });
    }

    // Reset Function
    $(".laptops-cards-wrap #resetbtn-laptop, .laptops-cards-wrap #resetbtnTwo-laptops").click(function () {
        $(".laptops-cards-wrap .smartphone-card").show();
        $(".laptops-cards-wrap #norecords").hide();
        // $(".laptops-cards-wrap .smartphone-card:gt(5)").hide();
        var new_url = window.location.href.split('?')[0];
        history.pushState({}, null, new_url);
        $(".accordion").find("input:radio").prop("checked", false);
        $(".laptops-cards-wrap .checkboxes-wrap").find("input#allbrands").prop("checked", true);
        var newTextToRange = $(".laptops-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
        $(".laptops-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange);
        $(".laptops-cards-wrap .smartphone-card").show();
        $(".laptops-cards-wrap .smartphone-card:gt(5)").hide();
        $('#seeMore').show();
        $('#seeMoreTwo').hide();
        $("#norecords").hide();
    })

    // if (smartphonesUrl.includes('selectedCategory')) {
    $(document).ready(function () {
        $("#smartphone-loader").hide();
        var newTextToRange = $(".laptops-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
        $(".laptops-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange);
        let smartphonesUrl = window.location.href;
        if (smartphonesUrl.indexOf("selectedCategory") > -1) {
            // console.log('Parameterised URL');
            updateCardsByQueryParameter();
        } else {
            // console.log('No Parameters in URL');
            $('.laptops-cards-wrap .smartphone-card:gt(5)').hide();
        }
    })