$('.smartphone-cards-wrap input[name="brands"]').click(function () {
	$("#seeMore").hide();
	$("#seeMoreTwo").hide();
	var allBrandsBoxes = $(".smartphone-card");
	var singleBrand = $(this).attr("data-label");
	var url = new URL(window.location.href);
	var search_params = url.searchParams;
	search_params.set('selectedBrand', singleBrand);
	url.search = search_params.toString();
	var new_url = url.toString();
	// console.log(new_url);
	history.pushState({}, null, new_url);
	//var checkedBrand = $('input[name="brands"]:checked').attr('data-label');
	var checkedColor = $('input[name="colors"]:checked').attr('data-color');
	var checkedSpace = $('input[name="storages"]:checked').attr('data-space');
	var checkedOs = $('input[name="osystems"]:checked').attr('data-os');
	if ($(this).attr("data-label") == 'allcategories') {
		switch (true) {
			// default or all checked
			case checkedOs === 'allosystems' && checkedColor === 'allcolors' && checkedSpace == 'allspaces':
				var cardsIndex = $(".smartphone-card[colorname][osname][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('All colors, os and storage checked Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname][storagename='" + storageChecked + "'][colorname]").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][colorname][storagename]").length;
					var colorwithBrand = $(".smartphone-card[categoryname][categoryname][storagename][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname][categoryname][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][categoryname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[osname][colorname][storagename][categoryname]").length;
					// console.log(allOsBoxes, oswithBrand)
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			// all selected
			case checkedColor !== 'allcolors' && checkedSpace !== 'allspaces' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[osname='" + checkedOs + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
				// var cardsIndex = $(".smartphone-card").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						// $(elem).show();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('Not All colors, os and storage checked Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][osname='" + checkedOs + "'][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allOsBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "'][osname]").length;
					// console.log(allOsBoxes, oswithBrand)
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			// checked osystem
			case checkedColor === 'allcolors' && checkedSpace === 'allspaces' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[osname='" + checkedOs + "'][colorname][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('No colors, no storage yes os checked Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname]").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][storagename][colorname").length;
					var colorwithBrand = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename][osname='" + checkedOs + "']").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname][osname='" + checkedOs + "'][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][storagename][osname='" + checkedOs + "']").length;
					var allOsBoxes = $(".smartphone-card[categoryname][colorname][storagename][osname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			// checked space
			case checkedColor === 'allcolors' && checkedSpace !== 'allspaces' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[osname][colorname][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No colors, no os yes storage Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname][storagename='" + storageChecked + "'][colorname]").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var colorwithBrand = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "'][osname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname][osname][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][storagename='" + checkedSpace + "'][osname]").length;
					var allOsBoxes = $(".smartphone-card[categoryname][colorname][storagename='" + checkedSpace + "'][osname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			case checkedColor !== 'allcolors' && checkedSpace === 'allspaces' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[osname][colorname='" + checkedColor + "'][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('No storage, no os yes color Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][storagename][colorname='" + checkedColor + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename][osname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][osname][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][storagename][osname]").length;
					var allOsBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename][osname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			case checkedOs !== 'allosystems' && checkedColor !== 'allcolors' && checkedSpace === 'allspaces':
				var cardsIndex = $(".smartphone-card[osname='" + checkedOs + "'][colorname='" + checkedColor + "'][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('No storage, yes os yes color Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][storagename][colorname='" + checkedColor + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename][osname='" + checkedOs + "']").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][osname='" + checkedOs + "'][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][storagename][osname='" + checkedOs + "']").length;
					var allOsBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename][osname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			case checkedOs === 'allosystems' && checkedColor !== 'allcolors' && checkedSpace !== 'allspaces':
				var cardsIndex = $(".smartphone-card[osname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('osname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No os, yes storage yes color Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "'][osname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][osname][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][storagename='" + checkedSpace + "'][osname]").length;
					var allOsBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "'][osname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			case checkedOs !== 'allosystems' && checkedColor === 'allcolors' && checkedSpace !== 'allspaces':
				var cardsIndex = $(".smartphone-card[osname='" + checkedOs + "'][colorname][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('osname') === checkedOs && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No color, yes storage yes os Brands')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname][osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname]").length;
					var oswithBrand = $(".smartphone-card[categoryname][osname='" + osChecked + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var colorwithBrand = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allStorageBoxes = $(".smartphone-card[categoryname][colorname][osname='" + checkedOs + "'][storagename]").length;
					var allColorBoxes = $(".smartphone-card[categoryname][colorname][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allOsBoxes = $(".smartphone-card[categoryname][colorname][storagename='" + checkedSpace + "'][osname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					}
				});
				break;
			default:
			// $(allBrandsBoxes).each((index, elem) => {
			//   var visibleCards = $(".smartphone-card").is(":visible");
			//   if($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('storagename') && singleBrand === 'allcategories') {
			//     // console.log('Default All colors, all storages, all os checked brands')
			//     $(elem).show()
			//   } else if (!visibleCards) {
			//     $("#norecords").show();

			//   } else {
			//     // console.log('Default Else All colors, all storages, all os checked brands')
			//     $(elem).hide()
			//   }
			// });
		}
	}
	else if ($(this).attr("data-label") !== 'allcategories') {
		switch (true) {
			case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="osystems"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each((index, elem) => {
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each((index, elem) => {
						$("#norecords").hide();
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Brands checked storage, osname and color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var storageColorOsBrandWithChecked = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + osystemChecked + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][colorname='" + checkedColor + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(storageColorOsBrandWithChecked);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(storageColorOsBrandWithChecked);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(storageColorOsBrandWithChecked);
						} else {
							$(value).html(oswithBrand);
						}
					} else if (singleBrand) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === singleBrand) {
							$(value).html(storageColorOsBrandWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allBrandsBoxes).each((index, elem) => {
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each((index, elem) => {
						$("#norecords").hide();
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('Brands checked storage and color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var storageColorBrandWithChecked = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "']").length;
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][storagename='" + storageChecked + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + osystemChecked + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
					// console.log(allColorBoxes)
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(storageColorBrandWithChecked);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(storageColorBrandWithChecked);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if (singleBrand) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === singleBrand) {
							$(value).html(storageColorBrandWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allBrandsBoxes).each((index, elem) => {
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Brands checked osname and color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var osColorBrandWithChecked = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][colorname='" + checkedColor + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + colorChecked + "'][osname='" + checkedOs + "']").length;
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + osystemChecked + "'][colorname='" + checkedColor + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(osColorBrandWithChecked);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(osColorBrandWithChecked);
						} else {
							$(value).html(oswithBrand);
						}
					} else if (singleBrand) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === singleBrand) {
							$(value).html(osColorBrandWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="storages"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allBrandsBoxes).each((index, elem) => {
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Brands checked osname and storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var osStorageBrandWithChecked = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][storagename='" + checkedSpace + "']").length;
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + storageChecked + "'][osname='" + checkedOs + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "'][colorname='" + colorChecked + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + osystemChecked + "'][storagename='" + checkedSpace + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[categoryname][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(osStorageBrandWithChecked);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(osStorageBrandWithChecked);
						} else {
							$(value).html(oswithBrand);
						}
					} else if (singleBrand) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === singleBrand) {
							$(value).html(osStorageBrandWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="osystems"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allBrandsBoxes).each((index, elem) => {
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Brands checked osname')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + osystemChecked + "']").length;
					var checkedosithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][colorname='" + colorChecked + "']").length;
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][storagename='" + storageChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + checkedOs + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(checkedosithBrand);
						} else {
							$(value).html(oswithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="storages"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allBrandsBoxes).each((index, elem) => {
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('Brands checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + storageChecked + "']").length;
					var checkedstoragewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "']").length;
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname='" + colorChecked + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][osname='" + osystemChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + checkedSpace + "'][osname]").length;
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(checkedstoragewithBrand);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allBrandsBoxes).each((index, elem) => {
						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allBrandsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('categoryname') === singleBrand && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
							// console.log('Brands checked color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + colorChecked + "']").length;
					var checkedcolorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "']").length;
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][storagename='" + storageChecked + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][osname='" + osystemChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + checkedColor + "'][osname]").length;
					if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(checkedcolorwithBrand);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			default:
				$(allBrandsBoxes).each((index, elem) => {
					var visibleCards = $(".smartphone-card").is(":visible");
					if ($(elem).attr('categoryname') === singleBrand) {
						$("#norecords").hide();

						$(elem).show()
						// console.log('Brands checked brands')
					} else if (!visibleCards) {
						$("#norecords").show();

					} else {
						$(elem).hide()
					}
				});
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + colorChecked + "']").length;
					var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + storageChecked + "']").length;
					var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + osystemChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname]").length;
					if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithBrand);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithBrand);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithBrand);
						}
					} else {
						// console.log('category radios');
					}
				});
		}


	}
});
$('.smartphone-cards-wrap input[name="colors"]').click(function () {
	$("#seeMore").hide();
	$("#seeMoreTwo").hide();
	var singleColor = $(this).attr("data-color");
	var allColorBoxes = $(".smartphone-card");
	var checkedBrand = $('input[name="brands"]:checked').attr('data-label');
	var checkedSpace = $('input[name="storages"]:checked').attr('data-space');
	var checkedOs = $('input[name="osystems"]:checked').attr('data-os');
	if ($(this).attr("data-color") == 'allcolors') {
		switch (true) {
			case checkedOs === 'allosystems' && checkedBrand === 'allcategories' && checkedSpace == 'allspaces':
				var cardsIndex = $(".smartphone-card[categoryname][osname][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('osname') && $(elem).attr('categoryname') && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('osname') && $(elem).attr('categoryname') && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('All storages, brands and os checked Color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname][storagename='" + storageChecked + "'][osname]").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][osname][storagename]").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname][storagename][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][colorname][categoryname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][colorname][categoryname][storagename").length;
					var allBrandBoxes = $(".smartphone-card[colorname][colorname][storagename][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			// All Unchecked
			case checkedOs !== 'allosystems' && checkedBrand !== 'allcategories' && checkedSpace !== 'allspaces':
				var cardsIndex = $(".smartphone-card[categoryname='" + checkedBrand + "'][osname='" + checkedOs + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('osname') === checkedOs && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('osname') === checkedOs && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No All storage, brands and os checked Color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][osname='" + checkedOs + "']").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "'][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][osname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			// os checked
			case checkedBrand === 'allcategories' && checkedSpace === 'allspaces' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname][storagename][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex);

				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('storagename') && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();

						if ($(elem).attr('storagename') && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('No All storage, no brands and yes os checked Color');
						} else {
							$(elem).hide();
						}
					});
				}

				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname][storagename='" + storageChecked + "'][osname='" + checkedOs + "']").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][storagename][osname='" + checkedOs + "']").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname][storagename][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][categoryname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][osname][categoryname][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][storagename][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			// storage checked
			case checkedBrand === 'allcategories' && checkedSpace !== 'allspaces' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname][storagename='" + checkedSpace + "'][osname]").length;
				// console.log(cardsIndex);

				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') && $(elem).attr('osname')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') && $(elem).attr('osname')) {
							$(elem).show();
							// console.log('No All os, no brands and yes os storage Color');
						} else {
							$(elem).hide();
						}
					});
				}

				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname][storagename='" + storageChecked + "'][osname]").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][storagename='" + checkedSpace + "'][osname]").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname][storagename='" + checkedSpace + "'][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][osname][categoryname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][osname][categoryname][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[colorname][osname][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			// brands checked
			case checkedBrand !== 'allcategories' && checkedSpace === 'allspaces' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname='" + checkedBrand + "'][storagename][osname]").length;
				// console.log(cardsIndex);

				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('storagename') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();

						if ($(elem).attr('storagename') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
							// console.log('No All storage, no os and yes brand Color');
						} else {
							$(elem).hide();
						}
					});
				}

				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][osname]").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][storagename][osname]").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][osname][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][osname][categoryname='" + checkedBrand + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[colorname][osname][storagename][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			// brands and storage checked
			case checkedBrand !== 'allcategories' && checkedSpace !== 'allspaces' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "'][osname]").length;
				// console.log(cardsIndex);

				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
							// console.log('No All os, yes storage and yes brand Color');
						} else {
							$(elem).hide();
						}
					});
				}

				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][osname]").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][storagename='" + checkedSpace + "'][osname]").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "'][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][osname][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][osname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[colorname][osname][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			// brands and os checked
			case checkedBrand !== 'allcategories' && checkedSpace === 'allspaces' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname='" + checkedBrand + "'][storagename][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex);

				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('storagename') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();

						if ($(elem).attr('storagename') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('No All storage, yes os and yes brand Color');
						} else {
							$(elem).hide();
						}
					});
				}

				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][osname='" + checkedOs + "']").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][storagename][osname='" + checkedOs + "']").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][osname][categoryname='" + checkedBrand + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][storagename][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			// storage and os checked
			case checkedBrand === 'allcategories' && checkedSpace !== 'allspaces' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex);

				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allColorBoxes).each(function (index, elem) {
						if ($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each(function (index, elem) {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === checkedSpace && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('No All brands, yes os and yes storage Color');
						} else {
							$(elem).hide();
						}
					});
				}

				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname][categoryname][storagename='" + storageChecked + "'][osname='" + checkedOs + "']").length;
					var brandwithColor = $(".smartphone-card[colorname][categoryname='" + catChecked + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var oswithColor = $(".smartphone-card[colorname][categoryname][storagename='" + checkedSpace + "'][osname='" + osChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][categoryname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname][osname][categoryname][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[colorname][osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					}
				});
				break;
			default:
			// $(allColorBoxes).each((index, elem) => {
			//   var visibleCards = $(".smartphone-card").is(":visible");
			//   if($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('storagename') && singleBrand === 'allcategories') {
			//     // console.log('Default All colors, all storages, all os checked brands')
			//     $("#norecords").hide();

			//     $(elem).show();
			//   } else if (!visibleCards) {
			//     $("#norecords").show();

			//   } else {
			//     // console.log('Default Else All colors, all storages, all os checked brands colors')
			//     $(elem).hide()
			//   }
			// });
		}
	}
	else if ($(this).attr("data-color") !== 'allcolors') {
		switch (true) {
			case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked') && $('input[name="osystems"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Colors checked storage, brand and osname')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var storageColorOsBrandWithChecked = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + storageChecked + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + osystemChecked + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "']").length;
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + catChecked + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allColorBoxes = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(storageColorOsBrandWithChecked);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(storageColorOsBrandWithChecked);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(storageColorOsBrandWithChecked);
						} else {
							$(value).html(storagewithColor);
						}
					} else if (singleColor) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === singleColor) {
							$(value).html(storageColorOsBrandWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});

				break;
			case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('Colors checked storage and brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var storageBrandColorWithChecked = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "']").length;
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + catChecked + "']").length;
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + storageChecked + "'][categoryname='" + checkedBrand + "']").length;
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + osystemChecked + "'][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var allColorBoxes = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					// console.log(oswithColor, allOsBoxes)
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(storageBrandColorWithChecked);
						} else {
							$(value).html(storagewithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(storageBrandColorWithChecked);
						} else {
							$(value).html(brandwithColor);
						}
					} else if (singleColor) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === singleColor) {
							$(value).html(storageBrandColorWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname='" + checkedBrand + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Colors checked osname and brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var osBrandColorWithChecked = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname='" + checkedBrand + "']").length;
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname='" + catChecked + "']").length;
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][storagename='" + storageChecked + "']").length;
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + osystemChecked + "'][categoryname='" + checkedBrand + "']").length;
					var allColorBoxes = $(".smartphone-card[colorname][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(osBrandColorWithChecked);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(osBrandColorWithChecked);
						} else {
							$(value).html(brandwithColor);
						}
					} else if (singleColor) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === singleColor) {
							$(value).html(osBrandColorWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="storages"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor && $(elem).attr('storagename') === checkedSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Colors checked osname and storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var osStorageColorWithChecked = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][storagename='" + checkedSpace + "']").length;
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + storageChecked + "'][osname='" + checkedOs + "']").length;
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname='" + catChecked + "']").length;
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + osystemChecked + "'][storagename='" + checkedSpace + "']").length;
					var allColorBoxes = $(".smartphone-card[colorname][storagename='" + checkedSpace + "'][osname='" + checkedOs + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(osStorageColorWithChecked);
						} else {
							$(value).html(storagewithColor);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(osStorageColorWithChecked);
						} else {
							$(value).html(oswithColor);
						}
					} else if (singleColor) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === singleColor) {
							$(value).html(osStorageColorWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="osystems"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Colors checked osname')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + osystemChecked + "']").length;
					var checkedoswithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "']").length;
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname='" + catChecked + "']").length;
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][storagename='" + storageChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(checkedoswithColor);
						} else {
							$(value).html(oswithColor);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="storages"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('Colors checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + storageChecked + "']").length;
					var checkedstoragewithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "']").length;
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname='" + catChecked + "']").length;
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][osname='" + osystemChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(checkedstoragewithColor);
						} else {
							$(value).html(storagewithColor);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor && $(elem).attr('categoryname') === checkedBrand) {
							$(elem).show();
							// console.log('Colors checked brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + catChecked + "']").length;
					var checkedbrandwithBrand = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "']").length;
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "']").length;
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "'][osname='" + osystemChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + checkedBrand + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(checkedbrandwithBrand);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			default:
				var cardsIndex = $(".smartphone-card[colorname='" + singleColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allColorBoxes).each((index, elem) => {
						if ($(elem).attr('colorname') === singleColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allColorBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('colorname') === singleColor) {
							$(elem).show();
							// console.log('Colors checked brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var osystemChecked = $(value).attr('osname');
					var brandwithColor = $(".smartphone-card[colorname='" + singleColor + "'][categoryname='" + catChecked + "']").length;
					var storagewithColor = $(".smartphone-card[colorname='" + singleColor + "'][storagename='" + storageChecked + "']").length;
					var oswithColor = $(".smartphone-card[colorname='" + singleColor + "'][osname='" + osystemChecked + "']").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + singleColor + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[colorname='" + singleColor + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + singleColor + "'][osname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithColor);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithColor);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithColor);
						}
					} else {
						// console.log('category radios');
					}
				});
		}
	}
});
$('.smartphone-cards-wrap input[name="storages"]').click(function () {
	$("#seeMore").hide();
	$("#seeMoreTwo").hide();
	var singleSpace = $(this).attr("data-space");
	var allSpaceBoxes = $(".smartphone-card");
	var checkedBrand = $('input[name="brands"]:checked').attr('data-label');
	var checkedColor = $('input[name="colors"]:checked').attr('data-color');
	var checkedOs = $('input[name="osystems"]:checked').attr('data-os');
	if ($(this).attr("data-space") == 'allspaces') {
		switch (true) {
			case checkedBrand === 'allcategories' && checkedColor === 'allcolors' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname][colorname][osname]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('osname')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('osname')) {
							$(elem).show();
							// console.log('All colors, brands and osystem checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var oswithSpace = $(".smartphone-card[storagename][osname='" + osChecked + "'][categoryname][colorname").length;
					var brandwithSpace = $(".smartphone-card[storagename][categoryname='" + catChecked + "'][colorname][osname").length;
					var colorwithSpace = $(".smartphone-card[storagename][categoryname][osname][colorname='" + colorChecked + "']").length;
					var allOsBoxes = $(".smartphone-card[storagename][colorname][categoryname][osname]").length;
					var allColorBoxes = $(".smartphone-card[storagename][colorname][categoryname][osname").length;
					var allBrandBoxes = $(".smartphone-card[storagename][colorname][osname][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			case checkedBrand !== 'allcategories' && checkedColor !== 'allcolors' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('No All colors, brands and os checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var oswithSpace = $(".smartphone-card[storagename][osname='" + osChecked + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
					var brandwithSpace = $(".smartphone-card[storagename][categoryname='" + catChecked + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
					var colorwithSpace = $(".smartphone-card[storagename][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "'][colorname='" + colorChecked + "']").length;
					var allOsBoxes = $(".smartphone-card[storagename][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][osname]").length;
					var allColorBoxes = $(".smartphone-card[storagename][colorname][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
					var allBrandBoxes = $(".smartphone-card[storagename][colorname='" + checkedColor + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			// os checked
			case checkedBrand === 'allcategories' && checkedColor === 'allcolors' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname][colorname][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('No All colors, no brands and yes os checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var oswithSpace = $(".smartphone-card[osname='" + osChecked + "'][categoryname][storagename][colorname").length;
					var brandwithSpace = $(".smartphone-card[osname='" + checkedOs + "'][categoryname='" + catChecked + "'][colorname][storagename]").length;
					var colorwithSpace = $(".smartphone-card[osname='" + checkedOs + "'][categoryname][storagename][colorname='" + colorChecked + "']").length;
					var allOsBoxes = $(".smartphone-card[osname][colorname][categoryname][storagename]").length;
					var allColorBoxes = $(".smartphone-card[osname='" + checkedOs + "'][colorname][categoryname][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + checkedOs + "'][colorname][storagename][categoryname]").length;

					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			// color checked
			case checkedBrand === 'allcategories' && checkedOs === 'allosystems' && checkedColor !== 'allcolors':
				var cardsIndex = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][osname]").length;
				// console.log(cardsIndex + 'colorstorageall');
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('osname')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('osname')) {
							$(elem).show();
							// console.log('No All brands, no os and yes colors checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var colorwithSpace = $(".smartphone-card[colorname='" + colorChecked + "'][categoryname][storagename][osname").length;
					var brandwithSpace = $(".smartphone-card[colorname='" + checkedColor + "'][categoryname='" + catChecked + "'][osname][storagename]").length;
					var oswithSpace = $(".smartphone-card[colorname='" + checkedColor + "'][categoryname][storagename][osname='" + osChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[colorname][osname][categoryname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[colorname='" + checkedColor + "'][osname][categoryname][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[colorname='" + checkedColor + "'][osname][storagename][categoryname]").length;

					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			// brand checked
			case checkedBrand !== 'allcategories' && checkedColor === 'allcolors' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname][osname]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
							// console.log('No All storages, colors and yes brands checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var colorwithSpace = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "'][storagename][osname]").length;
					var brandwithSpace = $(".smartphone-card[categoryname='" + catChecked + "'][categoryname][osname][storagename]").length;
					var oswithSpace = $(".smartphone-card[categoryname='" + checkedBrand + "'][categoryname][storagename][osname='" + osChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + checkedBrand + "'][osname][colorname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + checkedBrand + "'][osname][colorname][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname][storagename][colorname]").length;

					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			// brand and color checked
			case checkedBrand !== 'allcategories' && checkedColor !== 'allcolors' && checkedOs === 'allosystems':
				var cardsIndex = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname')) {
							$(elem).show();
							// console.log('No All osystem yes colors and yes brands checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var colorwithSpace = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "'][storagename][osname]").length;
					var brandwithSpace = $(".smartphone-card[categoryname='" + catChecked + "'][storagename][osname][colorname='" + checkedColor + "']").length;
					var oswithSpace = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "'][storagename][osname='" + osChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + checkedBrand + "'][osname][colorname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + checkedBrand + "'][osname][colorname='" + checkedColor + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[categoryname][osname][storagename][colorname='" + checkedColor + "']").length;

					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			// checked brand and os
			case checkedBrand !== 'allcategories' && checkedColor === 'allcolors' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[storagename][categoryname='" + checkedBrand + "'][colorname][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('No All colors yes os and yes brands checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var colorwithSpace = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "'][storagename][osname='" + checkedOs + "']").length;
					var brandwithSpace = $(".smartphone-card[categoryname='" + catChecked + "'][storagename][osname='" + checkedOs + "'][colorname]").length;
					var oswithSpace = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname][storagename][osname='" + osChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname='" + checkedBrand + "'][osname='" + checkedOs + "'][colorname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname='" + checkedBrand + "'][osname][colorname][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[categoryname][osname='" + checkedOs + "'][storagename][colorname]").length;

					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			// checked color and os
			case checkedBrand === 'allcategories' && checkedColor !== 'allcolors' && checkedOs !== 'allosystems':
				var cardsIndex = $(".smartphone-card[storagename][categoryname][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allSpaceBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('No All brand yes os and yes colors checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osChecked = $(value).attr('osname');
					var colorwithSpace = $(".smartphone-card[categoryname][colorname='" + colorChecked + "'][storagename][osname='" + checkedOs + "']").length;
					var brandwithSpace = $(".smartphone-card[categoryname='" + catChecked + "'][storagename][osname='" + checkedOs + "'][colorname='" + checkedColor + "']").length;
					var oswithSpace = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename][osname='" + osChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[categoryname][osname='" + checkedOs + "'][colorname][storagename]").length;
					var allOsBoxes = $(".smartphone-card[categoryname][osname][colorname][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[categoryname][osname='" + checkedOs + "'][storagename][colorname='" + checkedColor + "']").length;

					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithSpace);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithSpace);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithSpace);
						}
					}
				});
				break;
			// default:
			// $(allOsBoxes).each((index, elem) => {
			//   var visibleCards = $(".smartphone-card").is(":visible");
			//   if($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('categoryname') && singleBrand === 'allcategories') {
			//     // console.log('Default All colors, all storages, all os checked brands storage')
			//     $("#norecords").hide();

			//     $(elem).show();
			//   } else if (!visibleCards) {
			//     $("#norecords").show();

			//   } else {
			//     // console.log('Default Else All colors, all storages, all os checked brands storage')
			//     $(elem).hide()
			//   }
			// });
		}

	}
	else if ($(this).attr("data-space") !== 'allspaces') {
		switch (true) {
			case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked') && $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
							// console.log('Storage checked color,storage and brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osystemChecked = $(value).attr('osname');
					var brandColorOsStorageWithChecked = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "'][osname='" + checkedOs + "']").length;
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + osystemChecked + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + colorChecked + "'][categoryname='" + catChecked + "'][osname='" + checkedOs + "']").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[storagename][osname='" + checkedOs + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(brandColorOsStorageWithChecked);
						} else {
							$(value).html(brandwithStorage);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(brandColorOsStorageWithChecked);
						} else {
							$(value).html(colorwithStorage);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(brandColorOsStorageWithChecked);
						} else {
							$(value).html(oswithStorage);
						}
					} else if (singleSpace) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === singleSpace) {
							$(value).html(brandColorOsStorageWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;

			case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
							// console.log('Storage checked color and brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osystemChecked = $(value).attr('osname');
					var brandColorStorageWithChecked = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']").length;
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][osname='" + osystemChecked + "']").length;
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[storagename][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(brandColorStorageWithChecked);
						} else {
							$(value).html(brandwithStorage);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(brandColorStorageWithChecked);
						} else {
							$(value).html(colorwithStorage);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithStorage);
						}
					} else if (singleSpace) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === singleSpace) {
							$(value).html(brandColorStorageWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;

			case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Storage checked osname and brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osystemChecked = $(value).attr('osname');
					var brandColorStorageWithChecked = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']").length;
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname='" + osystemChecked + "']").length;
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][categoryname='" + catChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[storagename][categoryname='" + checkedBrand + "'][osname='" + checkedOs + "']").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(brandColorStorageWithChecked);
						} else {
							$(value).html(brandwithStorage);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(brandColorStorageWithChecked);
						} else {
							$(value).html(colorwithStorage);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithStorage);
						}
					} else if (singleSpace) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === singleSpace) {
							$(value).html(brandColorStorageWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;

			case $('input[name="osystems"]:not(:eq(0))').is(':checked') && $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('colorname') === checkedColor && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Storage checked osname and color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var osystemChecked = $(value).attr('osname');
					var osColorStorageWithChecked = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][osname='" + checkedOs + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][colorname='" + colorChecked + "']").length;
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][osname='" + osystemChecked + "']").length;
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][categoryname='" + catChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[storagename][colorname='" + colorChecked + "'][osname='" + checkedOs + "']").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + colorChecked + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + colorChecked + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(osColorStorageWithChecked);
						} else {
							$(value).html(oswithStorage);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(osColorStorageWithChecked);
						} else {
							$(value).html(colorwithStorage);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithStorage);
						}
					} else if (singleSpace) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === singleSpace) {
							$(value).html(osColorStorageWithChecked);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			case $('input[name="osystems"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('osname') === checkedOs) {
							$(elem).show();
							// console.log('Storage checked osname')
						} else {
							$(elem).hide();
						}
					});
				}

				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var osystemChecked = $(value).attr('osname');
					var colorChecked = $(value).attr('color');
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + osystemChecked + "']").length;
					var checkedoswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][colorname='" + colorChecked + "']").length;
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][categoryname='" + catChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][colorname]").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + checkedOs + "'][categoryname]").length;
					if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === checkedOs) {
							$(value).html(checkedoswithStorage);
						} else {
							$(value).html(oswithStorage);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithStorage);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithStorage);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
							// console.log('Storage checked color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var osystemChecked = $(value).attr('osname');
					var colorChecked = $(value).attr('color');
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][osname='" + osystemChecked + "'").length;
					var checkedoswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + colorChecked + "']").length;
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname]").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + checkedColor + "'][categoryname]").length;
					if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(checkedoswithStorage);
						} else {
							$(value).html(colorwithStorage);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithStorage);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithStorage);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;


			case $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace && $(elem).attr('categoryname') === checkedBrand) {
							$(elem).show();
							// console.log('Storage checked brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var osystemChecked = $(value).attr('osname');
					var colorChecked = $(value).attr('color');
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname='" + osystemChecked + "'").length;
					var checkedoswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']").length;
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + catChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][colorname]").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + checkedBrand + "'][osname]").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname]").length;
					if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithStorage);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithStorage);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(checkedoswithStorage);
						} else {
							$(value).html(brandwithStorage);
						}
					} else {
						// console.log('category radios');
					}
				});
				break;
			default:
				var cardsIndex = $(".smartphone-card[storagename='" + singleSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allSpaceBoxes).each((index, elem) => {
						if ($(elem).attr('storagename') === singleSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allSpaceBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('storagename') === singleSpace) {
							$(elem).show();
							// console.log('Storage checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var colorChecked = $(value).attr('color');
					var osystemChecked = $(value).attr('osname');
					var brandwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][categoryname='" + catChecked + "']").length;
					var colorwithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][colorname='" + colorChecked + "']").length;
					var oswithStorage = $(".smartphone-card[storagename='" + singleSpace + "'][osname='" + osystemChecked + "']").length;
					var allBrandBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][colorname]").length;
					var allColorBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[storagename='" + singleSpace + "'][osname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithStorage);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithStorage);
						}
					} else if ($(value).attr('osname')) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else {
							$(value).html(oswithStorage);
						}
					} else {
						// console.log('category radios');
					}
				});
		}
	}
});
$('.smartphone-cards-wrap input[name="osystems"]').click(function () {
	$("#seeMore").hide();
	$("#seeMoreTwo").hide();
	var singleOS = $(this).attr("data-os");
	var allOsBoxes = $(".smartphone-card");
	var checkedBrand = $('input[name="brands"]:checked').attr('data-label');
	var checkedColor = $('input[name="colors"]:checked').attr('data-color');
	var checkedSpace = $('input[name="storages"]:checked').attr('data-space');
	if ($(this).attr("data-os") == 'allosystems') {
		switch (true) {
			case checkedBrand === 'allcategories' && checkedColor === 'allcolors' && checkedSpace == 'allspaces':
				var cardsIndex = $(".smartphone-card[categoryname][osname][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('All colors, brands and storage checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname][storagename='" + storageChecked + "'][colorname]").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname][storagename").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname][storagename][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][colorname][categoryname][storagename]").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname][storagename").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname][storagename][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});
				break;
			case checkedBrand !== 'allcategories' && checkedColor !== 'allcolors' && checkedSpace !== 'allspaces':
				var cardsIndex = $(".smartphone-card[categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex + 'he;;');
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No All colors, brands and os checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "'][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});
				break;
			case checkedBrand === 'allcategories' && checkedColor === 'allcolors' && checkedSpace !== 'allspaces':
				var cardsIndex = $(".smartphone-card[categoryname][colorname][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No All colors, brands and yes storage checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname][storagename='" + storageChecked + "'][colorname").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname][storagename='" + checkedSpace + "']").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname][storagename='" + checkedSpace + "'][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][colorname][categoryname][storagename]").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname][storagename='" + checkedSpace + "'][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});
				break;
			case checkedBrand === 'allcategories' && checkedColor !== 'allcolors' && checkedSpace === 'allspaces':
				var cardsIndex = $(".smartphone-card[categoryname][colorname='" + checkedColor + "'][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('No All storages, brands and yes color checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname='" + checkedColor + "'][storagename]").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname][storagename][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][storagename][categoryname][colorname='" + checkedColor + "']").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][storagename][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});
				break;
			case checkedBrand !== 'allcategories' && checkedColor === 'allcolors' && checkedSpace === 'allspaces':
				var cardsIndex = $(".smartphone-card[categoryname][colorname][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('No All storages, colors and yes brands checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][colorname]").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname][storagename]").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][colorname][categoryname='" + checkedBrand + "'][storagename]").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname='" + checkedBrand + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname][storagename][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});
				break;
			case checkedBrand !== 'allcategories' && checkedColor !== 'allcolors' && checkedSpace === 'allspaces':
				var cardsIndex = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "'][storagename]").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename')) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename')) {
							$(elem).show();
							// console.log('No All storages yescolors and yes brands checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname='" + checkedColor + "'][storagename]").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][storagename][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname='" + checkedBrand + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][storagename][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});
				break;
			case checkedBrand !== 'allcategories' && checkedColor === 'allcolors' && checkedSpace !== 'allspaces':
				var cardsIndex = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][colorname][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No All colors yes storages and yes brands checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][colorname]").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname][storagename='" + checkedSpace + "']").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "'][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][colorname][categoryname='" + checkedBrand + "'][storagename").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname][storagename='" + checkedSpace + "'][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});
				break;
			case checkedBrand === 'allcategories' && checkedColor !== 'allcolors' && checkedSpace !== 'allspaces':
				var cardsIndex = $(".smartphone-card[osname][categoryname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex);
				if (cardsIndex == 0) {
					$("#norecords").show();
					$(allOsBoxes).each(function (index, elem) {
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each(function (index, elem) {
						$("#norecords").hide();
						if ($(elem).attr('colorname') === checkedColor && $(elem).attr('categoryname') && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('No All brand yes storages and yes colors checked osystem')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var catChecked = $(value).attr('cat');
					var storagewithOs = $(".smartphone-card[osname][categoryname][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var brandwithOs = $(".smartphone-card[osname][categoryname='" + catChecked + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
					var colorwithOS = $(".smartphone-card[osname][categoryname][storagename='" + checkedSpace + "'][colorname='" + colorChecked + "']").length;
					var allStorageBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][categoryname][storagename").length;
					var allColorBoxes = $(".smartphone-card[osname][colorname][categoryname][storagename='" + checkedSpace + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					// console.log(storagewithOs, allStorageBoxes)
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOS);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					}
				});

				break;
			default:
			// $(allOsBoxes).each((index, elem) => {
			//   var visibleCards = $(".smartphone-card").is(":visible");
			//   if($(elem).attr('colorname') && $(elem).attr('osname') && $(elem).attr('categoryname') && singleBrand === 'allcategories') {
			//     // console.log('Default All colors, all storages, all os checked brands storage')
			//     $("#norecords").hide();

			//     $(elem).show();
			//   } else if (!visibleCards) {
			//     $("#norecords").show();

			//   } else {
			//     // console.log('Default Else All colors, all storages, all os checked brands storage')
			//     $(elem).hide()
			//   }
			// });
		}
	}
	else if ($(this).attr("data-os") !== 'allosystems') {
		switch (true) {
			case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked') && $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
							// console.log('OsName checked storage, brand and color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var colorBrandStorageOsWithChecked = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + colorChecked + "'][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "'][colorname='" + checkedColor + "']").length;
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + catChecked + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(colorBrandStorageOsWithChecked);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(colorBrandStorageOsWithChecked);
						} else {
							$(value).html(colorwithOs);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(colorBrandStorageOsWithChecked);
						} else {
							$(value).html(storagewithOs);
						}
					} else if (singleOS) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === singleOS) {
							$(value).html(colorBrandStorageOsWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
							// console.log('OsName checked brand and color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var colorBrandOsWithChecked = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + colorChecked + "'][categoryname='" + checkedBrand + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "']").length;
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + catChecked + "'][colorname='" + checkedColor + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[osname][colorname='" + checkedColor + "'][categoryname='" + checkedBrand + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(colorBrandOsWithChecked);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(colorBrandOsWithChecked);
						} else {
							$(value).html(colorwithOs);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					} else if (singleOS) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} if ($(value).attr('osname') === singleOS) {
							$(value).html(colorBrandOsWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="storages"]:not(:eq(0))').is(':checked') && $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('OsName checked brand and storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var storageBrandOsWithChecked = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + colorChecked + "'][categoryname='" + checkedBrand + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "']").length;
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + catChecked + "'][storagename='" + checkedSpace + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][categoryname='" + checkedBrand + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(storageBrandOsWithChecked);
						} else {
							$(value).html(colorwithOs);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(storageBrandOsWithChecked);
						} else {
							$(value).html(storagewithOs);
						}
					} else if (singleOS) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === singleOS) {
							$(value).html(storageBrandOsWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="colors"]:not(:eq(0))').is(':checked') && $('input[name="storages"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS && $(elem).attr('colorname') === checkedColor && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('OsName checked color and storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var catChecked = $(value).attr('cat');
					var storageColorOsWithChecked = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + colorChecked + "'][storagename='" + checkedSpace + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][storagename='" + storageChecked + "']").length;
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][storagename]").length;
					var allOsBoxes = $(".smartphone-card[osname][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "']").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][colorname='" + checkedColor + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(storageColorOsWithChecked);
						} else {
							$(value).html(colorwithOs);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(storageColorOsWithChecked);
						} else {
							$(value).html(storagewithOs);
						}
					} else if (singleOS) {
						if ($(value).attr('osname') === 'allos') {
							$(value).html(allOsBoxes);
						} else if ($(value).attr('osname') === singleOS) {
							$(value).html(storageColorOsWithChecked);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="storages"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS && $(elem).attr('storagename') === checkedSpace) {
							$(elem).show();
							// console.log('OsName checked storage')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][categoryname='" + catChecked + "']").length;
					var checkedbrandwithOs = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + storageChecked + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][colorname='" + colorChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + checkedSpace + "'][categoryname]").length;
					if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else if ($(value).attr('space') === checkedSpace) {
							$(value).html(checkedbrandwithOs);
						} else {
							$(value).html(storagewithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOs);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="colors"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS && $(elem).attr('colorname') === checkedColor) {
							$(elem).show();
							// console.log('OsName checked color')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname='" + catChecked + "']").length;
					var checkedbrandwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][storagename='" + storageChecked + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + colorChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + checkedColor + "'][categoryname]").length;
					if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else if ($(value).attr('color') === checkedColor) {
							$(value).html(checkedbrandwithOs);
						} else {
							$(value).html(colorwithOs);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					} else if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			case $('input[name="brands"]:not(:eq(0))').is(':checked'):
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS && $(elem).attr('categoryname') === checkedBrand) {
							$(elem).show();
							// console.log('OsName checked brand')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var storageChecked = $(value).attr('space');
					var colorChecked = $(value).attr('color');
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + catChecked + "']").length;
					var checkedbrandwithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename='" + storageChecked + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][colorname='" + colorChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + checkedBrand + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else if ($(value).attr('cat') === checkedBrand) {
							$(value).html(checkedbrandwithOs);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOs);
						}
					} else {
						//// console.log('category radios');
					}
				});
				break;
			default:
				var cardsIndex = $(".smartphone-card[osname='" + singleOS + "']").length;
				// console.log(cardsIndex)
				if (cardsIndex == 0) {
					$("#norecords").show();

					$(allOsBoxes).each((index, elem) => {
						if ($(elem).attr('osname') === singleOS) {
							$(elem).show();
						} else {
							$(elem).hide();
						}
					});
				} else {
					$(allOsBoxes).each((index, elem) => {
						$("#norecords").hide();

						if ($(elem).attr('osname') === singleOS) {
							$(elem).show();
							// console.log('OsName checked osname')
						} else {
							$(elem).hide();
						}
					});
				}
				$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
					var catChecked = $(value).attr('cat');
					var colorChecked = $(value).attr('color');
					var storageChecked = $(value).attr('space');
					var brandwithOs = $(".smartphone-card[osname='" + singleOS + "'][categoryname='" + catChecked + "']").length;
					var colorwithOs = $(".smartphone-card[osname='" + singleOS + "'][colorname='" + colorChecked + "']").length;
					var storagewithOs = $(".smartphone-card[osname='" + singleOS + "'][storagename='" + storageChecked + "']").length;
					var allColorBoxes = $(".smartphone-card[osname='" + singleOS + "'][colorname]").length;
					var allStorageBoxes = $(".smartphone-card[osname='" + singleOS + "'][storagename]").length;
					var allBrandBoxes = $(".smartphone-card[osname='" + singleOS + "'][categoryname]").length;
					if ($(value).attr('cat')) {
						if ($(value).attr('cat') === 'allcategories') {
							$(value).html(allBrandBoxes);
						} else {
							$(value).html(brandwithOs);
						}
					} else if ($(value).attr('color')) {
						if ($(value).attr('color') === 'allcolors') {
							$(value).html(allColorBoxes);
						} else {
							$(value).html(colorwithOs);
						}
					} else if ($(value).attr('space')) {
						if ($(value).attr('space') === 'allspaces') {
							$(value).html(allStorageBoxes);
						} else {
							$(value).html(storagewithOs);
						}
					} else {
						//// console.log('category radios');
					}
				});
		}
	}
});


$(document).on("change", ".smartphone-cards-wrap #sortby", function () {
	var sortingMethod = $(this).val();
	if (sortingMethod == 'l2h') {
		sortProductsPriceAscending();
	} else if (sortingMethod == 'h2l') {
		sortProductsPriceDescending();
	} else if (sortingMethod == 'mpopular') {
		sortProductsbyMostPopular();
	} else if (sortingMethod == 'recommended') {
		sortProductsbyRecommended();
	}
});

function sortProductsPriceAscending() {
	let smartphonesUrl = window.location.href;
	if ($('input[name=brands]:checked').attr > 0 && $('input[name=brands]:checked').attr('id') !== 'allcategories' || $('input[name=colors]:checked').length > 0 && $('input[name=colors]:checked').attr('id') !== 'allcolors' || $('input[name=storages]:checked').length > 0 && $('input[name=storages]:checked').attr('id') !== 'allspaces' || $('input[name=osystems]:checked').length > 0 && $('input[name=osystems]:checked').attr('id') !== 'allos' || smartphonesUrl.indexOf("selectedBrand") > -1) {
		var allCards = $('.smartphone-cards-box .smartphone-card:visible');
		allCards.show();
		// console.log('filters selected no load more');
	} else {
		var allCards = $('.smartphone-cards-box .smartphone-card');
		allCards.show();
		$("#seeMore").hide();
		$("#seeMoreTwo").hide();
		// console.log('filters not selected set to All no load more');
	}
	var ascendingProducts = $('.smb-smartphonecards');
	var newAscendingProducts = $(ascendingProducts).find('.smartphone-card').sort(function (a, b) {
		return $(a).data("price") - $(b).data("price")
	});
	var NewAscendingList = []
	var NewAscendingListProducts = []
	newAscendingProducts.each(function (index, value) {
		NewAscendingList.push($(value).wrap('<div class="card-box"></div>').parent())
	})
	for (const elements of NewAscendingList) {
		NewAscendingListProducts.push($(elements).wrap('<div class="smb-smartphonecards"></div>').parent())
	}
	$(".smartphone-cards-box").html(NewAscendingListProducts);
}
function sortProductsPriceDescending() {
	let smartphonesUrl = window.location.href;
	if ($('input[name=brands]:checked').attr > 0 && $('input[name=brands]:checked').attr('id') !== 'allcategories' || $('input[name=colors]:checked').length > 0 && $('input[name=colors]:checked').attr('id') !== 'allcolors' || $('input[name=storages]:checked').length > 0 && $('input[name=storages]:checked').attr('id') !== 'allspaces' || $('input[name=osystems]:checked').length > 0 && $('input[name=osystems]:checked').attr('id') !== 'allos' || smartphonesUrl.indexOf("selectedBrand") > -1) {
		var allCards = $('.smartphone-cards-box .smartphone-card:visible');
		allCards.show();
		// console.log('filters selected no load more');
	} else {
		var allCards = $('.smartphone-cards-box .smartphone-card');
		allCards.show();
		$("#seeMore").hide();
		$("#seeMoreTwo").hide();
		// console.log('filters not selected set to All no load more');
	}
	var descendingProducts = $('.smb-smartphonecards');
	var newDescendingProducts = $(descendingProducts).find('.smartphone-card').sort(function (a, b) {
		return $(b).data("price") - $(a).data("price")
	});
	var NewAscendingList = []
	var NewAscendingListProducts = []
	newDescendingProducts.each(function (index, value) {
		NewAscendingList.push($(value).wrap('<div class="card-box"></div>').parent())
	})
	for (const elements of NewAscendingList) {
		NewAscendingListProducts.push($(elements).wrap('<div class="smb-smartphonecards"></div>').parent())
	}
	$(".smartphone-cards-box").html(NewAscendingListProducts);
}
function sortProductsbyMostPopular() {
	let smartphonesUrl = window.location.href;
	if ($('input[name=brands]:checked').attr > 0 && $('input[name=brands]:checked').attr('id') !== 'allcategories' || $('input[name=colors]:checked').length > 0 && $('input[name=colors]:checked').attr('id') !== 'allcolors' || $('input[name=storages]:checked').length > 0 && $('input[name=storages]:checked').attr('id') !== 'allspaces' || $('input[name=osystems]:checked').length > 0 && $('input[name=osystems]:checked').attr('id') !== 'allos' || smartphonesUrl.indexOf("selectedBrand") > -1) {
		var allCards = $('.smartphone-cards-box .smartphone-card:visible');
		allCards.show();
		// console.log('filters selected no load more');
	} else {
		var allCards = $('.smartphone-cards-box .smartphone-card');
		allCards.show();
		$("#seeMore").hide();
		$("#seeMoreTwo").hide();
		// console.log('filters not selected set to All no load more');
	}
	$('.smb-smartphonecards').each(function () {
		if ($(this).find('.smartphone-card').hasClass('popular')) {
			$(this).prependTo('.smartphone-cards-box')
		}
	});
}
function sortProductsbyRecommended() {
	let smartphonesUrl = window.location.href;
	if ($('input[name=brands]:checked').attr > 0 && $('input[name=brands]:checked').attr('id') !== 'allcategories' || $('input[name=colors]:checked').length > 0 && $('input[name=colors]:checked').attr('id') !== 'allcolors' || $('input[name=storages]:checked').length > 0 && $('input[name=storages]:checked').attr('id') !== 'allspaces' || $('input[name=osystems]:checked').length > 0 && $('input[name=osystems]:checked').attr('id') !== 'allos' || smartphonesUrl.indexOf("selectedBrand") > -1) {
		var allCards = $('.smartphone-cards-box .smartphone-card:visible');
		allCards.show();
		// console.log('filters selected no load more');
	} else {
		var allCards = $('.smartphone-cards-box .smartphone-card');
		allCards.show();
		$("#seeMore").hide();
		$("#seeMoreTwo").hide();
		// console.log('filters not selected set to All no load more');
	}
	$('.smb-smartphonecards').each(function () {
		if ($(this).find('.smartphone-card').hasClass('recommended')) {
			$(this).prependTo('.smartphone-cards-box')
		}
	});
}
// Reset Button Function
function resetButton() {
	$(" .smartphone-cards-wrap #resetbtn,.smartphone-cards-wrap #resetbtn-two").click(function () {
		$(".smartphone-cards-box .smartphone-card").show();
		$(".smartphone-cards-box .smartphone-card:gt(5)").hide();
		// $(".smartphone-cards-box .smartphone-card:lt(6)").show();
		// console.log('reset btn');
		$('#seeMore').show();
		$('#seeMoreTwo').hide();
		$("#norecords").hide();
        var new_url = window.location.href.split('?')[0];
        history.pushState({}, null, new_url);
		// $('.smartphone-cards-box .smartphone-card:lt('+x+')').fadeIn();
		$(".accordion").find("input:checkbox").prop("checked", false);
		$(".accordion").find("input:radio").prop("checked", false);
		$(".checkboxes-wrap").find("input#allcategories").prop("checked", true);
		$(".checkboxes-wrap").find("input#allcolors").prop("checked", true);
		$(".checkboxes-wrap").find("input#allspaces").prop("checked", true);
		$(".checkboxes-wrap").find("input#allos").prop("checked", true);
		$(".accordion-flush .accordion-collapse.activeradio").collapse("hide");
		$(".accordion-flush .accordion-collapse.activeradio").removeClass("show");
		$(".accordion-flush .accordion-collapse.activeradio").addClass("collapse");
		$(".checkbuttons .accordion-button").addClass("collapsed");
		$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
			var storageChecked = $(value).attr('space');
			var colorChecked = $(value).attr('color');
			var catChecked = $(value).attr('cat');
			var osystemChecked = $(value).attr('osname');
			var allBrandBoxes = $(".smartphone-card[osname][storagename][colorname][categoryname='" + catChecked + "']").length;
			var allcolorBoxes = $(".smartphone-card[osname][storagename][categoryname][colorname='" + colorChecked + "']").length;
			var allstorageBoxes = $(".smartphone-card[osname][storagename='" + storageChecked + "'][categoryname][colorname]").length;
			var allosBoxes = $(".smartphone-card[osname='" + osystemChecked + "'][colorname][storagename][categoryname]").length;
			var allBrandBoxesAll = $(".smartphone-card[osname][storagename][colorname][categoryname]").length;
			if ($(value).attr('cat')) {
				if ($(value).attr('cat') === 'allcategories') {
					$(value).html(allBrandBoxesAll);
				} else {
					$(value).html(allBrandBoxes);
				}
			} else if ($(value).attr('color')) {
				if ($(value).attr('color') === 'allcolors') {
					$(value).html(allBrandBoxesAll);
				} else {
					$(value).html(allcolorBoxes);
				}
			} else if ($(value).attr('space')) {
				if ($(value).attr('space') === 'allspaces') {
					$(value).html(allBrandBoxesAll);
				} else {
					$(value).html(allstorageBoxes);
				}
			} else if ($(value).attr('osname')) {
				if ($(value).attr('osname') === 'allos') {
					$(value).html(allBrandBoxesAll);
				} else {
					$(value).html(allosBoxes);
				}
			}
		});
		var newTextToRange = $(".smartphone-cards-wrap .range-slider-wrap .irs-to").text().replace(/\D/g, '');
		$(".smartphone-cards-wrap .range-slider-wrap .irs-to").text(newTextToRange)
	});
}
//view more button show hide if category is less then or equal to 5
$(".p-category-list-wrap ul").each(function () {
	var liCount;
	liCount = $(this).children("li").length;
	if (liCount <= 5) {
		$(this).next(".view-more-smartphone").addClass("d-none");
	}
});
// view more and view less functionality for category list ( filters )
function vewCategoriesMoreLess() {
	var viewMorebutton = $(this);
	viewMorebutton.closest(".p-category-list-wrap").find("ul").toggleClass("full-list");
	viewMorebutton.toggleClass("toggleView");
}
$(".p-category-list-wrap .view-more-smartphone").off("click").on("click", vewCategoriesMoreLess);

// filter mobile view popup open close
function filtersMobileView(thisValue) {
	if (window.innerWidth < 992) {
		var currentElement = $(thisValue).attr("data-label");
		if (currentElement) {
			$(".responsive-" + currentElement).addClass("mobileViewActive");
			$("body").addClass("freeze");
		}
	}
}

$(".filter-compare-sort-section a").off("click").on("click", function () {
	filtersMobileView(this);
});

// to make filters popup in-active ( hide )in mobile view
$(".filter-close").off("click").on("click", function () {
	$(".responsive-filters").removeClass("mobileViewActive");
	$(".responsive-sort").removeClass("mobileViewActive");
	$("body").removeClass("freeze");
});

function calculateColors(colorCat, brandCat, spaceSize, osName) {
	//// console.log(colorCat, brandCat, spaceSize, osName)
	var allCatboxes = $(".smartphone-cards-wrap .smartphone-card[categoryname]").length;
	var allColorboxes = $(".smartphone-cards-wrap .smartphone-card[categoryname]").length;
	var allSpaceboxes = $(".smartphone-cards-wrap .smartphone-card[categoryname]").length;
	var allOsboxes = $(".smartphone-cards-wrap .smartphone-card[categoryname]").length;
	var allColorBoxes = $(".smartphone-card[colorname='" + colorCat + "']").length;
	var allBrandsBoxes = $(".smartphone-card[categoryname='" + brandCat + "']").length;
	var allSpaceBoxes = $(".smartphone-card[storagename='" + spaceSize + "']").length;
	var allOsBoxes = $(".smartphone-card[osname='" + osName + "']").length;
	$(".smartphone-cards-wrap input + label .badge[cat='allcategories']").html(allCatboxes)
	$(".smartphone-cards-wrap input + label .badge[color='allcolors']").html(allColorboxes)
	$(".smartphone-cards-wrap input + label .badge[space='allspaces']").html(allSpaceboxes)
	$(".smartphone-cards-wrap input + label .badge[osname='allos']").html(allOsboxes)
	$(".smartphone-cards-wrap input + label .badge[cat='" + brandCat + "']").each(function (index, value) {
		$(value).html(allBrandsBoxes)
	});
	$(".smartphone-cards-wrap input + label .badge[color='" + colorCat + "']").each(function (index, value) {
		$(value).html(allColorBoxes)
	});
	$(".smartphone-cards-wrap input + label .badge[space='" + spaceSize + "']").each(function (index, value) {
		$(value).html(allSpaceBoxes)
	});
	$(".smartphone-cards-wrap input + label .badge[osname='" + osName + "']").each(function (index, value) {
		$(value).html(allOsBoxes)
	});

}

const currentURL = window.location.href;

function updateRadioLabelQuantity(singleBrand) {
	$(".smartphone-cards-wrap input + label .badge").each(function (index, value) {
		var colorChecked = $(value).attr('color');
		var storageChecked = $(value).attr('space');
		var osystemChecked = $(value).attr('osname');
		var catChecked = $(value).attr('cat');
		var colorwithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname='" + colorChecked + "']").length;
		var storagewithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename='" + storageChecked + "']").length;
		var oswithBrand = $(".smartphone-card[categoryname='" + singleBrand + "'][osname='" + osystemChecked + "']").length;
		var allColorBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][colorname]").length;
		var allStorageBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][storagename]").length;
		var allOsBoxes = $(".smartphone-card[categoryname='" + singleBrand + "'][osname]").length;
		var allBrandBoxes = $(".smartphone-card[osname][storagename][colorname][categoryname='" + catChecked + "']").length;
		var allBrandBoxesAll = $(".smartphone-card[osname][storagename][colorname][categoryname]").length;

		if ($(value).attr('cat')) {
			if ($(value).attr('cat') === 'allcategories') {
				$(value).html(allBrandBoxesAll);
			} else {
				$(value).html(allBrandBoxes);
			}
		} else if ($(value).attr('color')) {
			if ($(value).attr('color') === 'allcolors') {
				$(value).html(allColorBoxes);
			} else {
				$(value).html(colorwithBrand);
			}
		} else if ($(value).attr('space')) {
			if ($(value).attr('space') === 'allspaces') {
				$(value).html(allStorageBoxes);
			} else {
				$(value).html(storagewithBrand);
			}
		} else if ($(value).attr('osname')) {
			if ($(value).attr('osname') === 'allos') {
				$(value).html(allOsBoxes);
			} else {
				$(value).html(oswithBrand);
			}
		} else {
			// console.log('category radios');
		}
		if ($(value).attr('cat') == singleBrand) {
			// console.log(singleBrand)
			// console.log($(this).closest("div.checkboxes-wrap"))
			// $(".laptops-cards-wrap .checkboxes-wrap").find("input#allbrands").prop("checked", false);
			$(this).closest("div.checkboxes-wrap").find("input[name='brands']").prop("checked", true)
			// console.log('it works')
		}
	});
}

function getParameterByNamePhones(name, href) {
	name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
	const regexS = '[\\?&]' + name + '=([^&#]*)';
	const regex = new RegExp(regexS);
	const results = regex.exec(href);
	if (results == null) return '';
	else return decodeURIComponent(results[1].replace(/\-/g, ' '));
}

function queryParamValuePhones(name, url = currentURL) {
	if (!name || !currentURL) return undefined;
	return getParameterByNamePhones(name, url).replace(/_/g, ' ').replace(/[\_\"\'\>\<\?\=\/\/]/g, ' ');
}

function updateCardsByQueryParameter() {
	var singleBrand = queryParamValuePhones('selectedBrand', currentURL);
	var allBrandsBoxes = $(".smartphone-card");
	var visibleCardsSmartphones = [];
	$("#seeMore").hide();
	$(allBrandsBoxes).each((index, elem) => {
		if (singleBrand === 'allcategories') {
			$(elem).show();
			visibleCardsSmartphones.push(elem)
			// console.log('brand is all')
		} else {
			if ($(elem).attr('categoryname') === singleBrand) {
				$(elem).show();
				// console.log('Brands is checked');
				visibleCardsSmartphones.push(elem)
			} else {
				$(elem).hide();
			}
		}

	});
	// console.log(visibleCardsSmartphones);
	if (visibleCardsSmartphones.length > 0) {
		$("#norecords").hide();
	} else {
		$("#norecords").show();
	}
	updateRadioLabelQuantity(singleBrand);
}
// seeMore Btn show cards
function seeMoreBtn() {
	var size_cards = $(".smartphone-cards-box .smartphone-card").length;
	var x = 6;
	$('#seeMore').click(function () {
		x = (x + 3 <= size_cards) ? x + 3 : size_cards;
		$('.smartphone-cards-box .smartphone-card:lt(' + x + ')').show();
		if (x === size_cards) {
			$(this).hide()
		}
	});
}
seeMoreBtn();

$(document).ready(function () {
	$("#smartphone-loader").hide();
	let smartphonesUrl = window.location.href;
	// if (smartphonesUrl.includes('?')) {
	if (smartphonesUrl.indexOf("selectedBrand") > -1) {
		// console.log('Parameterised URL');
		updateCardsByQueryParameter();
	} else {
		// console.log('No Parameters in URL');
		$('.smartphone-cards-wrap input + label .badge').each(function (index, value) {
			var brandCat = $(value).attr('cat');
			var colorCat = $(value).attr('color');
			var spaceSize = $(value).attr('space');
			var osName = $(value).attr('osname');
			calculateColors(colorCat, brandCat, spaceSize, osName);
		});
		
		$('.smartphone-cards-box .smartphone-card:gt(5)').hide();
		
	}

	// if (smartphonesUrl.indexOf("sortBy") > -1) {
	// 	sortProductsbyMostPopular();
	// } 

	const queryStringSorting = window.location.search;
	const urlParamsSorting = new URLSearchParams(queryStringSorting);
	const sortBy = urlParamsSorting.get('sortBy')
	if (sortBy === 'exclusive-offers') {
		sortProductsbyMostPopular();
	} else if (sortBy === 'recommended') {
		sortProductsbyRecommended();
	}

	function getChildrenofCategories() {
		$('.filters-listing-box .accordion .accordion-item').each(function () {
			var newLength = $(this).find('.p-category-list-wrap ul li').length
			if (newLength === 0) {
				$(this).find('.accordion-header').hide()
			}
		})
	}
	resetButton();
	vewCategoriesMoreLess();
	getChildrenofCategories();
});
