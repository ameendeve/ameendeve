import { FORM_SUCCESS, FORM_ERROR } from '../analytics/analytics';
import valdefault from 'jquery';
import Dropzone from "dropzone"

Dropzone.autoDiscover = false;

var dropzones = [];
var filesArrayList = [];
var attachmentsObj = {};
let flNameAlphabatsOnly;
let documemntRequiredMsg;
let reuploadText;
let reuploadMsgError;
if ($('body').attr('dir') == 'rtl') {
  documemntRequiredMsg = 'الوثيقة مطلوبة',
    flNameAlphabatsOnly = 'الرجاء ادخال احرف و مسافة فقط'
  reuploadText = "إعادة تحميل",
    reuploadMsgError = "خطأ في التحميل - حجم الملف كبير جدًا"
} else {
  documemntRequiredMsg = "Document is required",
    flNameAlphabatsOnly = "Letters only please",
    reuploadText = "Re-Upload",
    reuploadMsgError = "Upload Error - File size is too big"
}

function handleUploadedFile(fileData, fileBaseUrl, fileName) {
  var filetypeName = fileData.previewTemplate.innerText;
  var uppercaseType = filetypeName.split('\n')[0].toUpperCase()
  var uppercaseFileType = uppercaseType.split(' ').join('_')
  attachmentsObj = {
    name: fileName,
    type: uppercaseFileType.replace('*',''),
    document: fileBaseUrl
  };
  filesArrayList.push(attachmentsObj);
}
function removeFileObjectWithId(nameofFile) {
	filesArrayList.splice(filesArrayList.findIndex(item => item.name == nameofFile.name),1);
}

$('.showfilesList').click(function() {
    showFilesFunction();
})
$(document).ready(function () {
  $('.dropzone').each(function (i, el) {
      const name = 'g_' + $(el).data('field');
        const labelName = $(el).data('field');
        const imgpath = $(el).data('image');
        const modalID = $(el).data('modal');
        var err_flag = false;
        const images = [];
        var myDropzone = new Dropzone(el, {
            //all your settings here.*
            maxFiles: 1,
            maxFilesize: 1,
            thumbnailWidth: null,
            thumbnailHeight: null,
            addRemoveLinks: false,
            url: 'my_upload_file',
            acceptedFiles: 'application/pdf,.doc,.docx',
            dictDefaultMessage: "<div class='defaulttext'><div class='label-wrap'><svg width='23' height='23' viewBox='0 0 23 23' fill='none' xmlns='http://www.w3.org/2000/svg'><circle cx='11.5' cy='11.5' r='11' fill='white' stroke='#848789'/><path d='M17 11.5H6M11.5 17V6' stroke='#848789' stroke-linecap='round'/></svg><span class='drag-n-drop'><h4> " + labelName + " </h4></span></div></div>",
            previewTemplate:
            `<div class="custom-dropzone-preview">
              <div class="rsr-uploading-file">
                  <div class='label-wrap'><svg width='23' height='23' viewBox='0 0 23 23' fill='none' xmlns='http://www.w3.org/2000/svg'><circle cx='11.5' cy='11.5' r='11' fill='white' stroke='#848789'/><path d='M17 11.5H6M11.5 17V6' stroke='#848789' stroke-linecap='round'/></svg><span class='drag-n-drop'><h4> `+ labelName + ` </h4></span></div>
                  <div class="dropzone-preview-box">
                          <p>40% completed</p>
                      <div class="rsr-progress-bar">                                
                          <span class="rsr-green-bar"></span>
                      </div>    
                  </div>
              </div>
              <div class="rsr-upload-error file-size-big">
                  <div class='label-wrap'><span class='drag-n-drop sec-secondary-headings'><h5> `+ labelName + ` </h5> <div class='sec-secondary'><div class='p4'><p class='upload-error'>` + reuploadMsgError + `</p> </div></div>   </span></div>                        
                  <div class="dropzone-preview-box">
                  <a class="re-upload">` + reuploadText + `</a>    
                  </div>  
              </div>
              <div class="rsr-upload-error invalid-file-format">
                  <div class='label-wrap'><span class='drag-n-drop sec-secondary-headings'><h5> `+ labelName + ` </h5> <div class='sec-secondary'><div class='p4'><p class='upload-error'>` + reuploadMsgError + `</p> </div></div>   </span></div>                        
                  <div class="dropzone-preview-box">
                  <a class="re-upload">` + reuploadText + `</a>    
                  </div>  
              </div>
              <div class='rsr-upload-success'>
                  <div class='rsr-upload-result'>
                      <div class="label-wrap">
                      <div class="dropzone-preview-box">
                      <div class="rsr-uploadimg">
                          <img class="dropzone-thumb-upload-img" data-dz-thumbnail />
                          </div>                         
                          </div>  
                          <div class="drag-n-drop">                                    
                              <h4>` + labelName +  `</h4>
                              <div class="rsr-filename">                                    
                                  <span data-dz-name></span>
                              </div>                                
                          </div>                                
                          <a class="rsr-delete" href="#">
                              <svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                  <g id="Asset-Artboard-Page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                                      <g id="Icon/Outline-1pt/trash-bin/trash_bin_black" stroke="#242424">
                                          <polygon id="Line" points="3.75 18.75 16.25 18.75 16.25 3.75 3.75 3.75"></polygon>
                                          <polygon id="Line" points="6.5625 3.75 13.4375 3.75 13.4375 1.25 6.5625 1.25"></polygon>
                                          <line x1="1.25" y1="3.75" x2="18.75" y2="3.75" id="Line"></line>
                                          <line x1="6.5625" y1="6.5625" x2="6.5625" y2="15.9375" id="Line"></line>
                                          <line x1="10" y1="6.5625" x2="10" y2="15.9375" id="Line"></line>
                                          <line x1="13.4375" y1="6.5625" x2="13.4375" y2="15.9375" id="Line"></line>
                                      </g>
                                  </g>
                              </svg>
                          </a>
                      </div>                            
                  </div>
              </div>`,

            init: function () {
                var dropzoneForm = this;
                //this function check if there is an file already uploaded
                // if yes it removes the first/last file
                this.on("addedfile", function (file) {
                    $("#smb-upload-form-loader").show();
                    
                      
                    
                    
                    // fileReaderBase64.onload = function(event) {
                      
                    // };
                    if (this.files[1] != null) {
                        this.removeFile(this.files[0]);
                        
                    }                                
                    var _this = this;
                    $(this.element).find(".rsr-delete").on("click", function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        removeFileObjectWithId(file)
                        _this.removeFile(file);})
                    }),
                    this.on("success", function (file, response) {
                        $('.dz-image').css({ "width": "100%", "height": "auto" });
                        
                    }),
                    this.on("thumbnail", function (file, dataUrl, errorMessage, response) {
                        $('.dz-image').last().find('img').attr({ width: '100%', height: '100%' });
                        var img_path = dataUrl
                        
                        if (err_flag == false) {
                            $('.emirate-id-card-img img').attr('src', img_path);
                            $('#'+ modalID ).modal('show');
                        }
                    }),
                    this.on("error", function (file, errorMessage) {
                        err_flag = true;
                        
                        $(".re-upload").on("click", function(e) {
                          this.closest('.dropzone').click();
                        })
                        $("#smb-upload-form-loader").hide();
                    })
            },
            accept: function (file, done) {
                var ext = file.name.split('.').pop();
                if (file.type != 'image/gif' && file.type != 'image/jpeg' && file.type != 'image/png' && file.type != 'application/pdf' && file.type != 'application/doc' && file.type != 'application/docx' && file.type != 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' && file.type != 'application/xls' && file.type != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
                    file.previewElement.classList.add("invalidFileFormat");
                    err_flag = true;
                    $(".re-upload").on("click", function(e) {
                      this.closest('.dropzone').click();
                    });
                }
                else if (ext == "pdf") {
                    $(file.previewElement).find(".rsr-uploadimg img").attr("src", "/content/dam/etisalat/smb/channel-partner/pdf.png");
                    file.previewElement.classList.add("default-file-icon");
                    $('.emirate-id-card-img img').attr('src', '/content/dam/etisalat/smb/channel-partner/pdf.png');
                    $('#'+ modalID ).modal('show');
                } else if (ext.indexOf("doc") != -1 || ext.indexOf("docx") != -1) {
                    $(file.previewElement).find(".rsr-uploadimg img").attr("src", "/content/dam/etisalat/smb/channel-partner/doc.png");
                    file.previewElement.classList.add("default-file-icon");
                    $('.emirate-id-card-img img').attr('src', '/content/dam/etisalat/smb/channel-partner/doc.png');
                    $('#'+ modalID ).modal('show')
                } else if (ext.indexOf("xls") != -1 || ext.indexOf("xlsx") != -1) {
                    $(file.previewElement).find(".rsr-uploadimg img").attr("src", "/content/dam/etisalat/smb/channel-partner/xls.png");
                    file.previewElement.classList.add("default-file-icon");
                    $('.emirate-id-card-img img').attr('src', '/content/dam/etisalat/smb/channel-partner/xls.png');
                    $('#'+ modalID ).modal('show')
                }
                // $('#modals-emirates-id-front').modal('show');
                var fileReaderBase64 = new FileReader();
                    fileReaderBase64.readAsDataURL(file);
                    fileReaderBase64.addEventListener('load', function(event) {
                      var base64StringUrl = event.target.result;
                      var fileName = file.name;
                      handleUploadedFile(file, base64StringUrl ,fileName);
                    })
                dropzones.push(myDropzone);
                
                
                $("#smb-upload-form-loader").hide();
                
            },
            success: function (file, response) {
                alert('success')
                if (file.previewElement) {
                    file.previewElement.classList.add("dz-success");
                }
                
                
            }
        })
        
       
        
  })
  
})

// first form js
valdefault();
if(window.location.href.indexOf('error') !== -1){
    $("#smbUploadDocument #dErrorMessage").removeClass('hidden');
}

var $smbUploadDocument = $("#smbUploadDocument");
var smbUploadDocumentlang = $('html').attr('lang');
var smbUploadDocumentresultMessageContainer = $("#smbUploadDocument .business-form-submitted");
var smbUploadDocumentinvalidNumberError = window.location.href.indexOf(".ae/ar") > -1 ? "رقم هاف محمول غير صالح " : "Invalid Contact Number";
var smbUploadDocumentGeneralErrorMsg = window.location.href.indexOf(".ae/ar") > -1 ? "هناك شيء خاطئ، يرجى المحاولة في وقت لاحق" : "Something went wrong, please try again later";
// if (!$smbUploadDocument.length) {
//   return false;
// }
const $SUBMIT_CTA = $('#smbUploadDocument #btnsmbUploadDocument');
const currentURL = window.location.href;
$SUBMIT_CTA.on('click', function () {
  $('#smbUploadDocument .col-md-6 .dropzoneWrapper div.dropzone').each(function(dropindex, dropitem) {
    if(!$(dropitem).hasClass('dz-started') || $(dropitem).children('.dz-error').length > 0) {
      $(this).addClass('required-field')
    } else {
      $(this).removeClass('required-field')
    }
  })
  $('#smbUploadDocument .col-md-6 .dropzoneWrapper').each(function(dropzoneindex, dropzonewrap) {
    if($(dropzonewrap).children('.dz-started').length && !$(dropzonewrap).find('.dz-error').length) {
      $(this).find(".hidewith-opacity .form-group input.form-control").val('files uploaded');
      $(this).find(".hidewith-opacity .form-group input.form-control").removeClass('has-error');
      $(this).find(".hidewith-opacity .form-group input.form-control").addClass('valid');
    } else {
      $(this).find(".hidewith-opacity .form-group input.form-control").val('');
      $(this).find(".hidewith-opacity .form-group input.form-control").addClass('has-error');
      $(this).find(".hidewith-opacity .form-group input.form-control").removeClass('valid');
    }
  })
  if ($smbUploadDocument.valid() == false) {
      FORM_ERROR($smbUploadDocument, 'validation error');
      return false;
  }
});

function getFormData($smbUploadDocument) {
    var o = {};
    var a = $smbUploadDocument.serializeArray();
    $.each(a, function () {
      if (o[this.name]) {
        if (!o[this.name].push) {
          o[this.name] = [o[this.name]];
        }
        o[this.name].push(this.value || "");
      } else {
        o[this.name] = this.value || "";
      }
    });
    return o;
}

  function showErrorMessage(text) {
    smbUploadDocumentresultMessageContainer.text(text);
    smbUploadDocumentresultMessageContainer.addClass("error");
    smbUploadDocumentresultMessageContainer.removeClass("hidden");
    // show again the submit button, enable the form, hide the loadings
  }
  // $('.submit-wraper .btn').on('click',function(){
  //   if($("#smbUploadDocument").valid() == false){
  //     return false
  //   }
  // });
function getParameterByName(name, href) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    const regexS = '[\\?&]' + name + '=([^&#]*)';
    const regex = new RegExp(regexS);
    const results = regex.exec(href);
    if (results == null) return '';
    else return decodeURIComponent(results[1].replace(/\-/g, ' '));
  }
  function queryParamValue(name, url = currentURL) {
    if (!name || !currentURL) return undefined;

    return getParameterByName(name, url)
      .replace(/_/g, ' ')
      .replace(/[\_\"\'\>\<\?\=\/\/]/g, ' ');
  }

$(document).ready(function () {
    
    $smbUploadDocument.validate({
            rules: {
                firstName: {
                    required: true,
                    realalphabeticlatinarabic: true,
                    maxlength: 248
                },                   
                lastName: {
                    required: true,
                    realalphabeticlatinarabic: true,
                    maxlength: 248
                },
                emailAddress: {
                    required: true,
                    email2: !0
                },
                mobileNumber: {
                    required: true,
                    digits: true,
                    pattern: /^(050|054|055|056|052)/,
                    minlength: 10,
                    maxlength: 10
                },
                EmiratiFiles: { 
                  required: true 
                },
                ObjectiveFiles: { 
                  required: true 
                },
                HiringFiles: { 
                  required: true 
                },
                StatementFiles: { 
                  required: true 
                },
                VolumeFiles: { 
                  required: true 
                }
                
            },
            errorPlacement:
            function( error, element ){
              error.insertAfter(element);
            },
            // messages: smbUploadDocumentmessagelocal,
            messages: {
              EmiratiFiles: { 
                required: documemntRequiredMsg 
              },
              ObjectiveFiles: { 
                required: documemntRequiredMsg 
              },
              HiringFiles: { 
                required: documemntRequiredMsg 
              },
              StatementFiles: { 
                required: documemntRequiredMsg 
              },
              VolumeFiles: { 
                required: documemntRequiredMsg 
              },
              firstName: {
                lettersonly: flNameAlphabatsOnly
              },
              lastName: {
                lettersonly: flNameAlphabatsOnly
              }
            },
            submitHandler: function(form) {
                var dataObj = getFormData($smbUploadDocument);
                var formData = {
                    formType: dataObj.subject,
                    firstName: dataObj.firstName,
                    lastName: dataObj.lastName,
                    email: dataObj.emailAddress,
                    mobile: dataObj.mobileNumber,
                    message: dataObj.description,
                    attachments: filesArrayList
                }
                let dataObjwithJson = {
                    ClientCaptchaValue: sessionStorage.getItem("gcresponse"),
                    TYPE: 'NOTIFY_BUSINESS_USER',
                    REQPAYLOAD: formData,
                };
                dataObjwithJson = JSON.stringify(dataObjwithJson, null, 2);
                document.getElementById("btnsmbUploadDocument").disabled = true;
                
                $.ajax({
                    type: 'POST',
                    url: $($smbUploadDocument).attr('action'),
                    data: dataObjwithJson.replace(/[\r\n]/gm, ''),
                    dataType: 'json',
                    headers: {
                    'content-type': 'application/json',
                    'x-calling-application': 'cms',
                    },
                    encode: true
                })
                .done(function (response) {
                    const fromData = getFormData($smbUploadDocument);

                    
                    const authoredRedirectUrl = fromData[':redirect'] || `channel-partner-thankyou.html`;
                    
                    let RE_URL = '';
                    const ref = response?.bcrmTransactionId || '';

                    let path = window.location.pathname;
                    let page = path.split('/').pop();
                   
                    if(window.location.search) {
                      RE_URL += `${window.location.search}&referenceNo=${ref}`;
                    } else {
                      RE_URL += `?referenceNo=${ref}`;
                    }
          
                    $(document).trigger('GA_FROM_TRACKING', { $type: 'submit' });
                    FORM_SUCCESS($smbUploadDocument, formData);
                    window.location.href = window.location.origin + window.location.pathname.replace(page, authoredRedirectUrl) + RE_URL; 
                   // window.location.href =  window.location.href.replace(page, authoredRedirectUrl)+RE_URL;
          
                    return true;
                })
                .fail(submitErrorResponse);
    
                // return false to prevent normal browser submit and page navigation
               return false;
            }
        })
    });

    
    var submitErrorResponse = function(jqXHR, textStatus, error) {
        let errorText = (jqXHR.responseJSON && jqXHR.responseJSON.message) || error;
        showErrorMessage(smbUploadDocumentGeneralErrorMsg);
        FORM_ERROR($smbUploadDocument, 'API error', errorText);
    };
    
    
