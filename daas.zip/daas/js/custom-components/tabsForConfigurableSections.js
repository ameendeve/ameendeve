
(function (window) {

	
      function tabsConfigSlider() {
        $(document).find(".eand-tabs-config").each(function (index) {
          $(this).addClass("slider" + index);     
          var $tabsSlider = $(this);
          //var isSecondary = $(this).hasClass('eand-pills-wrap');
          $tabsSlider.find(".swiper-button-next").addClass("sliderRight" + index);
          $tabsSlider.find(".swiper-button-prev").addClass("sliderLeft" + index);
          $tabsSlider.find(".swiper-pagination").addClass("sliderPagination" + index);
          var swiper = new Swiper(".slider" + index + " .tab-config-tile .swiper", {
            slidesPerView: 'auto',
            spaceBetween: 0,
            navigation: {
              nextEl: ".swiper-button-next.sliderRight" + index,
              prevEl: ".swiper-button-prev.sliderLeft" + index,
            },
            pagination: {
              el: ".swiper-pagination.sliderPagination" + index,
              clickable: true,
              dynamicBullets: true,
              dynamicMainBullets: 4
            },
           
          });
        });
      }
      // register the event handlers
      $(document).ready(function () {
        var activeTab,previousTab,activeTabIndex,previousTabIndex
        var elements = document.querySelectorAll('a[data-bs-toggle="tab"]')
        var onTabChanged = function(e) {
          activeTab = $(e.target).parent('li')
          previousTab = $(e.relatedTarget).parent('li')
          activeTabIndex = $(activeTab).index();
          previousTabIndex = $(previousTab).index();
          if(activeTabIndex > previousTabIndex) {
            
            $(this).parents('.tabs-nav-wrap').find('.swiper-button-next').click();
          }
          else {
            $(this).parents('.tabs-nav-wrap').find('.swiper-button-prev').click();
          }
        };
        for (var i = 0; i < elements.length; i++) {
          elements[i].addEventListener('shown.bs.tab', onTabChanged, false);
        }
        
        tabsConfigSlider();
      });
	  

})(window);