function initTariffCardContextNavCarousel() {
    $(document).find(".tarrif-card-inner-wrap").each(function (index) {
        $(this).addClass('slideronPage' + index);
        var $tariffcardCarousel = $(this);
        $tariffcardCarousel.find(".swiper-pagination").addClass("tariffcarousel" + index);
        console.log($(".withSlider" + index + ".tarrif-card-carousel"));
        var swiperSlideLength = $('.slideronPage' + index + " .tarrif-card-carousel .swiper-slide").length;
        $(this).addClass("swiper-with-" + swiperSlideLength + "-slides");
        if ($(window).width() > 992) {
            if (swiperSlideLength <= 4) {
                $(".slideronPage" + index).addClass("destroyed");
                $(".slideronPage" + index).find(".swiper-wrapper").addClass("row");
                var good = $(".slideronPage" + index).find(".swiper-wrapper.row").children().removeClass("swiper-slide");
                console.log(good);
                $(".slideronPage" + index).find(".swiper-navigation").addClass("deactive");
            } else {
                $(".slideronPage" + index).find(".swiper-wrapper").removeClass("row");
                var $carouselSliderwithProgress = new Swiper(".slideronPage" + index + " .tarrif-card-carousel", {
                    slidesPerGroupSkip: 1,
                    slidesPerView: 4.2,
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                        type: "progressbar"
                    },
                    breakpoints: {
                        1099: {
                            slidesPerView: 4.3,
                            spaceBetween: 24
                        },
                        768: {
                            slidesPerView: 2.3,
                            spaceBetween: 12
                        },
                        100: {
                            slidesPerView: 1.2,
                            spaceBetween: 10,
                            pagination: {
                                type: "bullets",
                                clickable: true
                            }
                        }
                    }
                });
            }
        } else {
            $(".slideronPage" + index).find(".swiper-wrapper").removeClass("row");
            var $carouselSliderwithProgress = new Swiper(".slideronPage" + index + " .tarrif-card-carousel", {
                slidesPerGroupSkip: 1,
                slidesPerView: 4.2,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                    type: "progressbar"
                },
                breakpoints: {
                    1099: {
                        slidesPerView: 4.3,
                        spaceBetween: 24
                    },
                    768: {
                        slidesPerView: 2.3,
                        spaceBetween: 12
                    },
                    100: {
                        slidesPerView: 1.2,
                        spaceBetween: 10,
                        pagination: {
                            type: "bullets",
                            clickable: true
                        }
                    }
                }
            });
        }
    });
}
$(document).ready(function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    initTariffCardContextNavCarousel();
});
