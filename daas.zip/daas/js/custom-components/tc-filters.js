// register the event handlers
$(document).ready(function () {
if ($(window).width() > 767) {
    $(".eand-filter-wrapper.third-variation .vertical-accordion-list-wrap .accordion-button").off('click').on("click", function (e) {
    var attrtab = $(this).attr("data-bs-target");
    $(".vertical-accordion-list-wrap .accordion-button").addClass("collapsed");
    $(this).removeClass("collapsed");
    $(".eand-filter-wrapper.third-variation .content-wrapper .accordion-item .accordion-collapse").removeClass("show");
    $(".eand-filter-wrapper.third-variation .content-wrapper .accordion-item").find(attrtab).addClass("show");
    });
}
});
