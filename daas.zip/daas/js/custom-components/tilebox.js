import { swiperInit } from "../swipernwtcon";

function tileBoxCarousel() {
    $(document).find(".tile-box-carousel").each(function (index) {
        $(this).addClass("tileBoxSwiper" + index);
        var $tileBoxParent = $(this);
        $tileBoxParent.find(".swiper-button-next").addClass("tileboxRight" + index);
        $tileBoxParent.find(".swiper-button-prev").addClass("tileboxLeft" + index);
        $tileBoxParent.find(".swiper-pagination").addClass("tileboxpage" + index);
        var carouselSliderTileBox = swiperInit(".tileBoxSwiper" + index + " .tile-box-carousel-wrapper", {
            loop: false,
            slidesPerGroupSkip: 1,
            navigation: false,
            pagination: {
                el: '.swiper-pagination.tileboxpage' + index,
                clickable: true
            },
            breakpoints: {
                1099: {
                    slidesPerView: 3.25,
                    spaceBetween: 24,
                    pagination: {
                        type: "progressbar",
                        clickable: true
                    }
                },
                768: {
                    slidesPerView: 3.20,
                    spaceBetween: 16,
                    pagination: {
                        type: "progressbar",
                        clickable: true
                    }
                },
                100: {
                    slidesPerView: 1.25,
                    spaceBetween: 16,
                    pagination: {
                        type: "bullets",
                        clickable: true
                    }
                }
            }
        });
    });
} // Initialize the carousel Function


$(document).ready(function () {
    tileBoxCarousel();
});