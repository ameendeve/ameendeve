 /**
* ###version###
* Top Nav
*/
import { LANGUAGE_SWITCH } from './language-switch';
$(document).ready(function() {
		$('.inc-push-meu-icon a').click(function(){
			console.log("Push Nav Working");
			$('.push-nav-container').toggleClass('open');
			$('body').toggleClass('push-menu-open');
			// $('.push-enLogo').toggleClass('d-none')
			if($('body').hasClass('push-menu-open')){
				$('.en-logo-text').addClass('in-left');
				setTimeout(function(){
					$('.push-close').removeClass('d-none');
				},100);
			}else{
				$('.en-logo-text').removeClass('in-left');
				$('.push-close').addClass('d-none');
			}
		});
    $(window).scroll(function(){
			var sticky = $('.stickyNav'),
			scroll = $(window).scrollTop();
			if (scroll >= 0) sticky.addClass('fixedNav');
			else sticky.removeClass('fixedNav');
		});
		LANGUAGE_SWITCH();
});
