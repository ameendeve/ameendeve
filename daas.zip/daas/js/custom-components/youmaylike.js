import { swiperInit } from "../swipernwtcon";

 function youmayalsoLikeCarouselBlurredBg() {
	 $(document).find(".you-may-also-like-mobile-carousel-only").each(function (index) {
		 $(this).addClass("youMayLikeSwiperBb" + index);
		 var $youMayLikeParent = $(this);
		 $youMayLikeParent.find(".swiper-button-next").addClass("youmaylikebbRight" + index);
		 $youMayLikeParent.find(".swiper-button-prev").addClass("youmaylikebbLeft" + index);
		 $youMayLikeParent.find(".swiper-pagination").addClass("youmaylikebbpage" + index);
		 var carouselSlideryouMayLikeGrid = swiperInit(".youMayLikeSwiperBb" + index + " .you-may-like-blurred-bg-carousel", {
			 loop: false,
			 slidesPerGroupSkip: 1,
			 navigation: false,
			 pagination: {
				 el: '.swiper-pagination.youmaylikebbpage' + index,
				 clickable: true
			 },
			 breakpoints: {
				 1099: {
					 slidesPerView: 3,
					 spaceBetween: 24
				 },
				 768: {
					 slidesPerView: 3,
					 spaceBetween: 16
				 },
				 100: {
					 slidesPerView: 1.2,
					 spaceBetween: 16
				 }
			 }
		 });
	 });
 } //Swiper with semitransparent gradient overlay


 function youmayalsoLikeCarouselGradientOverlay() {
	 $(document).find(".you-may-also-like-main-carousel").each(function (index) {
		 $(this).addClass("youMayLikeSwiperGo" + index);
		 var $youMayLikeParentGo = $(this);
		 $youMayLikeParentGo.find(".swiper-button-next").addClass("youmaylikegoRight" + index);
		 $youMayLikeParentGo.find(".swiper-button-prev").addClass("youmaylikegoLeft" + index);
		 $youMayLikeParentGo.find(".swiper-pagination").addClass("youmaylikegopage" + index);
		 var carouselSlideryouMayLikeGrid = swiperInit(".youMayLikeSwiperGo" + index + " .you-may-like-gradient-overlay-carousel", {
			 loop: false,
			 slidesPerGroupSkip: 1,
			 navigation: false,
			 pagination: {
				 el: '.swiper-pagination.youmaylikegopage' + index,
				 clickable: true
			 },
			 breakpoints: {
				 1099: {
					 slidesPerView: 3,
					 spaceBetween: 24,
					 pagination: {
						 type: "progressbar",
						 clickable: true
					 }
				 },
				 768: {
					 slidesPerView: 2.2,
					 spaceBetween: 16,
					 pagination: {
						 type: "progressbar",
						 clickable: true
					 }
				 },
				 100: {
					 slidesPerView: 1.2,
					 spaceBetween: 16,
					 pagination: {
						 type: "bullets",
						 clickable: true
					 }
				 }
			 }
		 });
	 });
 }

 $(document).ready(function () {
	 youmayalsoLikeCarouselBlurredBg();
	 youmayalsoLikeCarouselGradientOverlay();
 });