"use strict";
use(function () {
    var year = {};
	const date = new Date();
	if(date != null){
		year = date.getFullYear();
	}
	return {
         currentYear : year
    }

});